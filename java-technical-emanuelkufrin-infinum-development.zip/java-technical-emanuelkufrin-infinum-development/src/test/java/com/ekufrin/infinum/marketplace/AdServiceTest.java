package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.config.AdRenewalConfigurationProperties;
import com.ekufrin.infinum.marketplace.config.AdReportConfigurationProperties;
import com.ekufrin.infinum.marketplace.dto.AdCreateRequest;
import com.ekufrin.infinum.marketplace.dto.AdReportCreateRequest;
import com.ekufrin.infinum.marketplace.dto.AdResponse;
import com.ekufrin.infinum.marketplace.dto.ContactInfoResponse;
import com.ekufrin.infinum.marketplace.enums.AdReportType;
import com.ekufrin.infinum.marketplace.enums.Condition;
import com.ekufrin.infinum.marketplace.enums.Role;
import com.ekufrin.infinum.marketplace.enums.Status;
import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.exception.EmailException;
import com.ekufrin.infinum.marketplace.exception.UploadException;
import com.ekufrin.infinum.marketplace.model.Ad;
import com.ekufrin.infinum.marketplace.model.AdReport;
import com.ekufrin.infinum.marketplace.model.Category;
import com.ekufrin.infinum.marketplace.model.ContactInfo;
import com.ekufrin.infinum.marketplace.model.Location;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.repository.AdReportRepository;
import com.ekufrin.infinum.marketplace.repository.AdRepository;
import com.ekufrin.infinum.marketplace.repository.CategoryRepository;
import com.ekufrin.infinum.marketplace.repository.ContactInfoRepository;
import com.ekufrin.infinum.marketplace.repository.UserRepository;
import com.ekufrin.infinum.marketplace.service.AdService;
import com.ekufrin.infinum.marketplace.service.EmailSenderService;
import com.ekufrin.infinum.marketplace.service.ImageService;
import com.ekufrin.infinum.marketplace.service.LocationService;
import com.ekufrin.infinum.marketplace.service.OTTService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.authentication.ott.DefaultOneTimeToken;
import org.springframework.security.core.userdetails.UserDetails;

import java.io.IOException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AdServiceTest {
    @InjectMocks
    private AdService adService;
    @Mock
    private AdRepository adRepository;
    @Mock
    private UserRepository userRepository;
    @Mock
    private CategoryRepository categoryRepository;
    @Mock
    private ContactInfoRepository contactInfoRepository;
    @Mock
    private ImageService imageService;
    @Mock
    private LocationService locationService;
    @Mock
    private OTTService ottService;
    @Mock
    private EmailSenderService emailSenderService;
    @Mock
    private AdRenewalConfigurationProperties renewalConfigurationProperties;
    @Mock
    private AdReportConfigurationProperties adReportConfigurationProperties;
    @Mock
    private AdReportRepository adReportRepository;

    @Test
    void createAd_ShouldThrowUploadException_WhenNoImages() {
        AdCreateRequest request = new AdCreateRequest();
        request.setImageIds(List.of());
        UserDetails userDetails = mock(UserDetails.class);

        assertThatThrownBy(() -> adService.createAd(request, userDetails)).isInstanceOf(UploadException.class).hasMessageContaining("At least one image must be uploaded.");
    }

    @Test
    void createAd_ShouldThrowUploadException_WhenTooManyImages() {
        AdCreateRequest request = new AdCreateRequest();
        request.setImageIds(List.of(UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID()));
        UserDetails userDetails = mock(UserDetails.class);

        assertThatThrownBy(() -> adService.createAd(request, userDetails)).isInstanceOf(UploadException.class).hasMessageContaining("Maximum of 5 images allowed.");
    }

    @Test
    void createAd_ShouldThrowDBException_WhenCategoryNotFound() {
        AdCreateRequest request = new AdCreateRequest();
        request.setImageIds(List.of(UUID.randomUUID()));
        request.setCategoryId(UUID.randomUUID());
        UserDetails userDetails = mock(UserDetails.class);

        when(categoryRepository.findByIdAndActiveIsTrue(any())).thenReturn(Optional.empty());

        assertThatThrownBy(() -> adService.createAd(request, userDetails)).isInstanceOf(DBException.class).hasMessageContaining("Category not found or is deactivated.");
    }

    @Test
    void createAd_ShouldThrowDBException_WhenUserNotFound() {
        AdCreateRequest request = new AdCreateRequest();
        request.setImageIds(List.of(UUID.randomUUID()));
        request.setCategoryId(UUID.randomUUID());
        UserDetails userDetails = mock(UserDetails.class);
        when(categoryRepository.findByIdAndActiveIsTrue(any())).thenReturn(Optional.of(new Category()));
        when(userDetails.getUsername()).thenReturn(UUID.randomUUID().toString());
        when(userRepository.findByIdWithContactInfo(any())).thenReturn(Optional.empty());

        assertThatThrownBy(() -> adService.createAd(request, userDetails)).isInstanceOf(DBException.class).hasMessageContaining("User not found.");
    }

    @Test
    void createAd_ShouldReturnAdResponse_WhenValidRequest() {
        UUID categoryId = UUID.randomUUID();
        UUID contactInfoId = UUID.randomUUID();
        UUID userId = UUID.randomUUID();
        List<UUID> imageIds = List.of(UUID.randomUUID(), UUID.randomUUID());
        Location location = new Location(UUID.randomUUID(), "123 Main St", "12.34,56.78", List.of());

        AdCreateRequest request = new AdCreateRequest();
        request.setTitle("Test Ad");
        request.setDescription("Test Description");
        request.setPrice(100.0);
        request.setCondition(Condition.NEW);
        request.setCategoryId(categoryId);
        request.setContactInfoId(contactInfoId);
        request.setImageIds(imageIds);
        request.setLocation(location);

        UserDetails userDetails = mock(UserDetails.class);
        User user = new User.Builder().id(UUID.randomUUID()).name("Test User").build();
        Ad savedAd = new Ad();
        savedAd.setId(UUID.randomUUID());
        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setEmail("test@example.com");
        contactInfo.setUser(user);
        savedAd.setContactInfo(contactInfo);
        Category category = new Category();
        category.setName("Test Category");
        savedAd.setCategory(category);
        savedAd.setCondition(Condition.NEW);
        savedAd.setStatus(Status.ACTIVE);
        savedAd.setImages(new ArrayList<>());
        savedAd.setLocation(location);

        when(userDetails.getUsername()).thenReturn(userId.toString());
        when(adRepository.findByIdWithImages(savedAd.getId())).thenReturn(Optional.of(savedAd));
        when(categoryRepository.findByIdAndActiveIsTrue(categoryId)).thenReturn(Optional.of(category));
        when(userRepository.findByIdWithContactInfo(userId)).thenReturn(Optional.of(user));
        when(contactInfoRepository.findById(contactInfoId)).thenReturn(Optional.of(contactInfo));
        when(adRepository.saveAndFlush(any(Ad.class))).thenReturn(savedAd);
        when(adRepository.findByIdWithImages(savedAd.getId())).thenReturn(Optional.of(savedAd));

        AdResponse response = adService.createAd(request, userDetails);
        assertThat(response).isNotNull();
        verify(imageService).assignImagesToAd(imageIds, savedAd);
    }

    @Test
    void givenNullFilters_whenGetAllAdsWithFilterAndSorting_thenReturnsMappedPage() {
        Ad ad = new Ad();
        ad.setTitle("iPhone 13");
        ad.setDescription("Almost new");
        ad.setPrice(500.0);
        ad.setCondition(Condition.USED);
        ad.setStatus(Status.ACTIVE);
        ad.setExpiresAt(Instant.now().plus(30, ChronoUnit.DAYS));
        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setId(UUID.randomUUID());
        contactInfo.setEmail("seller@example.com");
        contactInfo.setPhoneNumber("+385911111111");
        ad.setContactInfo(contactInfo);
        Category category = new Category();
        category.setName("Electronics");
        ad.setCategory(category);
        ad.setImages(new ArrayList<>());
        ad.setLocation(null);

        Page<Ad> adsPage = new PageImpl<>(List.of(ad));
        when(adRepository.findAllFiltered(any(), any(), any(), any(), any(), any(Pageable.class))).thenReturn(adsPage);

        Page<AdResponse> result = adService.getAllAdsWithFilterAndSorting(null, null, null, null, null, PageRequest.of(0, 10));

        assertThat(result).isNotNull();
        assertThat(result.getTotalElements()).isEqualTo(1);
        AdResponse dto = result.getContent().getFirst();
        assertThat(dto.title()).isEqualTo("iPhone 13");
        assertThat(dto.price()).isEqualTo(500.0);
        assertThat(dto.category()).isEqualTo("Electronics");
        assertThat(dto.condition()).isEqualTo(Condition.USED.name());
        assertThat(dto.status()).isEqualTo(Status.ACTIVE.name());
        assertThat(dto.contactInfo()).isEqualTo(new ContactInfoResponse(contactInfo.getId(), "seller@example.com", "+385911111111"));
    }

    @Test
    void givenPageableWithSort_whenGetAllAdsWithFilterAndSorting_thenRepositoryReceivesSort() {
        when(adRepository.findAllFiltered(any(), any(), any(), any(), any(), any(Pageable.class))).thenReturn(Page.empty());

        Pageable pageable = PageRequest.of(0, 20, Sort.by("price").ascending());
        adService.getAllAdsWithFilterAndSorting(null, null, null, null, null, pageable);

        ArgumentCaptor<Pageable> captor = ArgumentCaptor.forClass(Pageable.class);
        verify(adRepository).findAllFiltered(any(), any(), any(), any(), any(), captor.capture());
        Pageable captured = captor.getValue();
        assertThat(captured.getPageNumber()).isZero();
        assertThat(captured.getPageSize()).isEqualTo(20);
        assertThat(captured.getSort().getOrderFor("price")).isNotNull();
        assertThat(Objects.requireNonNull(captured.getSort().getOrderFor("price")).isAscending()).isTrue();
    }

    @Test
    void givenMinPriceGreaterThanMaxPrice_whenGetAllAdsWithFilterAndSorting_thenReturnsEmptyPage() {
        when(adRepository.findAllFiltered(any(), any(), any(), any(), any(), any(Pageable.class))).thenReturn(Page.empty());

        Page<AdResponse> result = adService.getAllAdsWithFilterAndSorting(null, null, null, 1000.0, 100.0, PageRequest.of(0, 10));
        assertThat(result.getTotalElements()).isZero();
    }

    @Test
    void getAdById_ShouldReturnAdResponse_WhenAdExists() {
        UUID id = UUID.randomUUID();
        Ad ad = new Ad();
        ad.setId(id);
        ad.setTitle("iPhone 13");
        ad.setDescription("Almost new");
        ad.setPrice(500.0);
        ad.setCondition(Condition.USED);
        ad.setStatus(Status.ACTIVE);
        ad.setExpiresAt(Instant.now().plus(30, ChronoUnit.DAYS));
        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setId(UUID.randomUUID());
        contactInfo.setEmail("seller@example.com");
        contactInfo.setPhoneNumber("+385911111111");
        ad.setContactInfo(contactInfo);
        Category category = new Category();
        category.setName("Electronics");
        ad.setCategory(category);
        ad.setImages(new ArrayList<>());
        ad.setLocation(null);

        when(adRepository.findByIdWithImages(id)).thenReturn(Optional.of(ad));

        AdResponse response = adService.getAdById(id);

        assertThat(response).isNotNull();
        assertThat(response.title()).isEqualTo("iPhone 13");
        assertThat(response.price()).isEqualTo(500.0);
        assertThat(response.category()).isEqualTo("Electronics");
        assertThat(response.condition()).isEqualTo(Condition.USED.name());
        assertThat(response.status()).isEqualTo(Status.ACTIVE.name());
        assertThat(response.contactInfo()).isEqualTo(new ContactInfoResponse(contactInfo.getId(), "seller@example.com", "+385911111111"));
    }

    @Test
    void getAdById_ShouldThrowDBException_WhenAdNotFound() {
        UUID id = UUID.randomUUID();
        when(adRepository.findByIdWithImages(id)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> adService.getAdById(id)).isInstanceOf(DBException.class).hasMessageContaining("Ad not found.");
    }

    @Test
    void getAdsByUser_ShouldReturnUsersAds_WhenUserHasAds() {
        UUID userId = UUID.fromString("8d5cfe7c-1e1b-4a1e-b8f0-111111111111");
        UserDetails userDetails = mock(UserDetails.class);
        when(userDetails.getUsername()).thenReturn(userId.toString());

        Ad ad = new Ad();
        ad.setId(UUID.randomUUID());
        ad.setTitle("iPhone 13");
        ad.setDescription("Almost new");
        ad.setPrice(500.0);
        ad.setCondition(Condition.USED);
        ad.setStatus(Status.ACTIVE);
        ad.setExpiresAt(Instant.now().plus(30, ChronoUnit.DAYS));
        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setEmail("contact1@example.com");
        contactInfo.setPhoneNumber("+385911234567");
        ad.setContactInfo(contactInfo);
        Category category = new Category();
        category.setName("Electronics");
        ad.setCategory(category);
        ad.setImages(new ArrayList<>());
        ad.setLocation(null);

        Page<Ad> adsPage = new PageImpl<>(List.of(ad));
        when(adRepository.findAllByAuthorId(userId, PageRequest.of(0, 10))).thenReturn(adsPage);

        Page<AdResponse> result = adService.getAdsByUser(userDetails, PageRequest.of(0, 10));

        assertThat(result.getTotalElements()).isEqualTo(1);
        assertThat(result.getContent().getFirst().title()).isEqualTo("iPhone 13");
        assertThat(result.getContent().getFirst().price()).isEqualTo(500.0);
        verify(adRepository).findAllByAuthorId(userId, PageRequest.of(0, 10));
    }

    @Test
    void getAdsByUser_ShouldReturnEmptyPage_WhenUserHasNoAds() {
        UUID userId = UUID.fromString("f1a6b9e3-483b-41b7-81db-666666666666");
        UserDetails userDetails = mock(UserDetails.class);
        when(userDetails.getUsername()).thenReturn(userId.toString());

        when(adRepository.findAllByAuthorId(userId, PageRequest.of(0, 10))).thenReturn(Page.empty());

        Page<AdResponse> result = adService.getAdsByUser(userDetails, PageRequest.of(0, 10));

        assertThat(result.getTotalElements()).isZero();
        assertThat(result.getContent()).isEmpty();
        verify(adRepository).findAllByAuthorId(userId, PageRequest.of(0, 10));
    }

    @Test
    void getAdsByUser_ShouldSupportPagination_WhenUserHasMultipleAds() {
        UUID userId = UUID.fromString("8d5cfe7c-1e1b-4a1e-b8f0-111111111111");
        UserDetails userDetails = mock(UserDetails.class);
        when(userDetails.getUsername()).thenReturn(userId.toString());

        Ad ad = new Ad();
        ad.setId(UUID.randomUUID());
        ad.setTitle("iPhone 13");
        ad.setDescription("Almost new");
        ad.setPrice(500.0);
        ad.setCondition(Condition.USED);
        ad.setStatus(Status.ACTIVE);
        ad.setExpiresAt(Instant.now().plus(30, ChronoUnit.DAYS));
        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setEmail("contact1@example.com");
        contactInfo.setPhoneNumber("+385911234567");
        ad.setContactInfo(contactInfo);
        Category category = new Category();
        category.setName("Electronics");
        ad.setCategory(category);
        ad.setImages(new ArrayList<>());
        ad.setLocation(null);

        Page<Ad> adsPage = new PageImpl<>(List.of(ad), PageRequest.of(0, 1), 5);
        when(adRepository.findAllByAuthorId(userId, PageRequest.of(0, 1))).thenReturn(adsPage);

        Page<AdResponse> result = adService.getAdsByUser(userDetails, PageRequest.of(0, 1));

        assertThat(result.getTotalElements()).isEqualTo(5);
        assertThat(result.getSize()).isEqualTo(1);
        assertThat(result.getContent()).hasSize(1);
        verify(adRepository).findAllByAuthorId(userId, PageRequest.of(0, 1));
    }

    @Test
    void getAdsByUser_ShouldMapToDTOCorrectly_WhenAdHasAllFields() {
        UUID userId = UUID.fromString("8d5cfe7c-1e1b-4a1e-b8f0-111111111111");
        UserDetails userDetails = mock(UserDetails.class);
        when(userDetails.getUsername()).thenReturn(userId.toString());

        Ad ad = new Ad();
        ad.setId(UUID.randomUUID());
        ad.setTitle("iPhone 13");
        ad.setDescription("Almost new, 128GB");
        ad.setPrice(500.0);
        ad.setCondition(Condition.USED);
        ad.setStatus(Status.ACTIVE);
        ad.setExpiresAt(Instant.now().plus(30, ChronoUnit.DAYS));
        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setEmail("contact1@example.com");
        contactInfo.setPhoneNumber("+385911234567");
        ad.setContactInfo(contactInfo);
        Category category = new Category();
        category.setName("Electronics");
        ad.setCategory(category);
        ad.setImages(new ArrayList<>());
        Location location = new Location();
        location.setAddress("Ilica 42, 10000 Zagreb");
        ad.setLocation(location);

        Page<Ad> adsPage = new PageImpl<>(List.of(ad));
        when(adRepository.findAllByAuthorId(userId, PageRequest.of(0, 10))).thenReturn(adsPage);

        Page<AdResponse> result = adService.getAdsByUser(userDetails, PageRequest.of(0, 10));

        AdResponse response = result.getContent().getFirst();
        assertThat(response.title()).isEqualTo("iPhone 13");
        assertThat(response.description()).isEqualTo("Almost new, 128GB");
        assertThat(response.price()).isEqualTo(500.0);
        assertThat(response.category()).isEqualTo("Electronics");
        assertThat(response.condition()).isEqualTo("USED");
        assertThat(response.status()).isEqualTo("ACTIVE");
        assertThat(response.contactInfo().email()).isEqualTo("contact1@example.com");
        assertThat(response.contactInfo().phoneNumber()).isEqualTo("+385911234567");
        assertThat(response.location()).isNotNull();
        assertThat(response.location().address()).isEqualTo("Ilica 42, 10000 Zagreb");
    }

    @Test
    void editAd_ShouldThrowDBException_WhenAdNotFound() {
        UUID adId = UUID.randomUUID();
        AdCreateRequest request = new AdCreateRequest();
        UserDetails userDetails = mock(UserDetails.class);

        when(adRepository.findByIdWithImages(adId)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> adService.editAd(adId, request, userDetails)).isInstanceOf(DBException.class).hasMessageContaining("Ad not found.");
    }

    @Test
    void editAd_ShouldThrowDBException_WhenAdExpiredForAdmin() {
        UUID adId = UUID.randomUUID();
        AdCreateRequest request = new AdCreateRequest();
        request.setImageIds(List.of());
        UserDetails userDetails = mock(UserDetails.class);
        when(userDetails.getUsername()).thenReturn(UUID.randomUUID().toString());

        Ad ad = new Ad();
        ad.setExpiresAt(Instant.now().minus(1, ChronoUnit.DAYS));

        User admin = mock(User.class);
        when(admin.getRole()).thenReturn(Role.ADMIN);

        when(adRepository.findByIdWithImages(adId)).thenReturn(Optional.of(ad));
        when(userRepository.findById(any())).thenReturn(Optional.of(admin));

        assertThatThrownBy(() -> adService.editAd(adId, request, userDetails)).isInstanceOf(DBException.class).hasMessageContaining("Ad has expired");
    }

    @Test
    void editAd_ShouldThrowDBException_WhenUserEditsAnotherUsersAd() {
        UUID adId = UUID.randomUUID();
        AdCreateRequest request = new AdCreateRequest();
        request.setImageIds(List.of());
        UserDetails userDetails = mock(UserDetails.class);

        UUID userId = UUID.randomUUID();
        UUID authorId = UUID.randomUUID();
        when(userDetails.getUsername()).thenReturn(userId.toString());

        User authorUser = mock(User.class);
        when(authorUser.getId()).thenReturn(authorId);

        Ad ad = new Ad();
        ad.setAuthor(authorUser);

        when(adRepository.findByIdWithImages(adId)).thenReturn(Optional.of(ad));
        when(userRepository.findById(any())).thenReturn(Optional.of(mock(User.class)));

        assertThatThrownBy(() -> adService.editAd(adId, request, userDetails)).isInstanceOf(DBException.class).hasMessageContaining("You can only edit your own ads.");
    }

    @Test
    void editAd_ShouldUpdateAd_WhenAdminEditsValidAd() {
        UUID adId = UUID.randomUUID();

        Location location = new Location();
        location.setId(UUID.randomUUID());
        location.setAddress("Strojarska ulica 22, 10000 Zagreb");

        AdCreateRequest request = new AdCreateRequest();
        request.setLocation(location);
        request.setTitle("Updated Title");
        request.setImageIds(List.of());
        request.setDescription("Updated Description");
        request.setPrice(500.0);
        request.setCondition(Condition.USED);

        UserDetails userDetails = mock(UserDetails.class);
        UUID adminId = UUID.randomUUID();
        when(userDetails.getUsername()).thenReturn(adminId.toString());

        User admin = mock(User.class);
        when(admin.getRole()).thenReturn(Role.ADMIN);

        Ad ad = new Ad();
        ad.setId(adId);
        ad.setExpiresAt(Instant.now().plus(1, ChronoUnit.DAYS));
        ad.setStatus(Status.ACTIVE);
        ad.setCondition(Condition.NEW);
        ad.setImages(new ArrayList<>());
        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setId(UUID.randomUUID());
        contactInfo.setEmail("admin@example.com");
        contactInfo.setPhoneNumber("+385911111111");
        ad.setContactInfo(contactInfo);
        Category category = new Category();
        category.setName("Category");
        ad.setCategory(category);
        ad.setLocation(location);

        when(adRepository.findByIdWithImages(adId)).thenReturn(Optional.of(ad));
        when(categoryRepository.findByIdAndActiveIsTrue(category.getId())).thenReturn(Optional.of(category));
        when(contactInfoRepository.findById(any())).thenReturn(Optional.of(contactInfo));
        when(locationService.findByAddress(any())).thenReturn(Optional.of(location));
        when(locationService.addLocation(any())).thenReturn(location);
        when(userRepository.findById(any())).thenReturn(Optional.of(admin));
        when(adRepository.saveAndFlush(any())).thenReturn(ad);
        when(adRepository.findByIdWithImages(adId)).thenReturn(Optional.of(ad));

        AdResponse response = adService.editAd(adId, request, userDetails);

        assertThat(response).isNotNull();
        assertThat(response.title()).isEqualTo("Updated Title");
        verify(adRepository).saveAndFlush(ad);
    }

    @Test
    void editAd_ShouldUpdateAdAndReactivate_WhenUserEditsExpiredAd() {
        UUID adId = UUID.randomUUID();

        Location location = new Location();
        location.setId(UUID.randomUUID());
        location.setAddress("Strojarska ulica 22, 10000 Zagreb");

        AdCreateRequest request = new AdCreateRequest();
        request.setTitle("Updated Title");
        request.setImageIds(List.of());
        request.setLocation(location);
        request.setDescription("Updated Description");
        request.setPrice(500.0);
        request.setCondition(Condition.USED);

        UserDetails userDetails = mock(UserDetails.class);
        UUID userId = UUID.randomUUID();
        when(userDetails.getUsername()).thenReturn(userId.toString());

        User user = mock(User.class);

        User authorUser = mock(User.class);
        when(authorUser.getId()).thenReturn(userId);

        Ad ad = new Ad();
        ad.setId(adId);
        ad.setExpiresAt(Instant.now().minus(1, ChronoUnit.DAYS));
        ad.setStatus(Status.EXPIRED);
        ad.setAuthor(authorUser);
        ad.setCondition(Condition.USED);
        ad.setImages(new ArrayList<>());
        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setId(UUID.randomUUID());
        contactInfo.setEmail("user@example.com");
        contactInfo.setPhoneNumber("+385922222222");
        ad.setContactInfo(contactInfo);
        Category category = new Category();
        category.setName("Category");
        ad.setCategory(category);
        ad.setLocation(location);

        when(adRepository.findByIdWithImages(adId)).thenReturn(Optional.of(ad));
        when(categoryRepository.findByIdAndActiveIsTrue(category.getId())).thenReturn(Optional.of(category));
        when(contactInfoRepository.findById(any())).thenReturn(Optional.of(contactInfo));
        when(locationService.findByAddress(any())).thenReturn(Optional.of(location));
        when(locationService.addLocation(any())).thenReturn(location);
        when(userRepository.findById(any())).thenReturn(Optional.of(user));
        when(adRepository.saveAndFlush(any())).thenReturn(ad);
        when(adRepository.findByIdWithImages(adId)).thenReturn(Optional.of(ad));

        AdResponse response = adService.editAd(adId, request, userDetails);

        assertThat(response).isNotNull();
        assertThat(response.title()).isEqualTo("Updated Title");
        assertThat(ad.getStatus()).isEqualTo(Status.ACTIVE);
        assertThat(ad.getExpiresAt()).isAfter(Instant.now());
        verify(adRepository).saveAndFlush(ad);
    }

    @Test
    void createAndSendRenewalTokenEmail_ShouldSendEmail_WhenAdExists() throws IOException {
        UUID adId = UUID.randomUUID();
        Ad ad = new Ad();
        ad.setId(adId);
        ad.setTitle("Expired Ad");
        ad.setExpiresAt(Instant.now().minus(1, ChronoUnit.DAYS));
        User author = new User.Builder().id(UUID.randomUUID()).name("John Doe").email("john.doe@example.com").build();
        ad.setAuthor(author);

        DefaultOneTimeToken token = new DefaultOneTimeToken("tokenValue", adId.toString(), Instant.now().plus(3, ChronoUnit.DAYS));


        when(adRepository.findByIdWithImages(adId)).thenReturn(Optional.of(ad));
        when(ottService.generate(any())).thenReturn(token);

        adService.createAndSendRenewalTokenEmail(adId);

        ArgumentCaptor<Map<String, Object>> dynamicDataCaptor = ArgumentCaptor.forClass(Map.class);
        verify(emailSenderService).sendEmail(eq("john.doe@example.com"), eq("d-948fe5bf407b4869ac1693fe1af7c316"), dynamicDataCaptor.capture());

        Map<String, Object> dynamicData = dynamicDataCaptor.getValue();
        assertThat(dynamicData)
                .containsEntry("username", "John Doe")
                .containsEntry("title", "Expired Ad")
                .containsKey("renewLink");
        assertThat(dynamicData.get("renewLink").toString()).contains("tokenValue");
    }

    @Test
    void createAndSendRenewalTokenEmail_ShouldThrowDBException_WhenAdNotFound() {
        UUID adId = UUID.randomUUID();

        when(adRepository.findByIdWithImages(adId)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> adService.createAndSendRenewalTokenEmail(adId)).isInstanceOf(DBException.class).hasMessageContaining("Ad not found.");
    }

    @Test
    void createAndSendRenewalTokenEmail_ShouldThrowEmailException_WhenEmailFails() throws IOException {
        UUID adId = UUID.randomUUID();
        Ad ad = new Ad();
        ad.setId(adId);
        ad.setTitle("Expired Ad");
        ad.setExpiresAt(Instant.now().minus(1, ChronoUnit.DAYS));
        User author = new User.Builder().id(UUID.randomUUID()).name("John Doe").email("john.doe@example.com").build();
        ad.setAuthor(author);

        DefaultOneTimeToken token = new DefaultOneTimeToken("tokenValue", adId.toString(), Instant.now().plus(3, ChronoUnit.DAYS));

        when(renewalConfigurationProperties.getUrl()).thenReturn("https://shae-burthensome-gratefully.ngrok-free.dev");
        when(adRepository.findByIdWithImages(adId)).thenReturn(Optional.of(ad));
        when(ottService.generate(any())).thenReturn(token);
        doThrow(new IOException("Email sending failed")).when(emailSenderService).sendEmail(any(), any(), any());

        assertThatThrownBy(() -> adService.createAndSendRenewalTokenEmail(adId)).isInstanceOf(EmailException.class).hasMessageContaining("Failed to send renewal email.");
    }

    @Test
    void reportAd_ValidAdAndRequest_ReturnsSavedAdReport() {
        UUID adId = UUID.randomUUID();
        Ad ad = new Ad();
        ad.setId(adId);
        ad.setTitle("Sample Ad");

        AdReportCreateRequest request = new AdReportCreateRequest(AdReportType.SPAM, "Inappropriate content");

        AdReport savedReport = new AdReport();
        savedReport.setId(UUID.randomUUID());
        savedReport.setAd(ad);
        savedReport.setType(AdReportType.SPAM);
        savedReport.setReason("Inappropriate content");
        savedReport.setCreatedAt(Instant.now());

        when(adRepository.findById(adId)).thenReturn(Optional.of(ad));
        when(userRepository.findAllByRole(Role.ADMIN)).thenReturn(List.of(new User.Builder().id(UUID.randomUUID()).role(Role.ADMIN).email("admin@admin.com").build()));
        when(adReportRepository.save(any(AdReport.class))).thenReturn(savedReport);
        when(adReportConfigurationProperties.getUrl()).thenReturn("https://shae-burthensome-gratefully.ngrok-free.dev");

        AdReport result = adService.reportAd(adId, request);

        assertThat(result).isNotNull();
        assertThat(result.getAd()).isEqualTo(ad);
        assertThat(result.getType()).hasToString("SPAM");
        assertThat(result.getReason()).isEqualTo("Inappropriate content");
    }

    @Test
    void reportAd_NonExistentAd_ThrowsDBException() {
        UUID adId = UUID.randomUUID();
        AdReportCreateRequest request = new AdReportCreateRequest(AdReportType.SPAM, "Inappropriate content");

        when(adRepository.findById(adId)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> adService.reportAd(adId, request)).isInstanceOf(DBException.class).hasMessageContaining("Ad not found.");
    }

    @Test
    void getAdReportByAdId_ValidAdminUser_ReturnsUpdatedAdReport() {
        UUID reportId = UUID.randomUUID();
        UUID adminId = UUID.randomUUID();
        User admin = new User.Builder()
                .id(adminId)
                .role(Role.ADMIN).build();

        AdReport report = new AdReport();
        report.setId(reportId);

        when(userRepository.findById(adminId)).thenReturn(Optional.of(admin));
        when(adReportRepository.findById(reportId)).thenReturn(Optional.of(report));
        when(adReportRepository.save(any(AdReport.class))).thenReturn(report);

        UserDetails userDetails = mock(UserDetails.class);
        when(userDetails.getUsername()).thenReturn(adminId.toString());

        AdReport result = adService.resolveAdReport(reportId, userDetails);

        assertThat(result).isNotNull();
        assertThat(result.getReviewedBy()).isEqualTo(admin);
        assertThat(result.getReviewedAt()).isNotNull();
    }

    @Test
    void getAdReportByAdId_NonExistentReport_ThrowsDBException() {
        UUID reportId = UUID.randomUUID();
        UUID adminId = UUID.randomUUID();
        User admin = new User.Builder()
                .id(adminId)
                .role(Role.ADMIN).build();

        when(userRepository.findById(adminId)).thenReturn(Optional.of(admin));
        when(adReportRepository.findById(reportId)).thenReturn(Optional.empty());

        UserDetails userDetails = mock(UserDetails.class);
        when(userDetails.getUsername()).thenReturn(adminId.toString());

        assertThatThrownBy(() -> adService.resolveAdReport(reportId, userDetails)).isInstanceOf(DBException.class).hasMessageContaining("Ad report not found.");
    }

}
