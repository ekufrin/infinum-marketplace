package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.config.SecurityConfiguration;
import com.ekufrin.infinum.marketplace.controller.OwnAdsController;
import com.ekufrin.infinum.marketplace.dto.AdResponse;
import com.ekufrin.infinum.marketplace.service.AdService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Objects;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = OwnAdsController.class, excludeAutoConfiguration = {SecurityConfiguration.class})
@AutoConfigureMockMvc(addFilters = false)
class OwnAdsControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockitoBean
    private AdService adService;
    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111")
    void getMyAds_AuthenticatedUser_ShouldReturnUsersAds() throws Exception {
        Pageable pageable = PageRequest.of(0, 10);
        AdResponse ad1 = mock(AdResponse.class);
        Page<AdResponse> adsPage = new PageImpl<>(List.of(ad1), pageable, 1);

        when(adService.getAdsByUser(any(), any(Pageable.class))).thenReturn(adsPage);

        mockMvc.perform(get("/users/me/ads"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content.length()").value(1))
                .andExpect(jsonPath("$.totalElements").value(1))
                .andExpect(jsonPath("$.totalPages").value(1))
                .andExpect(jsonPath("$.size").value(10))
                .andExpect(jsonPath("$.page").value(1));

        verify(adService).getAdsByUser(any(), any(Pageable.class));
    }

    @Test
    @WithMockUser(username = "f1a6b9e3-483b-41b7-81db-666666666666")
    void getMyAds_UserWithNoAds_ShouldReturnEmptyPage() throws Exception {
        Pageable pageable = PageRequest.of(0, 20);
        Page<AdResponse> emptyPage = new PageImpl<>(List.of(), pageable, 0);

        when(adService.getAdsByUser(any(), any(Pageable.class))).thenReturn(emptyPage);

        mockMvc.perform(get("/users/me/ads"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content").isEmpty())
                .andExpect(jsonPath("$.totalElements").value(0))
                .andExpect(jsonPath("$.totalPages").value(0))
                .andExpect(jsonPath("$.size").value(20))
                .andExpect(jsonPath("$.page").value(1));

        verify(adService).getAdsByUser(any(), any(Pageable.class));
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111")
    void getMyAds_SortParameter_ShouldApplySorting() throws Exception {
        AdResponse ad1 = mock(AdResponse.class);
        Page<AdResponse> adsPage = new PageImpl<>(List.of(ad1));

        when(adService.getAdsByUser(any(), any(Pageable.class))).thenReturn(adsPage);

        mockMvc.perform(get("/users/me/ads")
                        .param("sort", "title,asc"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content.length()").value(1));

        ArgumentCaptor<Pageable> pageableCaptor = ArgumentCaptor.forClass(Pageable.class);
        verify(adService).getAdsByUser(any(), pageableCaptor.capture());

        Pageable capturedPageable = pageableCaptor.getValue();
        assertThat(capturedPageable.getSort().getOrderFor("title")).isNotNull();
        assertThat(Objects.requireNonNull(capturedPageable.getSort().getOrderFor("title")).isAscending()).isTrue();
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111")
    void getMyAds_NoSortParameter_ShouldApplyDefaultSorting() throws Exception {
        Page<AdResponse> emptyPage = new PageImpl<>(List.of());

        when(adService.getAdsByUser(any(), any(Pageable.class))).thenReturn(emptyPage);

        mockMvc.perform(get("/users/me/ads"))
                .andExpect(status().isOk());

        ArgumentCaptor<Pageable> pageableCaptor = ArgumentCaptor.forClass(Pageable.class);
        verify(adService).getAdsByUser(any(), pageableCaptor.capture());

        Pageable capturedPageable = pageableCaptor.getValue();
        assertThat(capturedPageable.getSort().getOrderFor("status")).isNotNull();
        assertThat(Objects.requireNonNull(capturedPageable.getSort().getOrderFor("status")).getDirection())
                .isEqualTo(Sort.Direction.DESC);
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111")
    void getMyAds_PageParameters_ShouldApplyPagination() throws Exception {
        Pageable pageable = PageRequest.of(1, 2);
        AdResponse ad1 = mock(AdResponse.class);
        AdResponse ad2 = mock(AdResponse.class);
        Page<AdResponse> adsPage = new PageImpl<>(List.of(ad1, ad2), pageable, 10);

        when(adService.getAdsByUser(any(), any(Pageable.class))).thenReturn(adsPage);

        mockMvc.perform(get("/users/me/ads")
                        .param("page", "1")
                        .param("size", "2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content.length()").value(2))
                .andExpect(jsonPath("$.totalElements").value(10))
                .andExpect(jsonPath("$.totalPages").value(5))
                .andExpect(jsonPath("$.size").value(2))
                .andExpect(jsonPath("$.page").value(2));

        ArgumentCaptor<Pageable> pageableCaptor = ArgumentCaptor.forClass(Pageable.class);
        verify(adService).getAdsByUser(any(), pageableCaptor.capture());

        Pageable capturedPageable = pageableCaptor.getValue();
        assertThat(capturedPageable.getPageNumber()).isEqualTo(1);
        assertThat(capturedPageable.getPageSize()).isEqualTo(2);
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111")
    void getMyAds_UserWithMultipleAds_ShouldReturnAllAds() throws Exception {
        Pageable pageable = PageRequest.of(0, 20);
        AdResponse ad1 = mock(AdResponse.class);
        AdResponse ad2 = mock(AdResponse.class);
        AdResponse ad3 = mock(AdResponse.class);
        Page<AdResponse> adsPage = new PageImpl<>(List.of(ad1, ad2, ad3), pageable, 3);

        when(adService.getAdsByUser(any(), any(Pageable.class))).thenReturn(adsPage);

        mockMvc.perform(get("/users/me/ads"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content.length()").value(3))
                .andExpect(jsonPath("$.totalElements").value(3))
                .andExpect(jsonPath("$.totalPages").value(1));

        verify(adService).getAdsByUser(any(), any(Pageable.class));
    }
}