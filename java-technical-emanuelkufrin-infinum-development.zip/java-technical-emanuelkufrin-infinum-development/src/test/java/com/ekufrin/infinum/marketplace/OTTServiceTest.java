package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.model.OTT;
import com.ekufrin.infinum.marketplace.repository.OTTRepository;
import com.ekufrin.infinum.marketplace.service.OTTService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.ott.GenerateOneTimeTokenRequest;
import org.springframework.security.authentication.ott.OneTimeToken;
import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationToken;

import java.time.Duration;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OTTServiceTest {

    @Mock
    private OTTRepository ottRepository;

    @InjectMocks
    private OTTService ottService;

    @Test
    void generate_ShouldReturnToken_WhenRequestIsValid() {
        GenerateOneTimeTokenRequest request = new GenerateOneTimeTokenRequest("username", Duration.ofMinutes(10));
        OTT savedToken = new OTT();
        savedToken.setId(UUID.randomUUID());
        savedToken.setValue("username");
        savedToken.setExpiresAt(Instant.now().plus(Duration.ofMinutes(10)));

        when(ottRepository.save(any(OTT.class))).thenReturn(savedToken);

        OneTimeToken result = ottService.generate(request);

        assertThat(result).isNotNull();
        assertThat(result.getUsername()).isEqualTo(savedToken.getValue());
        assertThat(result.getExpiresAt()).isEqualTo(savedToken.getExpiresAt());
    }

    @Test
    void consume_ShouldReturnTokenAndDeleteIt_WhenTokenIsValid() {
        UUID tokenId = UUID.randomUUID();
        OneTimeTokenAuthenticationToken authenticationToken = new OneTimeTokenAuthenticationToken(tokenId.toString());
        OTT token = new OTT();
        token.setId(tokenId);
        token.setValue("username");
        token.setExpiresAt(Instant.now().plus(Duration.ofMinutes(10)));

        when(ottRepository.findById(tokenId)).thenReturn(Optional.of(token));

        OneTimeToken result = ottService.consume(authenticationToken);

        assertThat(result).isNotNull();
        assertThat(result.getUsername()).isEqualTo(token.getValue());
        verify(ottRepository).delete(token);
    }

    @Test
    void consume_ShouldThrowException_WhenTokenIsExpired() {
        UUID tokenId = UUID.randomUUID();
        OneTimeTokenAuthenticationToken authenticationToken = new OneTimeTokenAuthenticationToken(tokenId.toString());
        OTT token = new OTT();
        token.setId(tokenId);
        token.setValue("username");
        token.setExpiresAt(Instant.now().minus(Duration.ofMinutes(10)));

        when(ottRepository.findById(tokenId)).thenReturn(Optional.of(token));

        assertThatThrownBy(() -> ottService.consume(authenticationToken))
                .isInstanceOf(DBException.class)
                .hasMessage("Invalid or expired OTT");

        verify(ottRepository, never()).delete(any());
    }

    @Test
    void consume_ShouldThrowException_WhenTokenDoesNotExist() {
        UUID tokenId = UUID.randomUUID();
        OneTimeTokenAuthenticationToken authenticationToken = new OneTimeTokenAuthenticationToken(tokenId.toString());

        when(ottRepository.findById(tokenId)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> ottService.consume(authenticationToken))
                .isInstanceOf(DBException.class)
                .hasMessage("Invalid or expired OTT");

        verify(ottRepository, never()).delete(any());
    }
}

