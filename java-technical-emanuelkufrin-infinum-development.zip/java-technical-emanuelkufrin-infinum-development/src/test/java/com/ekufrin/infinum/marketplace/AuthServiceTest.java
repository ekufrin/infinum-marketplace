package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.exception.EmailException;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.repository.UserRepository;
import com.ekufrin.infinum.marketplace.service.AuthService;
import com.ekufrin.infinum.marketplace.service.EmailSenderService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.ott.DefaultOneTimeToken;
import org.springframework.security.authentication.ott.GenerateOneTimeTokenRequest;
import org.springframework.security.authentication.ott.OneTimeToken;
import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationToken;
import org.springframework.security.authentication.ott.OneTimeTokenService;

import java.io.IOException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @InjectMocks
    private AuthService authService;

    @Mock
    private UserRepository userRepository;

    @Mock
    private OneTimeTokenService oneTimeTokenService;

    @Mock
    private EmailSenderService emailSenderService;

    @Test
    void existingUser_createAndSendOTTokenEmail_sendsEmail() throws Exception {
        User user = new User.Builder()
                .id(UUID.randomUUID())
                .email("test@example.com")
                .username("testUser")
                .build();

        OneTimeToken token = new DefaultOneTimeToken("sampleToken", user.getId().toString(), Instant.now().plus(1, ChronoUnit.DAYS));

        when(userRepository.findByEmail("test@example.com")).thenReturn(Optional.of(user));
        when(oneTimeTokenService.generate(any(GenerateOneTimeTokenRequest.class))).thenReturn(token);

        authService.createAndSendOTTokenEmail("test@example.com");

        verify(emailSenderService).sendEmail(eq("test@example.com"), eq("d-7c797cde2ec24e6988e2633ef40ca76d"), anyMap());
    }

    @Test
    void nonExistentUser_createAndSendOTTokenEmail_throwsDBException() {
        when(userRepository.findByEmail("nonexistent@example.com")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> authService.createAndSendOTTokenEmail("nonexistent@example.com"))
                .isInstanceOf(DBException.class)
                .hasMessage("User not found");
    }

    @Test
    void existingUser_createAndSendOTTokenEmail_whenEmailSendFails_throwsEmailException() throws Exception {
        User user = new User.Builder()
                .id(UUID.randomUUID())
                .email("test@example.com")
                .username("testUser")
                .build();

        OneTimeToken token = new DefaultOneTimeToken("sampleToken", user.getId().toString(), Instant.now().plus(1, ChronoUnit.DAYS));

        when(userRepository.findByEmail("test@example.com")).thenReturn(Optional.of(user));
        when(oneTimeTokenService.generate(any(GenerateOneTimeTokenRequest.class))).thenReturn(token);
        doThrow(new IOException("Email sending failed")).when(emailSenderService).sendEmail(anyString(), anyString(), anyMap());

        assertThatThrownBy(() -> authService.createAndSendOTTokenEmail("test@example.com"))
                .isInstanceOf(EmailException.class)
                .hasMessage("Failed to send OTT login email.");
    }

    @Test
    void validOneTimeToken_validateOTTLogin_returnsUser() {
        OneTimeToken token = new DefaultOneTimeToken("sampleToken", UUID.randomUUID().toString(), Instant.now().plus(1, ChronoUnit.DAYS));

        User user = new User.Builder()
                .id(UUID.fromString(token.getUsername()))
                .build();

        when(oneTimeTokenService.consume(any(OneTimeTokenAuthenticationToken.class))).thenReturn(token);
        when(userRepository.findById(UUID.fromString(token.getUsername()))).thenReturn(Optional.of(user));

        User result = authService.validateOTTLogin(new OneTimeTokenAuthenticationToken("sampleToken"));

        assertThat(result).isEqualTo(user);
    }

    @Test
    void invalidOneTimeToken_validateOTTLogin_throwsAssertionError() {
        when(oneTimeTokenService.consume(any(OneTimeTokenAuthenticationToken.class))).thenReturn(null);

        assertThatThrownBy(() -> authService.validateOTTLogin(new OneTimeTokenAuthenticationToken("invalidToken")))
                .isInstanceOf(AssertionError.class);
    }

    @Test
    void validOneTimeToken_userMissing_validateOTTLogin_throwsDBException() {
        OneTimeToken token = new DefaultOneTimeToken("sampleToken", UUID.randomUUID().toString(), Instant.now().plus(1, ChronoUnit.DAYS));

        when(oneTimeTokenService.consume(any(OneTimeTokenAuthenticationToken.class))).thenReturn(token);
        when(userRepository.findById(UUID.fromString(token.getUsername()))).thenReturn(Optional.empty());

        assertThatThrownBy(() -> authService.validateOTTLogin(new OneTimeTokenAuthenticationToken("sampleToken")))
                .isInstanceOf(DBException.class)
                .hasMessage("User not found");
    }

}

