package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.controller.AdReportController;
import com.ekufrin.infinum.marketplace.enums.AdReportType;
import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.model.AdReport;
import com.ekufrin.infinum.marketplace.service.AdReportService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(value = AdReportController.class, excludeAutoConfiguration = SecurityAutoConfiguration.class)
class AdReportControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockitoBean
    private AdReportService adReportService;

    @Test
    void getAllAdReports_returnsPagedResponse_whenReportsExist() throws Exception {
        AdReport adReport1 = new AdReport();
        adReport1.setId(UUID.randomUUID());
        adReport1.setType(AdReportType.SPAM);
        adReport1.setReason("Test reason");
        AdReport adReport2 = new AdReport();
        adReport2.setId(UUID.randomUUID());
        adReport2.setType(AdReportType.INAPPROPRIATE_CONTENT);
        adReport2.setReason("Another test reason");
        Page<AdReport> adReports = new PageImpl<>(List.of(adReport1, adReport2));

        when(adReportService.getAllAdReports(any(Pageable.class))).thenReturn(adReports);


        mockMvc.perform(get("/ad-reports")
                        .param("page", "0")
                        .param("size", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content.length()").value(2));
    }

    @Test
    void getAllAdReports_returnsEmptyPagedResponse_whenNoReportsExist() throws Exception {
        Pageable pageable = PageRequest.of(0, 10);
        Page<AdReport> adReports = Page.empty();

        when(adReportService.getAllAdReports(pageable)).thenReturn(adReports);

        mockMvc.perform(get("/ad-reports")
                        .param("page", "0")
                        .param("size", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isEmpty());
    }

    @Test
    void getAdReportById_returnsAdReport_whenIdExists() throws Exception {
        UUID adReportId = UUID.randomUUID();
        AdReport adReport = new AdReport();
        adReport.setId(adReportId);
        adReport.setType(AdReportType.SPAM);
        adReport.setReason("Test reason");

        when(adReportService.getAdReportById(adReportId)).thenReturn(adReport);

        mockMvc.perform(get("/ad-reports/{id}", adReportId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(adReportId.toString()))
                .andExpect(jsonPath("$.type").value("SPAM"))
                .andExpect(jsonPath("$.reason").value("Test reason"));
    }

    @Test
    void getAdReportById_returnsNotFound_whenIdDoesNotExist() throws Exception {
        UUID nonExistentId = UUID.randomUUID();

        when(adReportService.getAdReportById(nonExistentId)).thenThrow(new DBException("AdReport not found"));

        mockMvc.perform(get("/ad-reports/{id}", nonExistentId))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.error").value("Not Found"));
    }

}
