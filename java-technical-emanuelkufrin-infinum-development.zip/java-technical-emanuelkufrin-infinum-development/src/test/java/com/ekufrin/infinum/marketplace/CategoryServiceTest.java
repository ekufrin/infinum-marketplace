package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.dto.CategoryChangeRequest;
import com.ekufrin.infinum.marketplace.dto.CategoryCreateRequest;
import com.ekufrin.infinum.marketplace.exception.AlreadyExistsInDB;
import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.model.Category;
import com.ekufrin.infinum.marketplace.repository.CategoryRepository;
import com.ekufrin.infinum.marketplace.service.CategoryService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CategoryServiceTest {
    @Mock
    private CategoryRepository categoryRepository;
    @InjectMocks
    private CategoryService categoryService;

    @Test
    void addCategory_ValidArgumentGiven_ShouldAddCategory() {
        CategoryCreateRequest request = new CategoryCreateRequest("NewCategory", false);
        Category category = new Category();
        category.setName("NewCategory");
        category.setActive(false);

        when(categoryRepository.save(any(Category.class))).thenReturn(category);

        Category response = categoryService.addCategory(request);

        assertThat(response.getName()).isEqualTo("NewCategory");
        assertThat(response.getActive()).isFalse();
    }

    @Test
    void addCategory_InvalidArgumentGiven_ShouldReturnNull() {
        CategoryCreateRequest request = new CategoryCreateRequest("", false);

        Category response = categoryService.addCategory(request);

        assertThat(response).isNull();
    }

    @Test
    void addCategory_DuplicateNameGiven_ShouldThrowAlreadyExistsInDB() {
        CategoryCreateRequest request = new CategoryCreateRequest("Electronics", true);

        try {
            categoryService.addCategory(request);
        } catch (AlreadyExistsInDB e) {
            assertThat(e.getMessage()).isEqualTo("Electronics already exists.");
        }
    }

    @Test
    void getAllCategories_ShouldReturnListOfCategoriesAsPageWithFilterAndSorting() {
        Page<Category> categoryPage = new PageImpl<>(List.of(
                new Category(UUID.randomUUID(), "Electronics", true, Instant.now(), null),
                new Category(UUID.randomUUID(), "Books", true, Instant.now(), null),
                new Category(UUID.randomUUID(), "Clothing", false, Instant.now(), null)
        ));
        Pageable pageable = PageRequest.of(0, 10);
        when(categoryService.getAllCategoriesAsPageWithFilterAndSorting("", null, pageable)).thenReturn(categoryPage);
        var response = categoryService.getAllCategoriesAsPageWithFilterAndSorting("", null, pageable);

        assertThat(response).isNotNull();
        assertThat(response.getTotalElements()).isEqualTo(3);
        assertThat(response.getContent().get(0).getName()).isEqualTo("Electronics");
        assertThat(response.getContent().get(1).getName()).isEqualTo("Books");
        assertThat(response.getContent().get(2).getName()).isEqualTo("Clothing");
        assertThat(response.getContent().get(0).getActive()).isTrue();
    }

    @Test
    void getAllCategories_SizeTwo_ShouldReturnListOfTwoCategoriesAsPageWithFilterAndSorting() {
        Page<Category> categoryPage = new PageImpl<>(List.of(
                new Category(UUID.randomUUID(), "Electronics", true, Instant.now(), null),
                new Category(UUID.randomUUID(), "Books", true, Instant.now(), null),
                new Category(UUID.randomUUID(), "Clothing", false, Instant.now(), null)
        ), PageRequest.of(0, 2), 3);
        Pageable pageable = PageRequest.of(0, 2);
        when(categoryService.getAllCategoriesAsPageWithFilterAndSorting("", null, pageable)).thenReturn(categoryPage);
        var response = categoryService.getAllCategoriesAsPageWithFilterAndSorting("", null, pageable);

        assertThat(response).isNotNull();
        assertThat(response.getNumberOfElements()).isEqualTo(3);
        assertThat(response.getSize()).isEqualTo(2);
        assertThat(response.getContent().get(0).getName()).isEqualTo("Electronics");
        assertThat(response.getContent().get(1).getName()).isEqualTo("Books");
        assertThat(response.getContent().get(0).getActive()).isTrue();
    }

    @Test
    void getAllCategories_ShouldReturnEmptyList() {
        Page<Category> categoryPage = new PageImpl<>(new ArrayList<>());
        Pageable pageable = PageRequest.of(0, 10);

        when(categoryService.getAllCategoriesAsPageWithFilterAndSorting("", null, pageable)).thenReturn(categoryPage);
        var response = categoryService.getAllCategoriesAsPageWithFilterAndSorting("", null, pageable);

        assertThat(response).isNotNull();
        assertThat(response.getTotalElements()).isZero();
    }

    @Test
    void getAllCategories_WithSearch_ShouldReturnFilteredCategories() {
        Page<Category> categoryPage = new PageImpl<>(List.of(
                new Category(UUID.randomUUID(), "Electronics", true, Instant.now(), null)
        ));
        Pageable pageable = PageRequest.of(0, 10);
        when(categoryService.getAllCategoriesAsPageWithFilterAndSorting("Electro", null, pageable)).thenReturn(categoryPage);

        var response = categoryService.getAllCategoriesAsPageWithFilterAndSorting("Electro", null, pageable);

        assertThat(response).isNotNull();
        assertThat(response.getTotalElements()).isEqualTo(1);
        assertThat(response.getContent().getFirst().getName()).isEqualTo("Electronics");
    }

    @Test
    void getAllCategories_WithStatus_ShouldReturnFilteredCategories() {
        Page<Category> categoryPage = new PageImpl<>(List.of(
                new Category(UUID.randomUUID(), "Electronics", true, Instant.now(), null),
                new Category(UUID.randomUUID(), "Books", true, Instant.now(), null)
        ));
        Pageable pageable = PageRequest.of(0, 10);
        when(categoryService.getAllCategoriesAsPageWithFilterAndSorting("", true, pageable)).thenReturn(categoryPage);

        var response = categoryService.getAllCategoriesAsPageWithFilterAndSorting("", true, pageable);

        assertThat(response).isNotNull();
        assertThat(response.getTotalElements()).isEqualTo(2);
        assertThat(response.getContent().stream().allMatch(Category::getActive)).isTrue();
    }


    @Test
    void updateCategoryName_ValidArgumentGiven_ShouldUpdateCategory() {
        UUID categoryId = UUID.fromString("11111111-1111-1111-1111-111111111111");
        CategoryChangeRequest request = new CategoryChangeRequest("Mobile Electronics", null);

        Category existingCategory = new Category(categoryId, "Electronics", true, Instant.now(), null);
        Category updatedCategory = new Category(categoryId, "Mobile Electronics", true, existingCategory.getCreatedAt(), null);

        when(categoryRepository.findById(categoryId)).thenReturn(java.util.Optional.of(existingCategory));
        when(categoryRepository.existsByNameIgnoreCase("Mobile Electronics")).thenReturn(false);
        when(categoryRepository.save(any(Category.class))).thenReturn(updatedCategory);

        Category response = categoryService.updateCategory(String.valueOf(categoryId), request);

        assertThat(response).isNotNull();
        assertThat(response.getId()).isEqualTo(categoryId);
        assertThat(response.getName()).isEqualTo("Mobile Electronics");
        assertThat(response.getActive()).isTrue();
    }

    @Test
    void updateCategoryName_DuplicateGiven_ShouldThrowAlreadyExistsInDB() {
        UUID categoryId = UUID.fromString("11111111-1111-1111-1111-111111111111");
        CategoryChangeRequest request = new CategoryChangeRequest("Books", null);
        when(categoryRepository.existsByNameIgnoreCase("Books")).thenReturn(true);

        try {
            categoryService.updateCategory(String.valueOf(categoryId), request);
        } catch (AlreadyExistsInDB e) {
            assertThat(e.getMessage()).isEqualTo("Books already exists.");
        }
    }

    @Test
    void updateCategory_InvalidIDGiven_ShouldThrowDBException() {
        UUID categoryId = UUID.randomUUID();
        CategoryChangeRequest request = new CategoryChangeRequest("Mobile Electronics", null);

        try {
            categoryService.updateCategory(String.valueOf(categoryId), request);
        } catch (DBException e) {
            assertThat(e.getMessage()).isEqualTo("Category not found");
        }
    }

    @Test
    void updateCategoryStatus_ValidArgumentGiven_ShouldUpdateCategoryStatus() {
        UUID categoryId = UUID.randomUUID();
        Category category = new Category(categoryId, "Electronics", true, Instant.now(), null);
        CategoryChangeRequest request = new CategoryChangeRequest(null, false);
        when(categoryRepository.findById(categoryId)).thenReturn(java.util.Optional.of(category));
        when(categoryService.updateCategory(String.valueOf(categoryId), request)).thenReturn(new Category(categoryId, "Electronics", false, category.getCreatedAt(), null));

        Category response = categoryService.updateCategory(String.valueOf(categoryId), request);

        assertThat(response).isNotNull();
        assertThat(response.getId()).isEqualTo(categoryId);
        assertThat(response.getName()).isEqualTo("Electronics");
        assertThat(response.getActive()).isFalse();
    }
}
