package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.model.TokenBlacklist;
import com.ekufrin.infinum.marketplace.repository.TokenBlacklistRepository;
import com.ekufrin.infinum.marketplace.service.TokenBlacklistService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TokenBlacklistServiceTest {
    @InjectMocks
    private TokenBlacklistService tokenBlacklistService;
    @Mock
    private TokenBlacklistRepository tokenBlacklistRepository;

    @Test
    void blacklistsTokenSuccessfully() {
        String token = "sampleToken";
        Instant expiresAt = Instant.now().plusSeconds(3600);

        tokenBlacklistService.blacklist(token, expiresAt);

        verify(tokenBlacklistRepository, times(1)).save(argThat(blacklist ->
                blacklist.getToken().equals(token) && blacklist.getExpiresAt().equals(expiresAt)));
    }

    @Test
    void returnsTrueWhenTokenIsBlacklisted() {
        String token = "blacklistedToken";
        when(tokenBlacklistRepository.existsByToken(token)).thenReturn(true);

        boolean result = tokenBlacklistService.isBlacklisted(token);

        assertThat(result).isTrue();
    }

    @Test
    void returnsFalseWhenTokenIsNotBlacklisted() {
        String token = "nonBlacklistedToken";
        when(tokenBlacklistRepository.existsByToken(token)).thenReturn(false);

        boolean result = tokenBlacklistService.isBlacklisted(token);

        assertThat(result).isFalse();
    }

    @Test
    void cleansUpExpiredTokens() {
        TokenBlacklist expiredToken1 = new TokenBlacklist();
        expiredToken1.setToken("expiredToken1");
        expiredToken1.setExpiresAt(Instant.now().minusSeconds(3600));
        TokenBlacklist expiredToken2 = new TokenBlacklist();
        expiredToken2.setToken("expiredToken2");
        expiredToken2.setExpiresAt(Instant.now().minusSeconds(1800));
        TokenBlacklist validToken = new TokenBlacklist();
        validToken.setToken("validToken");
        validToken.setExpiresAt(Instant.now().plusSeconds(3600));
        when(tokenBlacklistRepository.findAll()).thenReturn(List.of(expiredToken1, expiredToken2, validToken));
        tokenBlacklistService.cleanupExpired();

        verify(tokenBlacklistRepository, times(1)).deleteAll(argThat(iterable -> {
            List<TokenBlacklist> list = (List<TokenBlacklist>) iterable;
            return list.size() == 2 &&
                    list.contains(expiredToken1) &&
                    list.contains(expiredToken2) &&
                    !list.contains(validToken);
        }));
    }
}
