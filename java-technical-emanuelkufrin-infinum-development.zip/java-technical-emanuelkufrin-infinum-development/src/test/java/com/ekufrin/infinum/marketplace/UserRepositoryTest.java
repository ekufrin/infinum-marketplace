package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
class UserRepositoryTest {
    @Autowired
    private UserRepository userRepository;


    @Test
    void findByEmail_ValidArgumentGiven_ShouldReturnUser() {
        var user = userRepository.findByEmail("ivan.ivic@example.com");
        assertThat(user).isPresent();
        assertThat(user.get().getEmail()).isEqualTo("ivan.ivic@example.com");
        assertThat(user.get().getName()).isEqualTo("Ivan Ivić");
    }

    @Test
    void findByEmail_InvalidArgumentGiven_ShouldReturnEmpty() {
        var user = userRepository.findByEmail("test.test@test.com");
        assertThat(user).isNotPresent();
    }

    @Test
    void existsByEmail_IgnoreCase_ValidArgumentGiven_ShouldReturnTrue() {
        var exists = userRepository.existsByEmailIgnoreCase("ana.horvat@example.com");
        assertThat(exists).isTrue();
    }
}

