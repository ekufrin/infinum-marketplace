package com.ekufrin.infinum.marketplace;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
class AdReportControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @WithMockUser(username = "admin-user", roles = {"ADMIN"})
    void adminCanRetrievePagedAdReports_whenReportsExist() throws Exception {
        mockMvc.perform(get("/ad-reports")
                        .param("page", "0")
                        .param("size", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content.length()", greaterThanOrEqualTo(2)));
    }

    @Test
    @WithMockUser(username = "regular-user", roles = {"USER"})
    void nonAdminIsForbiddenFromAccessingAdReports() throws Exception {
        mockMvc.perform(get("/ad-reports")
                        .param("page", "0")
                        .param("size", "10"))
                .andExpect(status().isForbidden());
    }

    @Test
    void anonymousIsUnauthorizedWhenAccessingAdReports() throws Exception {
        mockMvc.perform(get("/ad-reports")
                        .param("page", "0")
                        .param("size", "10"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(username = "admin-user", roles = {"ADMIN"})
    void getAdReportById_returnsAdReport_whenIdExists() throws Exception {
        UUID id = UUID.fromString("22222222-2222-2222-2222-222222222222");

        mockMvc.perform(get("/ad-reports/{id}", id))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(id.toString()))
                .andExpect(jsonPath("$.type").value("SPAM"))
                .andExpect(jsonPath("$.reason").value("Duplicate listing across categories"));
    }

    @Test
    @WithMockUser(username = "admin-user", roles = {"ADMIN"})
    void getAdReportById_returnsNotFound_whenIdDoesNotExist() throws Exception {
        UUID nonExistent = UUID.randomUUID();

        mockMvc.perform(get("/ad-reports/{id}", nonExistent))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.error").value("Not Found"));
    }
}
