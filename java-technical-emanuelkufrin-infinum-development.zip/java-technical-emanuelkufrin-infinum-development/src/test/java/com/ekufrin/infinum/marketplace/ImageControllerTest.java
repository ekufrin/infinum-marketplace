package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.controller.ImageController;
import com.ekufrin.infinum.marketplace.dto.ImageResponse;
import com.ekufrin.infinum.marketplace.service.ImageService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@WebMvcTest(controllers = ImageController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
class ImageControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockitoBean
    private ImageService imageService;

    @Test
    void uploadImages_ShouldReturnEmptyList_WhenFilesIsEmpty() throws Exception {
        List<MultipartFile> files = Collections.emptyList();
        when(imageService.uploadImages(files)).thenReturn(Collections.emptyList());

        mockMvc.perform(MockMvcRequestBuilders.multipart("/images"))
                .andExpect(result -> {
                    ResponseEntity<List<ImageResponse>> response = new ResponseEntity<>(Collections.emptyList(), HttpStatus.CREATED);
                    assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
                    assertThat(response.getBody()).isEmpty();
                });
    }

    @Test
    void uploadImages_ShouldHandleNullFiles() throws Exception {
        when(imageService.uploadImages(null)).thenReturn(Collections.emptyList());

        mockMvc.perform(MockMvcRequestBuilders.multipart("/images"))
                .andExpect(result -> {
                    ResponseEntity<List<ImageResponse>> response = new ResponseEntity<>(Collections.emptyList(), HttpStatus.BAD_REQUEST);
                    assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
                    assertThat(response.getBody()).isEmpty();
                });
    }

    @Test
    void uploadImages_ShouldHandleLargeFileList() throws Exception {
        List<MockMultipartFile> files = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            files.add(new MockMultipartFile("files", "test" + i + ".jpg", "image/jpeg", ("content" + i).getBytes()));
        }
        List<ImageResponse> responses = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            responses.add(new ImageResponse(UUID.randomUUID()));
        }

        mockMvc.perform(MockMvcRequestBuilders.multipart("/images")
                        .file(files.getFirst()))
                .andExpect(result -> {
                    ResponseEntity<List<ImageResponse>> response = new ResponseEntity<>(responses, HttpStatus.CREATED);
                    assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
                    assertThat(response.getBody()).hasSize(1000);
                });
    }
}
