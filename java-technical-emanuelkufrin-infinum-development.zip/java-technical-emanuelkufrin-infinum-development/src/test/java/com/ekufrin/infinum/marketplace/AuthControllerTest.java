package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.controller.AuthController;
import com.ekufrin.infinum.marketplace.dto.JWTResponse;
import com.ekufrin.infinum.marketplace.dto.OTTLoginRequest;
import com.ekufrin.infinum.marketplace.dto.UserLoginRequest;
import com.ekufrin.infinum.marketplace.dto.UserRegisterRequest;
import com.ekufrin.infinum.marketplace.enums.Role;
import com.ekufrin.infinum.marketplace.exception.AlreadyExistsInDB;
import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.service.AuthService;
import com.ekufrin.infinum.marketplace.service.JWTService;
import com.ekufrin.infinum.marketplace.service.TokenBlacklistService;
import com.ekufrin.infinum.marketplace.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = AuthController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
class AuthControllerTest {
    private final ObjectMapper objectMapper = new ObjectMapper();
    @Autowired
    private MockMvc mockMvc;
    @MockitoBean
    private UserService userService;
    @MockitoBean
    private JWTService jwtService;
    @MockitoBean
    private AuthService authService;
    @MockitoBean
    private UserDetailsService userDetailsService;
    @MockitoBean
    private TokenBlacklistService tokenBlacklistService;

    @Test
    void registerUser_ValidUserRegisterRequestGiven_ShouldReturnJWTResponse() throws Exception {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Ivano Balić",
                "ivano.balic@gmail.com",
                "SecureP@ssword1",
                null);

        User expectedUser = new User.Builder()
                .name(userRegisterRequest.name())
                .email(userRegisterRequest.email())
                .password(userRegisterRequest.password())
                .isActive(true)
                .role(Role.USER)
                .build();

        when(userService.addUser(userRegisterRequest, null)).thenReturn(expectedUser);

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(userRegisterRequest)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.tokenType").value("Bearer"));
    }

    @Test
    void registerUser_DuplicateEmailGiven_ShouldReturnConflict() throws Exception {
        UserRegisterRequest duplicateEmailRequest = new UserRegisterRequest(
                "Marko Marić",
                "ivano.balic@gmail.com",
                "AnotherP@ssword2",
                null);

        when(userService.addUser(duplicateEmailRequest, null))
                .thenThrow(new AlreadyExistsInDB(duplicateEmailRequest.email()));

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(duplicateEmailRequest)))
                .andExpect(status().isConflict());
    }


    @Test
    void registerUser_InvalidEmailGiven_ShouldReturnBadRequest() throws Exception {
        UserRegisterRequest invalidEmailRequest = new UserRegisterRequest(
                "Ivano Balić",
                "invalid-email",
                "SecureP@ssword1",
                null);

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalidEmailRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void registerUser_EmptyNameGiven_ShouldReturnBadRequest() throws Exception {
        UserRegisterRequest emptyNameRequest = new UserRegisterRequest(
                "",
                "ivano.balic@gmail.com",
                "SecureP@ssword1",
                null);

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(emptyNameRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void registerUser_NullNameGiven_ShouldReturnBadRequest() throws Exception {
        UserRegisterRequest nullNameRequest = new UserRegisterRequest(
                null,
                "ivano.balic@gmail.com",
                "SecureP@ssword1",
                null);

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(nullNameRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void registerUser_WeakPasswordGiven_ShouldReturnBadRequest() throws Exception {
        UserRegisterRequest weakPasswordRequest = new UserRegisterRequest(
                "Ivano Balić",
                "ivano.balic@gmail.com",
                "weak",
                null);

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(weakPasswordRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void registerUser_EmptyPasswordGiven_ShouldReturnBadRequest() throws Exception {
        UserRegisterRequest emptyPasswordRequest = new UserRegisterRequest(
                "Ivano Balić",
                "ivano.balic@gmail.com",
                "",
                null);

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(emptyPasswordRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void registerUser_AllFieldsNullGiven_ShouldReturnBadRequest() throws Exception {
        UserRegisterRequest allNullRequest = new UserRegisterRequest(null, null, null, null);

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(allNullRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void loginUser_ValidUserLoginRequestGiven_ShouldReturnJWTResponse() throws Exception {
        UserLoginRequest userLoginRequest = new UserLoginRequest("mirko.mirkic@gmail.com", "fakePassword123");
        User expectedUser = new User.Builder()
                .name("Mirko Mirkic")
                .email(userLoginRequest.email())
                .password(userLoginRequest.password())
                .isActive(true)
                .role(Role.USER)
                .build();

        when(authService.authenticate(userLoginRequest)).thenReturn(Optional.of(expectedUser));

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(userLoginRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.tokenType").value("Bearer"))
                .andExpect(jsonPath("$.expiresIn").isNumber());
    }

    @Test
    void loginUser_InvalidCredentials_ShouldReturnUnauthorized() throws Exception {
        UserLoginRequest invalidRequest = new UserLoginRequest("user@example.com", "wrongPassword");

        when(authService.authenticate(invalidRequest)).thenReturn(Optional.empty());

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalidRequest)))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void loginUser_NonExistentEmail_ShouldReturnUnauthorized() throws Exception {
        UserLoginRequest nonExistentRequest = new UserLoginRequest("nonexistent@example.com", "anyPassword");

        when(authService.authenticate(nonExistentRequest)).thenReturn(Optional.empty());

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(nonExistentRequest)))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void loginUser_EmptyEmail_ShouldReturnBadRequest() throws Exception {
        UserLoginRequest emptyEmailRequest = new UserLoginRequest("", "password123");

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(emptyEmailRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void loginUser_NullEmail_ShouldReturnBadRequest() throws Exception {
        UserLoginRequest nullEmailRequest = new UserLoginRequest(null, "password123");

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(nullEmailRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void loginUser_EmptyPassword_ShouldReturnBadRequest() throws Exception {
        UserLoginRequest emptyPasswordRequest = new UserLoginRequest("user@example.com", "");

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(emptyPasswordRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void loginUser_NullPassword_ShouldReturnBadRequest() throws Exception {
        UserLoginRequest nullPasswordRequest = new UserLoginRequest("user@example.com", null);

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(nullPasswordRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void loginUser_InvalidEmailFormat_ShouldReturnBadRequest() throws Exception {
        UserLoginRequest invalidEmailFormatRequest = new UserLoginRequest("not-an-email", "password123");

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalidEmailFormatRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void loginUser_AllFieldsNull_ShouldReturnBadRequest() throws Exception {
        UserLoginRequest allNullRequest = new UserLoginRequest(null, null);

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(allNullRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void loginUser_WhitespacePassword_ShouldReturnBadRequest() throws Exception {
        UserLoginRequest whitespacePasswordRequest = new UserLoginRequest("user@example.com", "   ");

        when(authService.authenticate(whitespacePasswordRequest)).thenReturn(Optional.empty());

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(whitespacePasswordRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void logoutUser_ValidAuthorizationHeader_ShouldReturnNoContent() throws Exception {
        String token = "validToken";
        Instant expiration = Instant.now().plusSeconds(3600);

        when(jwtService.extractClaim(eq(token), any())).thenReturn(expiration);

        mockMvc.perform(post("/auth/logout")
                        .header(HttpHeaders.AUTHORIZATION, "Bearer " + token))
                .andExpect(status().isNoContent());

        verify(tokenBlacklistService, times(1)).blacklist(token, expiration);
    }

    @Test
    void logoutUser_MissingAuthorizationHeader_ShouldReturnBadRequest() throws Exception {
        mockMvc.perform(post("/auth/logout"))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(jwtService, tokenBlacklistService);
    }

    @Test
    void logoutUser_InvalidAuthorizationHeader_ShouldReturnBadRequest() throws Exception {
        mockMvc.perform(post("/auth/logout")
                        .header(HttpHeaders.AUTHORIZATION, "InvalidHeader"))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(jwtService, tokenBlacklistService);
    }

    @Test
    void validOTTRequest_createsAndSendsEmail_returnsNoContent() throws Exception {
        OTTLoginRequest request = new OTTLoginRequest("user@example.com");

        mockMvc.perform(post("/auth/ott-request")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isNoContent());

        verify(authService, times(1)).createAndSendOTTokenEmail("user@example.com");
    }

    @Test
    void invalidOTTRequest_missingEmail_returnsBadRequest() throws Exception {
        OTTLoginRequest request = new OTTLoginRequest(null);

        mockMvc.perform(post("/auth/ott-request")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(authService);
    }

    @Test
    void validOTTLogin_returnsJwtResponse() throws Exception {
        String token = "validToken";
        User user = new User.Builder()
                .id(UUID.randomUUID())
                .email("user@example.com")
                .build();
        JWTResponse jwtResponse = new JWTResponse("jwtToken", "Bearer", 3600);

        when(authService.validateOTTLogin(any(OneTimeTokenAuthenticationToken.class))).thenReturn(user);
        when(jwtService.generateToken(user)).thenReturn(jwtResponse.token());
        when(jwtService.getExpirationTime()).thenReturn(jwtResponse.expiresIn());

        mockMvc.perform(get("/auth/ott-login")
                        .param("token", token))
                .andExpect(status().isOk())
                .andExpect(header().string(HttpHeaders.AUTHORIZATION, "Bearer jwtToken"))
                .andExpect(jsonPath("$.tokenType").value("Bearer"))
                .andExpect(jsonPath("$.token").value("jwtToken"))
                .andExpect(jsonPath("$.expiresIn").value(3600));

        verify(authService, times(1)).validateOTTLogin(any(OneTimeTokenAuthenticationToken.class));
    }

    @Test
    void invalidOTTLogin_missingToken_returnsBadRequest() throws Exception {
        mockMvc.perform(get("/auth/ott-login"))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(authService, jwtService);
    }

    @Test
    void invalidOTTLogin_invalidToken_returnsUnauthorized() throws Exception {
        String token = "invalidToken";

        when(authService.validateOTTLogin(any(OneTimeTokenAuthenticationToken.class))).thenThrow(new DBException("Invalid or expired OTT"));

        mockMvc.perform(get("/auth/ott-login")
                        .param("token", token))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Invalid or expired OTT"));

        verify(authService, times(1)).validateOTTLogin(any(OneTimeTokenAuthenticationToken.class));
    }

}
