package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.dto.ContactInfoRequest;
import com.ekufrin.infinum.marketplace.dto.ContactInfoResponse;
import com.ekufrin.infinum.marketplace.dto.PunishmentCreateRequest;
import com.ekufrin.infinum.marketplace.dto.ResetPasswordChange;
import com.ekufrin.infinum.marketplace.dto.UserDTO;
import com.ekufrin.infinum.marketplace.dto.UserPasswordChange;
import com.ekufrin.infinum.marketplace.dto.UserRegisterRequest;
import com.ekufrin.infinum.marketplace.enums.AdReportType;
import com.ekufrin.infinum.marketplace.enums.Role;
import com.ekufrin.infinum.marketplace.exception.AlreadyExistsInDB;
import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.exception.EmailException;
import com.ekufrin.infinum.marketplace.exception.PasswordMismatch;
import com.ekufrin.infinum.marketplace.model.AdReport;
import com.ekufrin.infinum.marketplace.model.ContactInfo;
import com.ekufrin.infinum.marketplace.model.OTT;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.repository.AdReportRepository;
import com.ekufrin.infinum.marketplace.repository.ContactInfoRepository;
import com.ekufrin.infinum.marketplace.repository.OTTRepository;
import com.ekufrin.infinum.marketplace.repository.UserRepository;
import com.ekufrin.infinum.marketplace.service.EmailSenderService;
import com.ekufrin.infinum.marketplace.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.authentication.ott.DefaultOneTimeToken;
import org.springframework.security.authentication.ott.GenerateOneTimeTokenRequest;
import org.springframework.security.authentication.ott.OneTimeToken;
import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationToken;
import org.springframework.security.authentication.ott.OneTimeTokenService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static com.ekufrin.infinum.marketplace.service.UserService.EXPIRES_IN;
import static com.ekufrin.infinum.marketplace.service.UserService.PASSWORD_RESET_OTT_TEMPLATE_ID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    @Mock
    private UserRepository userRepository;
    @Mock
    private ContactInfoRepository contactInfoRepository;
    @Mock
    private EmailSenderService emailSenderService;
    @Mock
    private OneTimeTokenService oneTimeTokenService;
    @Mock
    private OTTRepository ottRepository;
    @Mock
    private AdReportRepository adReportRepository;
    private UserService userService;


    @BeforeEach
    void setUp() {
        userService = new UserService(userRepository, contactInfoRepository, passwordEncoder, oneTimeTokenService, emailSenderService, ottRepository, adReportRepository);
    }

    @Test
    void addUser_ValidUserRequestGiven_ShouldReturnAddedUser() {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Ivano Balić",
                "ivano.balic@gmail.com",
                "SecureP@ssword1",
                null);

        UUID expectedId = UUID.randomUUID();
        User expectedUser = new User.Builder()
                .id(expectedId)
                .name(userRegisterRequest.name())
                .email(userRegisterRequest.email())
                .password(passwordEncoder.encode(userRegisterRequest.password()))
                .isActive(true)
                .role(Role.USER)
                .build();

        when(userRepository.existsByEmailIgnoreCase("ivano.balic@gmail.com")).thenReturn(Boolean.FALSE);
        when(userRepository.save(any(User.class))).thenReturn(expectedUser);

        var user = userService.addUser(userRegisterRequest, null);

        assertThat(user.getId()).isNotNull();
        assertThat(user.getName()).isEqualTo("Ivano Balić");
        assertThat(user.getEmail()).isEqualTo("ivano.balic@gmail.com");
        assertThat(passwordEncoder.matches(userRegisterRequest.password(), user.getPassword())).isTrue();
    }

    @Test
    void addUser_ValidUserRequestGiven_ShouldReturnEmailAlreadyExists() {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Ivano Balić",
                "ivano.balic@gmail.com",
                "SecureP@ssword1",
                null);

        when(userRepository.existsByEmailIgnoreCase("ivano.balic@gmail.com")).thenReturn(Boolean.TRUE);

        try {
            userService.addUser(userRegisterRequest, null);
        } catch (Exception e) {
            assertThat(e).isInstanceOf(AlreadyExistsInDB.class);
            assertThat(e.getMessage()).isEqualTo("ivano.balic@gmail.com already exists.");
        }
    }

    @Test
    void addUser_EmailWithDifferentCase_ShouldStillCheckForDuplicates() {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Marko Marić",
                "Ivano.Balic@Gmail.com",
                "SecureP@ssword1",
                null);

        when(userRepository.existsByEmailIgnoreCase("Ivano.Balic@Gmail.com")).thenReturn(Boolean.TRUE);

        try {
            userService.addUser(userRegisterRequest, null);
        } catch (Exception e) {
            assertThat(e).isInstanceOf(AlreadyExistsInDB.class);
            assertThat(e.getMessage()).contains("Ivano.Balic@Gmail.com");
        }
    }

    @Test
    void addUser_EmptyEmail_ShouldHandleValidation() {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Ivano Balić",
                "",
                "SecureP@ssword1",
                null);

        when(userRepository.existsByEmailIgnoreCase("")).thenReturn(Boolean.FALSE);
        assertThatThrownBy(() -> userService.addUser(userRegisterRequest, null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Wrong email format");
    }

    @Test
    void addUser_VeryLongEmail_ShouldHandle() {
        String longEmail = "a".repeat(250) + "@gmail.com";
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Ivano Balić",
                longEmail,
                "SecureP@ssword1",
                null);

        when(userRepository.existsByEmailIgnoreCase(longEmail)).thenReturn(Boolean.FALSE);
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        var user = userService.addUser(userRegisterRequest, null);

        assertThat(user.getEmail()).isEqualTo(longEmail);
    }

    @Test
    void addUser_SpecialCharactersInName_ShouldHandle() {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Ivano-Balić@#$%",
                "ivano.balic@gmail.com",
                "SecureP@ssword1",
                null);

        when(userRepository.existsByEmailIgnoreCase("ivano.balic@gmail.com")).thenReturn(Boolean.FALSE);
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        var user = userService.addUser(userRegisterRequest, null);

        assertThat(user.getName()).isEqualTo("Ivano-Balić@#$%");
    }

    @Test
    void addUser_EmailWithWhitespace_ShouldThrowException() {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Ivano Balić",
                " ivano.balic@gmail.com ",
                "SecureP@ssword1",
                null);

        when(userRepository.existsByEmailIgnoreCase(" ivano.balic@gmail.com ")).thenReturn(Boolean.FALSE);

        assertThatThrownBy(() -> userService.addUser(userRegisterRequest, null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Wrong email format");
    }

    @Test
    void addUser_OwnerCanCreateUserWithCustomRole_ShouldReturnUserWithRequestedRole() {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Owner Creator",
                "owner.created@example.com",
                "SecureP@ssword1",
                Role.OWNER);

        UUID ownerId = UUID.randomUUID();
        UserDetails ownerDetails = org.springframework.security.core.userdetails.User.withUsername(ownerId.toString())
                .password("password")
                .roles("OWNER")
                .build();

        User ownerUser = new User.Builder().id(ownerId).role(Role.OWNER).username("owner").build();

        when(userRepository.findById(ownerId)).thenReturn(Optional.of(ownerUser));

        assertThatThrownBy(() -> userService.addUser(userRegisterRequest, ownerDetails))
                .isInstanceOf(DBException.class)
                .hasMessageContaining("Cannot create owner user.");
    }

    @Test
    void addUser_NonOwnerCannotCreateUserWithCustomRole_ShouldThrowDBException() {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Regular Creator",
                "regular.created@example.com",
                "SecureP@ssword1",
                Role.ADMIN);

        UUID userId = UUID.randomUUID();
        UserDetails userDetails = org.springframework.security.core.userdetails.User.withUsername(userId.toString())
                .password("password")
                .roles("USER")
                .build();

        User regularUser = new User.Builder().id(userId).role(Role.USER).username("regular").build();

        when(userRepository.findById(userId)).thenReturn(Optional.of(regularUser));

        assertThatThrownBy(() -> userService.addUser(userRegisterRequest, userDetails))
                .isInstanceOf(DBException.class)
                .hasMessageContaining("Only owners can create users with custom roles.");
    }

    @Test
    void changeUserPassword_UserNotFound_ShouldThrowException() {
        UUID userId = UUID.randomUUID();
        UserPasswordChange change = new UserPasswordChange("old", "new");
        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        String userIdStr = userId.toString();

        assertThatThrownBy(() -> userService.changeUserPassword(userIdStr, change))
                .isInstanceOf(DBException.class);
    }

    @Test
    void changeUserPassword_OldPasswordIncorrect_ShouldThrowPasswordMismatch() {
        String email = "user@example.com";
        String oldPassword = "wrongOld";
        String currentPassword = passwordEncoder.encode("realOld");
        User user = new User.Builder().id(UUID.randomUUID()).email(email).password(currentPassword).build();
        when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));

        UserPasswordChange change = new UserPasswordChange(oldPassword, "newPassword");

        String userId = user.getId().toString();

        assertThatThrownBy(() -> userService.changeUserPassword(userId, change))
                .isInstanceOf(PasswordMismatch.class)
                .hasMessageContaining("Old password does not match");
    }

    @Test
    void changeUserPassword_NewPasswordSameAsOld_ShouldThrowPasswordMismatch() {
        String email = "user@example.com";
        String oldPassword = "samePassword";
        String currentPassword = passwordEncoder.encode(oldPassword);
        User user = new User.Builder().id(UUID.randomUUID()).email(email).password(currentPassword).build();
        when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));

        UserPasswordChange change = new UserPasswordChange(oldPassword, oldPassword);

        String userId = user.getId().toString();

        assertThatThrownBy(() -> userService.changeUserPassword(userId, change))
                .isInstanceOf(PasswordMismatch.class)
                .hasMessageContaining("New password must be different");
    }

    @Test
    void changeUserPassword_NewPasswordIsNull_ShouldThrowExceptionOrEncodeNull() {
        String email = "user@example.com";
        String oldPassword = "oldPassword";

        UserPasswordChange change = new UserPasswordChange(oldPassword, null);

        assertThatThrownBy(() -> userService.changeUserPassword(email, change))
                .isInstanceOf(Exception.class);
    }

    @Test
    void getAllUsers_PageZero_ShouldReturnEmptyPage() {
        Pageable pageable = PageRequest.of(0, 20);

        when(userRepository.findAllFiltered(isNull(), isNull(), any(Pageable.class)))
                .thenReturn(Page.empty());

        Page<UserDTO> result = userService.getAllUsersAsPageWithFilterAndSorting(null, null, pageable);

        assertThat(result).isEmpty();
        assertThat(result.getTotalElements()).isZero();
        assertThat(result.getContent()).isEmpty();
    }

    @Test
    void getAllUsers_SizeNegative_ShouldDefaultToTwenty_AndReturnEmptyPage() {
        Pageable pageable = PageRequest.of(1, 20);

        when(userRepository.findAllFiltered(isNull(), isNull(), any(Pageable.class)))
                .thenReturn(Page.empty());

        Page<UserDTO> result = userService.getAllUsersAsPageWithFilterAndSorting(null, null, pageable);

        assertThat(result).isEmpty();
    }

    @Test
    void getAllUsers_SizeTooLarge_ShouldCapToHundred_AndReturnEmptyPage() {
        Pageable pageable = PageRequest.of(1, 100);

        when(userRepository.findAllFiltered(isNull(), isNull(), any(Pageable.class)))
                .thenReturn(Page.empty());

        Page<UserDTO> result = userService.getAllUsersAsPageWithFilterAndSorting(null, null, pageable);

        assertThat(result).isEmpty();
    }

    @Test
    void getAllUsers_SortParamNull_ShouldSortByCreatedAtDesc_AndReturnEmptyPage() {
        Pageable pageable = PageRequest.of(1, 20);

        when(userRepository.findAllFiltered(isNull(), isNull(), any(Pageable.class)))
                .thenReturn(Page.empty());

        Page<UserDTO> result = userService.getAllUsersAsPageWithFilterAndSorting(null, null, pageable);

        assertThat(result).isEmpty();
        assertThat(result.getContent()).isEmpty();
    }

    @Test
    void getAllUsers_SortParamInvalidFormat_ShouldSortByPropertyAsc_AndReturnEmptyPage() {
        Pageable pageable = PageRequest.of(1, 20, Sort.by("invalid"));

        when(userRepository.findAllFiltered(isNull(), isNull(), any(Pageable.class)))
                .thenReturn(Page.empty());

        Page<UserDTO> result = userService.getAllUsersAsPageWithFilterAndSorting(null, null, pageable);

        assertThat(result).isEmpty();
        assertThat(result.getContent()).isEmpty();
    }

    @Test
    void getAllUsers_SearchIsBlank_ShouldPassNullToRepository_AndReturnEmptyPage() {
        Pageable pageable = PageRequest.of(1, 20);

        when(userRepository.findAllFiltered(eq("   "), isNull(), eq(pageable)))
                .thenReturn(Page.empty());

        Page<UserDTO> result = userService.getAllUsersAsPageWithFilterAndSorting("   ", null, pageable);

        assertThat(result).isEmpty();
    }

    @Test
    void getAllUsers_StatusTrue_ShouldPassTrueToRepository_AndReturnEmptyPage() {
        Pageable pageable = PageRequest.of(1, 20);

        when(userRepository.findAllFiltered(isNull(), eq(true), any(Pageable.class)))
                .thenReturn(Page.empty());

        Page<UserDTO> result = userService.getAllUsersAsPageWithFilterAndSorting(null, true, pageable);

        assertThat(result).isEmpty();
        assertThat(result.getContent()).isEmpty();
    }

    @Test
    void getAllUsers_StatusFalse_ShouldPassFalseToRepository_AndReturnEmptyPage() {
        Pageable pageable = PageRequest.of(1, 20);

        when(userRepository.findAllFiltered(isNull(), eq(false), any(Pageable.class)))
                .thenReturn(Page.empty());

        Page<UserDTO> result = userService.getAllUsersAsPageWithFilterAndSorting(null, false, pageable);

        assertThat(result).isEmpty();
        assertThat(result.getContent()).isEmpty();
    }

    @Test
    void getUserByEmail_UserExists_ShouldReturnUserDTO() {
        String email = "marija.kovac@example.com";
        User user = new User.Builder().name("Marija Kovač")
                .email(email)
                .role(Role.USER)
                .isActive(true).
                build();

        when(userRepository.findByEmail(email)).thenReturn(Optional.of(user));

        UserDTO userDTO = userService.getUserByEmail(email);
        assertThat(userDTO).isNotNull();
        assertThat(userDTO.name()).isEqualTo("Marija Kovač");
        assertThat(userDTO.email()).isEqualTo(email);
        assertThat(userDTO.role()).isEqualTo(Role.USER);
        assertThat(userDTO.isActive()).isTrue();
    }

    @Test
    void getUserByEmail_UserDoesNotExist_ShouldThrowDBException() {
        String email = "luka.lukic@yahoo.com";

        when(userRepository.findByEmail(email)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> userService.getUserByEmail(email))
                .isInstanceOf(DBException.class)
                .hasMessageContaining("User with email " + email + " not found.");
    }

    @Test
    void createContactInfo_validArgumentGiven_shouldReturnContactInfoResponse() {
        ContactInfoRequest request = new ContactInfoRequest(
                "test123@gmail.com",
                "+385912345678");
        UserDetails userDetails = org.springframework.security.core.userdetails.User.withUsername("8d5cfe7c-1e1b-4a1e-b8f0-111111111111")
                .password("password")
                .roles("USER")
                .build();
        when(userRepository.findById(UUID.fromString("8d5cfe7c-1e1b-4a1e-b8f0-111111111111")))
                .thenReturn(Optional.of(mock(com.ekufrin.infinum.marketplace.model.User.class)));
        when(contactInfoRepository.save(org.mockito.ArgumentMatchers.any()))
                .thenAnswer(i -> i.getArguments()[0]);
        ContactInfoResponse response = userService.createContactInfo(request, userDetails);

        assertThat(response.email()).isEqualTo(request.email());
        assertThat(response.phoneNumber()).isEqualTo(request.phoneNumber());
    }

    @Test
    void createContactInfo_UserNotFound_ThrowsDBException() {
        ContactInfoRequest request = new ContactInfoRequest("notfound@example.com", "+123456789");
        UserDetails userDetails = org.springframework.security.core.userdetails.User
                .withUsername("00000000-0000-0000-0000-000000000000")
                .password("password")
                .roles("USER")
                .build();

        when(userRepository.findById(UUID.fromString(userDetails.getUsername())))
                .thenReturn(Optional.empty());

        assertThatThrownBy(() -> userService.createContactInfo(request, userDetails))
                .isInstanceOf(DBException.class)
                .hasMessageContaining("User not found");
    }

    @Test
    void findAllContactInfoForUser_ValidUserId_ShouldReturnContactInfoPage() {
        UUID userId = UUID.randomUUID();
        Pageable pageable = PageRequest.of(0, 10);

        ContactInfo contactInfo1 = new ContactInfo();
        contactInfo1.setId(UUID.randomUUID());
        contactInfo1.setEmail("test.user@example.com");
        contactInfo1.setPhoneNumber("+123456789");

        ContactInfo contactInfo2 = new ContactInfo();
        contactInfo2.setId(UUID.randomUUID());
        contactInfo2.setEmail("test.user.new.email@example.com");
        contactInfo2.setPhoneNumber("+123456789");

        ContactInfoResponse contact1 = new ContactInfoResponse(
                contactInfo1.getId(),
                "test.user@example.com",
                "+123456789");

        ContactInfoResponse contact2 = new ContactInfoResponse(
                contactInfo2.getId(),
                "test.user.new.email@example.com",
                "+123456789");

        Page<ContactInfo> contactInfoPage = new PageImpl<>(List.of(contactInfo1, contactInfo2));
        when(contactInfoRepository.findAllByUser_Id(userId, pageable))
                .thenReturn(contactInfoPage);
        Page<ContactInfoResponse> result = userService.getAllContactInfoForUser(userId, pageable);
        assertThat(result).isNotNull();
        assertThat(result.getTotalElements()).isEqualTo(2);
        assertThat(result.getContent()).containsExactly(contact1, contact2);
    }

    @Test
    void findAllContactInfoForUser_NoContactInfo_ShouldReturnEmptyPage() {
        UUID userId = UUID.randomUUID();
        Pageable pageable = PageRequest.of(0, 10);

        when(contactInfoRepository.findAllByUser_Id(userId, pageable))
                .thenReturn(Page.empty());

        Page<ContactInfoResponse> result = userService.getAllContactInfoForUser(userId, pageable);

        assertThat(result).isEmpty();
        assertThat(result.getTotalElements()).isZero();
        assertThat(result.getContent()).isEmpty();
    }

    @Test
    void createAndSendOTTokenEmail_ValidEmail_ShouldSendEmail() throws Exception {
        String email = "user@example.com";
        User user = new User.Builder()
                .id(UUID.randomUUID())
                .email(email)
                .username("user123")
                .build();
        OneTimeToken token = new DefaultOneTimeToken("token123", user.getId().toString(), Instant.now().plus(EXPIRES_IN));

        when(userRepository.findByEmail(email)).thenReturn(Optional.of(user));
        when(oneTimeTokenService.generate(any(GenerateOneTimeTokenRequest.class))).thenReturn(token);

        userService.createAndSendOTTokenEmail(email);
        verify(emailSenderService, times(1)).sendEmail(eq(email), eq(PASSWORD_RESET_OTT_TEMPLATE_ID), anyMap());
    }

    @Test
    void createAndSendOTTokenEmail_UserNotFound_ShouldThrowDBException() {
        String email = "nonexistent@example.com";

        when(userRepository.findByEmail(email)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> userService.createAndSendOTTokenEmail(email))
                .isInstanceOf(DBException.class)
                .hasMessageContaining("User not found");
    }

    @Test
    void validateOTTPasswordResetToken_ValidToken_ShouldReturnTrue() {
        UUID tokenId = UUID.randomUUID();
        String tokenValue = tokenId.toString();
        OTT ott = new OTT();
        ott.setId(tokenId);
        ott.setValue(tokenValue);
        ott.setExpiresAt(Instant.now().plus(Duration.ofMinutes(10)));

        when(ottRepository.findById(tokenId)).thenReturn(Optional.of(ott));

        boolean result = userService.validateOTTPasswordResetToken(new OneTimeTokenAuthenticationToken(tokenValue));

        assertThat(result).isTrue();
    }

    @Test
    void validateOTTPasswordResetToken_ExpiredToken_ShouldReturnFalse() {
        UUID tokenId = UUID.randomUUID();
        String tokenValue = tokenId.toString();
        OTT ott = new OTT();
        ott.setId(tokenId);
        ott.setValue(tokenValue);
        ott.setExpiresAt(Instant.now().minus(Duration.ofMinutes(1)));

        when(ottRepository.findById(tokenId)).thenReturn(Optional.of(ott));

        boolean result = userService.validateOTTPasswordResetToken(new OneTimeTokenAuthenticationToken(tokenValue));

        assertThat(result).isFalse();
    }

    @Test
    void validateOTTPasswordChange_ValidToken_ShouldUpdatePassword() {
        String tokenValue = "validToken";
        String newPassword = "newPassword123";
        UUID userId = UUID.randomUUID();
        User user = new User.Builder()
                .id(userId)
                .password("oldPassword")
                .build();
        OneTimeToken token = new DefaultOneTimeToken(tokenValue, userId.toString(), Instant.now().plus(Duration.ofMinutes(10)));

        when(oneTimeTokenService.consume(any(OneTimeTokenAuthenticationToken.class))).thenReturn(token);
        when(userRepository.findById(userId)).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        User updatedUser = userService.validateOTTPasswordChange(new OneTimeTokenAuthenticationToken(tokenValue), new ResetPasswordChange(newPassword));

        assertThat(passwordEncoder.matches(newPassword, updatedUser.getPassword())).isTrue();
    }

    @Test
    void validateOTTPasswordChange_InvalidToken_ShouldThrowDBException() {
        String tokenValue = "invalidToken";

        when(oneTimeTokenService.consume(any(OneTimeTokenAuthenticationToken.class)))
                .thenThrow(new DBException("User not found"));

        assertThatThrownBy(() -> userService.validateOTTPasswordChange(new OneTimeTokenAuthenticationToken(tokenValue), new ResetPasswordChange("newPassword")))
                .isInstanceOf(DBException.class)
                .hasMessageContaining("User not found");
    }

    @Test
    void getAllAdReportsForUser_ValidUserId_ShouldReturnAdReportsPage() {
        UUID userId = UUID.randomUUID();
        Pageable pageable = PageRequest.of(0, 10);

        AdReport adReport1 = new AdReport();
        adReport1.setId(UUID.randomUUID());

        AdReport adReport2 = new AdReport();
        adReport2.setId(UUID.randomUUID());

        Page<AdReport> adReportsPage = new PageImpl<>(List.of(adReport1, adReport2));
        when(adReportRepository.findAllByAd_Author_Id(userId, pageable)).thenReturn(adReportsPage);

        Page<AdReport> result = userService.getAllAdReportsForUser(userId, pageable);

        assertThat(result).isNotNull();
        assertThat(result.getTotalElements()).isEqualTo(2);
        assertThat(result.getContent()).containsExactly(adReport1, adReport2);
    }

    @Test
    void getAllAdReportsForUser_NoAdReports_ShouldReturnEmptyPage() {
        UUID userId = UUID.randomUUID();
        Pageable pageable = PageRequest.of(0, 10);

        when(adReportRepository.findAllByAd_Author_Id(userId, pageable)).thenReturn(Page.empty());

        Page<AdReport> result = userService.getAllAdReportsForUser(userId, pageable);

        assertThat(result).isEmpty();
        assertThat(result.getTotalElements()).isZero();
        assertThat(result.getContent()).isEmpty();
    }

    @Test
    void punishUser_UserNotFound_ShouldThrowDBException() {
        UUID userId = UUID.randomUUID();
        PunishmentCreateRequest request = new PunishmentCreateRequest(AdReportType.SPAM, "Violation of terms", true);

        when(userRepository.findUserByIdAndRoleEquals(userId, Role.USER)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> userService.punishUser(userId, request))
                .isInstanceOf(DBException.class)
                .hasMessageContaining("User not found");
    }

    @Test
    void punishUser_BanUser_ShouldDeactivateUserAndSendEmail() throws Exception {
        UUID userId = UUID.randomUUID();
        User user = new User.Builder()
                .id(userId)
                .email("user@example.com")
                .username("testUser")
                .isActive(true)
                .build();
        PunishmentCreateRequest request = new PunishmentCreateRequest(AdReportType.SPAM, "Violation of terms", true);

        when(userRepository.findUserByIdAndRoleEquals(userId, Role.USER)).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        userService.punishUser(userId, request);

        assertThat(user.isActive()).isFalse();
        verify(userRepository).save(user);
        verify(emailSenderService).sendEmail(eq("user@example.com"), eq(UserService.PUNISHMENT_TEMPLATE_ID), anyMap());
    }

    @Test
    void punishUser_DoNotBanUser_ShouldSendEmailOnly() throws Exception {
        UUID userId = UUID.randomUUID();
        User user = new User.Builder()
                .id(userId)
                .email("user@example.com")
                .username("testUser")
                .isActive(true)
                .build();
        PunishmentCreateRequest request = new PunishmentCreateRequest(AdReportType.SPAM, "Violation of terms", false);

        when(userRepository.findUserByIdAndRoleEquals(userId, Role.USER)).thenReturn(Optional.of(user));

        userService.punishUser(userId, request);

        assertThat(user.isActive()).isTrue();
        verify(userRepository, never()).save(user);
        verify(emailSenderService).sendEmail(eq("user@example.com"), eq(UserService.PUNISHMENT_TEMPLATE_ID), anyMap());
    }

    @Test
    void punishUser_EmailSendingFails_ShouldThrowEmailException() throws Exception {
        UUID userId = UUID.randomUUID();
        User user = new User.Builder()
                .id(userId)
                .email("user@example.com")
                .username("testUser")
                .isActive(true)
                .build();
        PunishmentCreateRequest request = new PunishmentCreateRequest(AdReportType.SPAM, "Violation of terms", true);

        when(userRepository.findUserByIdAndRoleEquals(userId, Role.USER)).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));
        doThrow(new IOException("Email sending failed")).when(emailSenderService).sendEmail(anyString(), anyString(), anyMap());

        assertThatThrownBy(() -> userService.punishUser(userId, request))
                .isInstanceOf(EmailException.class)
                .hasMessageContaining("Failed to send punishment email.");
    }
}
