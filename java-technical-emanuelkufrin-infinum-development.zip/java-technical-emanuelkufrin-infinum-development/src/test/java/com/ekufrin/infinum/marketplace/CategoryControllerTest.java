package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.controller.CategoryController;
import com.ekufrin.infinum.marketplace.dto.CategoryChangeRequest;
import com.ekufrin.infinum.marketplace.dto.CategoryCreateRequest;
import com.ekufrin.infinum.marketplace.exception.AlreadyExistsInDB;
import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.model.Category;
import com.ekufrin.infinum.marketplace.service.CategoryService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = CategoryController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
class CategoryControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private CategoryService categoryService;
    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void addCategory_ValidArgumentGiven_ShouldAddCategory() throws Exception {
        CategoryCreateRequest request = new CategoryCreateRequest("Books", true);
        Category category = new Category();
        category.setName("Books");
        category.setActive(true);

        when(categoryService.addCategory(any(CategoryCreateRequest.class))).thenReturn(category);

        mockMvc.perform(post("/categories")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.name").value("Books"))
                .andExpect(jsonPath("$.active").value(true));
    }

    @Test
    void addCategory_InvalidArgumentGiven_ShouldReturnBadRequest() throws Exception {
        CategoryCreateRequest request = new CategoryCreateRequest(null, true);

        mockMvc.perform(post("/categories")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void addCategory_DuplicateNameGiven_ShouldReturnConflict() throws Exception {
        CategoryCreateRequest request = new CategoryCreateRequest("Books", true);

        when(categoryService.addCategory(any(CategoryCreateRequest.class)))
                .thenThrow(new AlreadyExistsInDB("Books"));

        mockMvc.perform(post("/categories")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isConflict());
    }

    @Test
    void getAllCategories_ShouldReturnListOfCategories() throws Exception {
        Page<Category> categoryPage = new PageImpl<>(List.of(
                new Category(UUID.randomUUID(), "Electronics", true, Instant.now(), null),
                new Category(UUID.randomUUID(), "Books", true, Instant.now(), null),
                new Category(UUID.randomUUID(), "Clothing", false, Instant.now(), null)
        ), PageRequest.of(0, 2), 3);

        when(categoryService.getAllCategoriesAsPageWithFilterAndSorting(any(), any(), any())).thenReturn(categoryPage);

        mockMvc.perform(get("/categories")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(3))
                .andExpect(jsonPath("$.content[0].name").value("Electronics"))
                .andExpect(jsonPath("$.content[1].name").value("Books"));
    }

    @Test
    void getAllCategories_NoCategories_ShouldReturnEmptyList() throws Exception {
        Page<Category> categoryPage = new PageImpl<>(new ArrayList<>(), PageRequest.of(0, 2), 0);

        when(categoryService.getAllCategoriesAsPageWithFilterAndSorting(any(), any(), any())).thenReturn(categoryPage);

        mockMvc.perform(get("/categories")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(0))
                .andExpect(jsonPath("$.content").isEmpty());
    }

    @Test
    void getAllCategories_PageSizeTwo_ShouldReturnListOfTwoCategories() throws Exception {
        Page<Category> categoryPage = new PageImpl<>(List.of(
                new Category(UUID.randomUUID(), "Electronics", true, Instant.now(), null),
                new Category(UUID.randomUUID(), "Books", true, Instant.now(), null),
                new Category(UUID.randomUUID(), "Clothing", false, Instant.now(), null)
        ), PageRequest.of(0, 2), 3);

        when(categoryService.getAllCategoriesAsPageWithFilterAndSorting(any(), any(), any())).thenReturn(categoryPage);

        mockMvc.perform(get("/categories")
                        .contentType(MediaType.APPLICATION_JSON)
                        .param("page", "0")
                        .param("size", "2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(3))
                .andExpect(jsonPath("$.size").value(2))
                .andExpect(jsonPath("$.content[0].name").value("Electronics"))
                .andExpect(jsonPath("$.content[1].name").value("Books"));
    }

    @Test
    void getAllCategories_WithSearchParam_ShouldReturnFilteredCategories() throws Exception {
        Page<Category> categoryPage = new PageImpl<>(List.of(
                new Category(UUID.randomUUID(), "Electronics", true, Instant.now(), null)
        ), PageRequest.of(0, 10), 1);

        when(categoryService.getAllCategoriesAsPageWithFilterAndSorting("Electro", null, PageRequest.of(0, 10)))
                .thenReturn(categoryPage);

        mockMvc.perform(get("/categories")
                        .param("search", "Electro")
                        .param("page", "0")
                        .param("size", "10")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(1))
                .andExpect(jsonPath("$.content[0].name").value("Electronics"));
    }


    @Test
    void updateCategoryName_ValidArgumentGiven_ShouldUpdateCategory() throws Exception {
        UUID categoryId = UUID.randomUUID();
        String newName = "NewCategoryName";
        Category updatedCategory = new Category(categoryId, newName, true, Instant.now(), null);

        when(categoryService.updateCategory(any(), any())).thenReturn(updatedCategory);

        mockMvc.perform(patch("/categories/{id}", categoryId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\": \"" + newName + "\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(categoryId.toString()))
                .andExpect(jsonPath("$.name").value(newName));
    }

    @Test
    void updateCategory_InvalidArgumentGiven_ShouldReturnBadRequest() throws Exception {
        UUID categoryId = UUID.randomUUID();

        mockMvc.perform(patch("/categories/{id}", categoryId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\": \"\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Name is required"));
    }

    @Test
    void updateCategoryName_NonExistentCategory_ShouldReturnNotFound() throws Exception {
        UUID categoryId = UUID.randomUUID();
        String newName = "NewCategoryName";

        when(categoryService.updateCategory(any(), any()))
                .thenThrow(new DBException("Category not found"));

        mockMvc.perform(patch("/categories/{id}", categoryId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\": \"" + newName + "\"}"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Category not found"));
    }

    @Test
    void updateCategoryName_DuplicateGiven_ShouldReturnConflict() throws Exception {
        UUID categoryId = UUID.randomUUID();
        String newName = "ExistingCategoryName";

        when(categoryService.updateCategory(any(), any()))
                .thenThrow(new AlreadyExistsInDB("ExistingCategoryName"));

        mockMvc.perform(patch("/categories/{id}", categoryId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\": \"" + newName + "\"}"))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.message").value("ExistingCategoryName already exists."));
    }

    @Test
    void updateCategoryStatus_ValidArgumentGiven_ShouldUpdateCategoryStatus() throws Exception {
        UUID categoryId = UUID.randomUUID();
        CategoryChangeRequest request = new CategoryChangeRequest(null, false);
        Category updatedCategory = new Category(categoryId, "SomeCategory", request.active(), Instant.now(), null);

        when(categoryService.updateCategory(any(), any())).thenReturn(updatedCategory);

        mockMvc.perform(patch("/categories/{id}", categoryId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(categoryId.toString()))
                .andExpect(jsonPath("$.active").value(request.active().toString()));
    }

    @Test
    void updateCategoryStatus_InvalidArgumentGiven_ShouldReturnOk() throws Exception {
        UUID categoryId = UUID.randomUUID();
        CategoryChangeRequest request = new CategoryChangeRequest(null, null);

        mockMvc.perform(patch("/categories/{id}", categoryId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk());
    }

    @Test
    void updateCategoryStatus_NonExistentCategory_ShouldReturnNotFound() throws Exception {
        UUID categoryId = UUID.randomUUID();
        CategoryChangeRequest request = new CategoryChangeRequest(null, false);

        when(categoryService.updateCategory(any(), any()))
                .thenThrow(new DBException("Category not found"));

        mockMvc.perform(patch("/categories/{id}", categoryId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Category not found"));
    }

}
