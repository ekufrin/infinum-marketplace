package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.model.AdReport;
import com.ekufrin.infinum.marketplace.repository.AdReportRepository;
import com.ekufrin.infinum.marketplace.service.AdReportService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AdReportServiceTest {

    @Mock
    private AdReportRepository adReportRepository;

    @InjectMocks
    private AdReportService adReportService;

    @Test
    void getAllAdReports_returnsPagedResults_whenReportsExist() {
        Pageable pageable = PageRequest.of(0, 10);
        AdReport adReport = new AdReport();
        adReport.setId(UUID.randomUUID());
        Page<AdReport> expectedPage = new PageImpl<>(List.of(adReport));

        when(adReportRepository.findAll(pageable)).thenReturn(expectedPage);

        Page<AdReport> result = adReportService.getAllAdReports(pageable);

        assertThat(result).isNotNull();
        assertThat(result.getContent()).hasSize(1);
        assertThat(result.getContent().getFirst().getId()).isEqualTo(adReport.getId());
    }

    @Test
    void getAllAdReports_returnsEmptyPage_whenNoReportsExist() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<AdReport> expectedPage = Page.empty();

        when(adReportRepository.findAll(pageable)).thenReturn(expectedPage);

        Page<AdReport> result = adReportService.getAllAdReports(pageable);

        assertThat(result).isNotNull();
        assertThat(result.getContent()).isEmpty();
    }

    @Test
    void returnsAdReport_whenIdExists() {
        UUID id = UUID.randomUUID();
        Optional<AdReport> adReport = Optional.of(new AdReport());
        adReport.get().setId(id);

        when(adReportRepository.findAdReportById(id)).thenReturn(adReport);

        AdReport result = adReportService.getAdReportById(id);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(id);
    }
}
