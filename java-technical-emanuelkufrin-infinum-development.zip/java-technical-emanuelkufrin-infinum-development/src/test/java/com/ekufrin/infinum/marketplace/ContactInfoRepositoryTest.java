package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.repository.ContactInfoRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.ActiveProfiles;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
class ContactInfoRepositoryTest {
    @Autowired
    private ContactInfoRepository contactInfoRepository;

    @Test
    void FindAllByUserId_ValidArgumentGiven_ShouldReturnListOfContactInfos() {
        var contactInfos = contactInfoRepository.findAllByUser_Id(UUID.fromString("8d5cfe7c-1e1b-4a1e-b8f0-111111111111"), PageRequest.of(0, 10));
        assertThat(contactInfos).isNotEmpty();
        assertThat(contactInfos.getContent().getFirst().getEmail()).isEqualTo("contact1@example.com");
        assertThat(contactInfos.getTotalElements()).isEqualTo(1);
    }

    @Test
    void FindAllByUserId_InvalidArgumentGiven_ShouldReturnEmptyList() {
        var contactInfos = contactInfoRepository.findAllByUser_Id(UUID.fromString("00000000-0000-0000-0000-000000000000"), PageRequest.of(0, 10));
        assertThat(contactInfos).isEmpty();
    }
}
