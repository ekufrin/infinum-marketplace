package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.repository.AdRepository;
import com.ekufrin.infinum.marketplace.repository.ConversationRepository;
import com.ekufrin.infinum.marketplace.service.ConversationService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.UUID;

@ExtendWith(MockitoExtension.class)
class ConversationServiceTest {

    @Mock
    private ConversationRepository conversationRepository;

    @Mock
    private AdRepository adRepository;

    @InjectMocks
    private ConversationService conversationService;

    @Test
    void startConversation_NoExistingConversationAndValidAuthor_ShouldCreateAndSaveConversation() {
        UUID adId = UUID.randomUUID();
        UUID authorId = UUID.randomUUID();
        UUID visitorId = UUID.randomUUID();
        org.springframework.security.core.userdetails.UserDetails userDetails = org.mockito.Mockito.mock(org.springframework.security.core.userdetails.UserDetails.class);

        org.mockito.Mockito.when(userDetails.getUsername()).thenReturn(visitorId.toString());
        org.mockito.Mockito.when(adRepository.getAuthorIdByAdId(adId)).thenReturn(Optional.of(authorId));
        org.mockito.Mockito.when(conversationRepository.findByAdIdAndVisitorId(adId, visitorId)).thenReturn(Optional.empty());
        org.mockito.Mockito.when(conversationRepository.save(org.mockito.Mockito.any(com.ekufrin.infinum.marketplace.model.Conversation.class))).thenAnswer(invocation -> invocation.getArgument(0));

        com.ekufrin.infinum.marketplace.model.Conversation result = conversationService.startConversation(adId, userDetails);

        org.assertj.core.api.Assertions.assertThat(result).isNotNull();
        org.assertj.core.api.Assertions.assertThat(result.getAdId()).isEqualTo(adId);
        org.assertj.core.api.Assertions.assertThat(result.getVisitorId()).isEqualTo(visitorId);
        org.assertj.core.api.Assertions.assertThat(result.getAuthorId()).isEqualTo(authorId);
        org.assertj.core.api.Assertions.assertThat(result.getCreatedAt()).isNotNull();
        org.mockito.Mockito.verify(conversationRepository).save(result);
    }

    @Test
    void startConversation_ExistingConversationFoundAndValidAuthor_ShouldReturnExistingWithoutSaving() {
        UUID adId = UUID.randomUUID();
        UUID visitorId = UUID.randomUUID();
        org.springframework.security.core.userdetails.UserDetails userDetails = org.mockito.Mockito.mock(org.springframework.security.core.userdetails.UserDetails.class);
        com.ekufrin.infinum.marketplace.model.Conversation existing = new com.ekufrin.infinum.marketplace.model.Conversation();
        existing.setAdId(adId);
        existing.setVisitorId(visitorId);
        existing.setAuthorId(UUID.randomUUID());
        existing.setCreatedAt(java.time.Instant.now());

        org.mockito.Mockito.when(userDetails.getUsername()).thenReturn(visitorId.toString());
        org.mockito.Mockito.when(adRepository.getAuthorIdByAdId(adId)).thenReturn(Optional.of(UUID.randomUUID()));
        org.mockito.Mockito.when(conversationRepository.findByAdIdAndVisitorId(adId, visitorId)).thenReturn(Optional.of(existing));

        com.ekufrin.infinum.marketplace.model.Conversation result = conversationService.startConversation(adId, userDetails);

        org.assertj.core.api.Assertions.assertThat(result).isSameAs(existing);
        org.mockito.Mockito.verify(conversationRepository, org.mockito.Mockito.never()).save(org.mockito.Mockito.any());
    }

    @Test
    void startConversation_AdAuthorMissing_ShouldThrowDBException() {
        UUID adId = UUID.randomUUID();
        org.mockito.Mockito.when(adRepository.getAuthorIdByAdId(adId)).thenReturn(Optional.empty());

        org.assertj.core.api.Assertions.assertThatThrownBy(() -> conversationService.startConversation(adId, org.mockito.Mockito.mock(org.springframework.security.core.userdetails.UserDetails.class))).isInstanceOf(com.ekufrin.infinum.marketplace.exception.DBException.class).hasMessage("Ad author not found");
    }

    @Test
    void startConversation_UserDetailsNullAndValidAuthor_ShouldCreateWithDefaultVisitor() {
        UUID adId = UUID.randomUUID();
        UUID authorId = UUID.randomUUID();
        UUID defaultVisitorId = UUID.fromString("00000000-0000-0000-0000-000000000000");

        org.mockito.Mockito.when(adRepository.getAuthorIdByAdId(adId)).thenReturn(Optional.of(authorId));
        org.mockito.Mockito.when(conversationRepository.findByAdIdAndVisitorId(adId, defaultVisitorId)).thenReturn(Optional.empty());
        org.mockito.Mockito.when(conversationRepository.save(org.mockito.Mockito.any(com.ekufrin.infinum.marketplace.model.Conversation.class))).thenAnswer(invocation -> invocation.getArgument(0));

        com.ekufrin.infinum.marketplace.model.Conversation result = conversationService.startConversation(adId, null);

        org.assertj.core.api.Assertions.assertThat(result).isNotNull();
        org.assertj.core.api.Assertions.assertThat(result.getAdId()).isEqualTo(adId);
        org.assertj.core.api.Assertions.assertThat(result.getVisitorId()).isEqualTo(defaultVisitorId);
        org.assertj.core.api.Assertions.assertThat(result.getAuthorId()).isEqualTo(authorId);
        org.assertj.core.api.Assertions.assertThat(result.getCreatedAt()).isNotNull();
        org.mockito.Mockito.verify(conversationRepository).save(result);
    }

    @Test
    void startConversation_UsernameNotUuidAndValidAuthor_ShouldThrowIllegalArgument() {
        UUID adId = UUID.randomUUID();
        org.springframework.security.core.userdetails.UserDetails userDetails = org.mockito.Mockito.mock(org.springframework.security.core.userdetails.UserDetails.class);

        org.mockito.Mockito.when(adRepository.getAuthorIdByAdId(adId)).thenReturn(Optional.of(UUID.randomUUID()));
        org.mockito.Mockito.when(userDetails.getUsername()).thenReturn("not-a-uuid");

        org.assertj.core.api.Assertions.assertThatThrownBy(() -> conversationService.startConversation(adId, userDetails)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void startConversation_ReturningExistingConversationWithExistingCreatedAt_ShouldPreserveTimestamp() {
        UUID adId = UUID.randomUUID();
        UUID visitorId = UUID.randomUUID();
        java.time.Instant createdAt = java.time.Instant.now().minusSeconds(60);
        org.springframework.security.core.userdetails.UserDetails userDetails = org.mockito.Mockito.mock(org.springframework.security.core.userdetails.UserDetails.class);
        com.ekufrin.infinum.marketplace.model.Conversation existing = new com.ekufrin.infinum.marketplace.model.Conversation();
        existing.setAdId(adId);
        existing.setVisitorId(visitorId);
        existing.setAuthorId(UUID.randomUUID());
        existing.setCreatedAt(createdAt);

        org.mockito.Mockito.when(userDetails.getUsername()).thenReturn(visitorId.toString());
        org.mockito.Mockito.when(adRepository.getAuthorIdByAdId(adId)).thenReturn(Optional.of(UUID.randomUUID()));
        org.mockito.Mockito.when(conversationRepository.findByAdIdAndVisitorId(adId, visitorId)).thenReturn(Optional.of(existing));

        com.ekufrin.infinum.marketplace.model.Conversation result = conversationService.startConversation(adId, userDetails);

        org.assertj.core.api.Assertions.assertThat(result.getCreatedAt()).isEqualTo(createdAt);
    }
}


