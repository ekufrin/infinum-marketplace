package com.ekufrin.infinum.marketplace;

import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.hasSize;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class OwnAdsControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private Flyway flyway;

    @BeforeEach
    void setUp() {
        flyway.clean();
        flyway.migrate();
    }

    @AfterEach
    void tearDown() {
        flyway.clean();
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111")
    void getMyAds_AuthenticatedUser_ShouldReturnOnlyUsersAds() throws Exception {
        mockMvc.perform(get("/users/me/ads"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(1)))
                .andExpect(jsonPath("$.content[0].title").exists())
                .andExpect(jsonPath("$.totalElements").value(1))
                .andExpect(jsonPath("$.page").value(1));
    }

    @Test
    @WithMockUser(username = "f1a6b9e3-483b-41b7-81db-666666666666")
    void getMyAds_UserWithNoAds_ShouldReturnEmptyPage() throws Exception {
        mockMvc.perform(get("/users/me/ads"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(0)))
                .andExpect(jsonPath("$.totalElements").value(0))
                .andExpect(jsonPath("$.totalPages").value(0));
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111")
    void getMyAds_SortByTitle_ShouldReturnSortedAds() throws Exception {
        mockMvc.perform(get("/users/me/ads")
                        .param("sort", "title,asc"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content[0].title").exists());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111")
    void getMyAds_DefaultSort_ShouldSortByStatusDesc() throws Exception {
        mockMvc.perform(get("/users/me/ads"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content[0].status").exists());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111")
    void getMyAds_Pagination_ShouldReturnCorrectPage() throws Exception {
        mockMvc.perform(get("/users/me/ads")
                        .param("page", "0")
                        .param("size", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(1)))
                .andExpect(jsonPath("$.totalElements").value(1))
                .andExpect(jsonPath("$.totalPages").value(1))
                .andExpect(jsonPath("$.page").value(1))
                .andExpect(jsonPath("$.size").value(1));
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111")
    void getMyAds_LastPage_ShouldReturnRemainingAds() throws Exception {
        mockMvc.perform(get("/users/me/ads")
                        .param("page", "1")
                        .param("size", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(1)))
                .andExpect(jsonPath("$.totalElements").value(1))
                .andExpect(jsonPath("$.totalPages").value(1))
                .andExpect(jsonPath("$.page").value(1))
                .andExpect(jsonPath("$.last").value(true));
    }

    @Test
    void getMyAds_UnauthenticatedUser_ShouldReturnUnauthorized() throws Exception {
        mockMvc.perform(get("/users/me/ads"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111")
    void getMyAds_DifferentStatuses_ShouldReturnAllStatuses() throws Exception {
        mockMvc.perform(get("/users/me/ads"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content[0].status").exists());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111")
    void getMyAds_SortByPriceDesc_ShouldReturnCorrectOrder() throws Exception {
        mockMvc.perform(get("/users/me/ads")
                        .param("sort", "price,desc"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content[0].price").exists());
    }
}