package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.repository.TokenBlacklistRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TokenBlacklistRepositoryTest {
    @Mock
    private TokenBlacklistRepository tokenBlacklistRepository;

    @Test
    void returnsTrue_WhenTokenExistsInBlacklist() {
        String token = "blacklistedToken";
        when(tokenBlacklistRepository.existsByToken(token)).thenReturn(true);

        boolean result = tokenBlacklistRepository.existsByToken(token);

        assertThat(result).isTrue();
    }

    @Test
    void returnsFalse_WhenTokenDoesNotExistInBlacklist() {
        String token = "nonBlacklistedToken";
        when(tokenBlacklistRepository.existsByToken(token)).thenReturn(false);

        boolean result = tokenBlacklistRepository.existsByToken(token);

        assertThat(result).isFalse();
    }
}
