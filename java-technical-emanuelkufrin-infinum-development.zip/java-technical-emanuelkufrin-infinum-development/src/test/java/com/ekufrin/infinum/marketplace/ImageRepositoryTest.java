package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.model.Image;
import com.ekufrin.infinum.marketplace.repository.ImageRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
class ImageRepositoryTest {
    @Autowired
    private ImageRepository imageRepository;

    @Test
    void FindAllByIdInAndAdIsNull_ShouldReturnEmptyList_WhenNoImagesFound() {
        List<Image> result = imageRepository.findAllByIdInAndAdIsNull(
                java.util.List.of(java.util.UUID.randomUUID(), java.util.UUID.randomUUID())
        );
        assertThat(result).isEmpty();
    }

    @Test
    void FindAllByIdInAndAdIsNull_ShouldReturnImages_WhenImagesFound() {
        UUID imageId1 = UUID.fromString("eeeeeee3-eeee-eeee-eeee-eeeeeeeeeeee");
        UUID imageId2 = UUID.fromString("eeeeeee4-eeee-eeee-eeee-eeeeeeeeeeee");
        List<Image> result = imageRepository.findAllByIdInAndAdIsNull(
                java.util.List.of(imageId1, imageId2)
        );
        assertThat(result).hasSize(2);
        assertThat(result.get(0).getId()).isIn(imageId1, imageId2);
        assertThat(result.get(1).getId()).isIn(imageId1, imageId2);
    }
}
