package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.enums.Condition;
import com.ekufrin.infinum.marketplace.model.Ad;
import com.ekufrin.infinum.marketplace.repository.AdRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
class AdRepositoryTest {
    @Autowired
    private AdRepository adRepository;

    @Test
    void findByIdWithImages_ShouldReturnAdWithImages_WhenAdExists() {
        var ad = adRepository.findByIdWithImages(java.util.UUID.fromString("ddddddd1-dddd-dddd-dddd-dddddddddddd"));
        assertThat(ad).isPresent();
        assertThat(ad.get().getTitle()).isEqualTo("iPhone 13");
        assertThat(ad.get().getImages()).hasSize(1);
    }

    @Test
    void findByIdWithImages_ShouldReturnEmpty_WhenAdDoesNotExist() {
        var ad = adRepository.findByIdWithImages(java.util.UUID.randomUUID());
        assertThat(ad).isNotPresent();
    }

    @Test
    void findAllFiltered_ShouldReturnIPhone_WhenTitleContainsIphone() {
        Page<Ad> page = adRepository.findAllFiltered("iphone", null, null, null, null, PageRequest.of(0, 10));
        assertThat(page.getTotalElements()).isEqualTo(1);
        assertThat(page.getContent().get(0).getTitle()).isEqualTo("iPhone 13");
    }

    @Test
    void findAllFiltered_ShouldReturnAllActiveAds_WhenTitleEmptyString() {
        Page<Ad> page = adRepository.findAllFiltered("", null, null, null, null, PageRequest.of(0, 20));
        assertThat(page.getTotalElements()).isEqualTo(6);
    }

    @Test
    void findAllFiltered_ShouldReturnNoResults_WhenMinPriceGreaterThanMaxPrice() {
        Page<Ad> page = adRepository.findAllFiltered(null, null, null, 1000.0, 100.0, PageRequest.of(0, 10));
        assertThat(page.getTotalElements()).isZero();
    }

    @Test
    void findAllFiltered_ShouldReturnGamingLaptop_WhenCombinedFiltersMatch() {
        Page<Ad> page = adRepository.findAllFiltered("gaming", "Electronics", Condition.USED, 800.0, 900.0, PageRequest.of(0, 10));
        assertThat(page.getTotalElements()).isEqualTo(1);
        assertThat(page.getContent().getFirst().getTitle()).isEqualTo("Gaming Laptop");
    }

    @Test
    void findAllFiltered_ShouldSortByPriceAscending() {
        Page<Ad> page = adRepository.findAllFiltered(null, null, null, null, null, PageRequest.of(0, 10, Sort.by("price").ascending()));
        assertThat(page.getTotalElements()).isEqualTo(6);
        assertThat(page.getContent().getFirst().getPrice()).isEqualTo(20.0);
        assertThat(page.getContent().getLast().getPrice()).isEqualTo(1200.0);
    }

    @Test
    void findAllFiltered_ShouldSortByPriceDescending() {
        Page<Ad> page = adRepository.findAllFiltered(null, null, null, null, null, PageRequest.of(0, 10, Sort.by("price").descending()));
        assertThat(page.getTotalElements()).isEqualTo(6);
        assertThat(page.getContent().getFirst().getPrice()).isEqualTo(1200.0);
        assertThat(page.getContent().getLast().getPrice()).isEqualTo(20.0);
    }

    @Test
    void findAllFiltered_ShouldFilterByCategoryAndCondition_ElectronicsUsedReturnsTwo() {
        Page<Ad> page = adRepository.findAllFiltered(null, "Electronics", Condition.USED, null, null, PageRequest.of(0, 10));
        assertThat(page.getTotalElements()).isEqualTo(2);
        assertThat(page.getContent()).allMatch(a -> a.getCategory().getName().equalsIgnoreCase("Electronics") && a.getCondition() == Condition.USED);
    }

    @Test
    void findAllFiltered_ShouldFilterByCategoryAndCondition_BooksNewReturnsOne() {
        Page<Ad> page = adRepository.findAllFiltered(null, "Books", Condition.NEW, null, null, PageRequest.of(0, 10));
        assertThat(page.getTotalElements()).isEqualTo(1);
        assertThat(page.getContent().getFirst().getTitle()).isEqualTo("Book: Java Basics");
        assertThat(page.getContent().getFirst().getCondition()).isEqualTo(Condition.NEW);
    }

    @Test
    void findAllByAuthorId_ShouldReturnOnlyAuthorsAds_WhenAuthorHasAds() {
        UUID authorId = UUID.fromString("8d5cfe7c-1e1b-4a1e-b8f0-111111111111");

        Page<Ad> page = adRepository.findAllByAuthorId(authorId, PageRequest.of(0, 10));

        assertThat(page.getTotalElements()).isEqualTo(1);
        assertThat(page.getContent().getFirst().getTitle()).isEqualTo("iPhone 13");
        assertThat(page.getContent()).allMatch(ad -> ad.getAuthor().getId().equals(authorId));
    }

    @Test
    void findAllByAuthorId_ShouldReturnEmptyPage_WhenAuthorHasNoAds() {
        UUID authorWithNoAds = UUID.fromString("f1a6b9e3-483b-41b7-81db-666666666666");

        Page<Ad> page = adRepository.findAllByAuthorId(authorWithNoAds, PageRequest.of(0, 10));

        assertThat(page.getTotalElements()).isZero();
        assertThat(page.getContent()).isEmpty();
    }

    @Test
    void findAllByAuthorId_ShouldReturnEmptyPage_WhenAuthorDoesNotExist() {
        UUID nonExistentAuthor = UUID.randomUUID();

        Page<Ad> page = adRepository.findAllByAuthorId(nonExistentAuthor, PageRequest.of(0, 10));

        assertThat(page.getTotalElements()).isZero();
    }

    @Test
    void findAllByAuthorId_ShouldSupportPagination_WhenAuthorHasMultipleAds() {
        UUID authorId = UUID.fromString("c4c9a87b-3efb-41c8-bbb0-333333333333");

        Page<Ad> page = adRepository.findAllByAuthorId(authorId, PageRequest.of(0, 1));

        assertThat(page.getTotalElements()).isEqualTo(1);
        assertThat(page.getSize()).isEqualTo(1);
        assertThat(page.getContent().getFirst().getTitle()).isEqualTo("Kitchen Table");
    }

    @Test
    void findAllByAuthorId_ShouldSupportSorting_WhenSortingByTitle() {
        UUID authorId = UUID.fromString("8d5cfe7c-1e1b-4a1e-b8f0-111111111111");

        Page<Ad> page = adRepository.findAllByAuthorId(authorId, PageRequest.of(0, 10, Sort.by("title").ascending()));

        assertThat(page.getTotalElements()).isEqualTo(1);
        assertThat(page.getContent().getFirst().getTitle()).isEqualTo("iPhone 13");
    }

    @Test
    void findAllByAuthorId_ShouldIncludeAllStatuses_NotOnlyActive() {
        UUID authorId = UUID.fromString("8d5cfe7c-1e1b-4a1e-b8f0-111111111111");

        Page<Ad> page = adRepository.findAllByAuthorId(authorId, PageRequest.of(0, 10));

        assertThat(page.getTotalElements()).isEqualTo(1);
        assertThat(page.getContent()).anyMatch(ad -> ad.getStatus() != null);
    }

    @Test
    void findAdsExpiringBetween_ShouldReturnAds_WhenAdsExpireWithinRange() {
        List<Ad> result = adRepository.findExpiredAds();

        assertThat(result).hasSize(6);
        assertThat(result).extracting(Ad::getTitle).containsExactlyInAnyOrder("iPhone 13",
                "Book: Java Basics",
                "Gaming Laptop",
                "Kitchen Table",
                "Road bike",
                "Microwave");
    }

    @Test
    void findAdsExpiringBetween_ShouldExcludeAds_WhenExpirationNotifiedAtIsNotNull() {
        List<Ad> result = adRepository.findExpiredAds();

        assertThat(result).extracting(Ad::getTitle).doesNotContain("Quadcopter Drone");
    }

}
