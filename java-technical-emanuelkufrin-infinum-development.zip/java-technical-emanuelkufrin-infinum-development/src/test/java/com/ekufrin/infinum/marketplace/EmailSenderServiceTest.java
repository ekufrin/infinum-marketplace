package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.service.EmailSenderService;
import com.sendgrid.Method;
import com.sendgrid.Request;
import com.sendgrid.Response;
import com.sendgrid.SendGrid;
import jakarta.validation.constraints.Email;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class EmailSenderServiceTest {

    @Mock
    private SendGrid sendGrid;

    @Mock
    private Email fromEmail;

    @InjectMocks
    private EmailSenderService emailSenderService;

    @Test
    void sendEmail_ShouldSendEmailSuccessfully_WhenValidInputsProvided() throws IOException {
        String toAddress = "recipient@example.com";
        String templateId = "template-id";
        Map<String, Object> dynamicData = Map.of("key", "value");

        Response mockResponse = new Response(202, "Accepted", null);
        when(sendGrid.api(any(Request.class))).thenReturn(mockResponse);

        emailSenderService.sendEmail(toAddress, templateId, dynamicData);

        verify(sendGrid).api(argThat(request ->
                request.getMethod() == Method.POST &&
                        request.getEndpoint().equals("mail/send") &&
                        request.getBody().contains(templateId)
        ));
    }

    @Test
    void sendEmail_ShouldThrowIOException_WhenSendGridApiFails() throws IOException {
        String toAddress = "recipient@example.com";
        String templateId = "template-id";
        Map<String, Object> dynamicData = Map.of("key", "value");

        when(sendGrid.api(any(Request.class))).thenThrow(new IOException("API error"));

        assertThatThrownBy(() -> emailSenderService.sendEmail(toAddress, templateId, dynamicData))
                .isInstanceOf(IOException.class)
                .hasMessage("API error");

        verify(sendGrid).api(any(Request.class));
    }

    @Test
    void sendEmail_ShouldLogResponseStatus_WhenEmailSent() throws IOException {
        String toAddress = "recipient@example.com";
        String templateId = "template-id";
        Map<String, Object> dynamicData = Map.of("key", "value");

        Response mockResponse = new Response(200, "OK", null);
        when(sendGrid.api(any(Request.class))).thenReturn(mockResponse);

        emailSenderService.sendEmail(toAddress, templateId, dynamicData);

        verify(sendGrid).api(any(Request.class));
    }
}
