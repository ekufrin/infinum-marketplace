package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.controller.ConversationController;
import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.model.Conversation;
import com.ekufrin.infinum.marketplace.service.ConversationService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ConversationController.class)
class ConversationControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockitoBean
    private ConversationService conversationService;

    @WithMockUser(username = "testuser")
    @Test
    void startConversation_withValidAdId_shouldReturnConversation() throws Exception {
        UUID adId = UUID.randomUUID();
        Conversation conversation = new Conversation();
        conversation.setId(UUID.randomUUID());

        when(conversationService.startConversation(eq(adId), any(UserDetails.class))).thenReturn(conversation);

        mockMvc.perform(post("/conversations/start/{adId}", adId)
                        .with(csrf()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(conversation.getId().toString()));

        verify(conversationService).startConversation(eq(adId), any(UserDetails.class));
    }

    @WithMockUser(username = "testuser")
    @Test
    void startConversation_withInvalidAdId_shouldReturnNotFound() throws Exception {
        UUID adId = UUID.randomUUID();

        when(conversationService.startConversation(eq(adId), any(UserDetails.class)))
                .thenThrow(new DBException("Ad not found"));

        mockMvc.perform(post("/conversations/start/{adId}", adId)
                        .with(csrf()))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.error").value("Not Found"));

        verify(conversationService).startConversation(eq(adId), any(UserDetails.class));
    }

    @Test
    void startConversation_withoutAuthentication_shouldReturnUnauthorized() throws Exception {
        UUID adId = UUID.randomUUID();

        mockMvc.perform(post("/conversations/start/{adId}", adId)
                        .with(csrf()))
                .andExpect(status().isUnauthorized());

        verifyNoInteractions(conversationService);
    }

    @WithMockUser(username = "testuser")
    @Test
    void startConversation_withoutCsrfToken_shouldReturnForbidden() throws Exception {
        UUID adId = UUID.randomUUID();

        mockMvc.perform(post("/conversations/start/{adId}", adId))
                .andExpect(status().isForbidden());

        verifyNoInteractions(conversationService);
    }

}
