package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.controller.ChatController;
import com.ekufrin.infinum.marketplace.dto.ChatMessageSendRequest;
import com.ekufrin.infinum.marketplace.model.Conversation;
import com.ekufrin.infinum.marketplace.model.Message;
import com.ekufrin.infinum.marketplace.service.ChatService;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import java.security.Principal;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@SpringBootTest
@AutoConfigureMockMvc
class ChatControllerTest {

    @Autowired
    private ChatController chatController;

    @MockitoBean
    private ChatService chatService;

    @MockitoBean
    private SimpMessagingTemplate simpMessagingTemplate;

    @Test
    @WithMockUser(username = "testuser")
    void sendMessage_callsServiceAndPublishes() {
        Conversation conversation = new Conversation();
        conversation.setId(UUID.randomUUID());

        Message saved = new Message();
        saved.setId(UUID.randomUUID());
        saved.setConversation(conversation);
        saved.setContent("hello");

        ChatMessageSendRequest request = new ChatMessageSendRequest(conversation.getId(), "hello");
        Principal mockPrincipal = () -> "testuser";

        doReturn(saved).when(chatService).save(any(ChatMessageSendRequest.class), any(Principal.class));

        chatController.sendMessage(request, mockPrincipal);

        verify(chatService).save(any(ChatMessageSendRequest.class), any(Principal.class));
        ArgumentCaptor<String> destinationCaptor = ArgumentCaptor.forClass(String.class);
        verify(simpMessagingTemplate).convertAndSend(destinationCaptor.capture(), eq(saved));
        assertThat(destinationCaptor.getValue()).isEqualTo("/topic/conversation." + conversation.getId());
    }

    @Test
    @WithMockUser(username = "testuser")
    void sendMessage_whenServiceThrows_shouldNotBroadcast() {
        ChatMessageSendRequest request = new ChatMessageSendRequest(UUID.randomUUID(), "Fail");
        Principal mockPrincipal = () -> "testuser";

        doThrow(new RuntimeException("service error"))
                .when(chatService).save(any(ChatMessageSendRequest.class), any(Principal.class));

        try {
            chatController.sendMessage(request, mockPrincipal);
        } catch (RuntimeException e) {
            assertThat(e.getMessage()).isEqualTo("service error");
        }

        verify(chatService).save(any(ChatMessageSendRequest.class), any(Principal.class));
        verifyNoInteractions(simpMessagingTemplate);
    }
}
