package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.dto.ChatMessageSendRequest;
import com.ekufrin.infinum.marketplace.model.Conversation;
import com.ekufrin.infinum.marketplace.model.Message;
import com.ekufrin.infinum.marketplace.repository.ConversationRepository;
import com.ekufrin.infinum.marketplace.repository.MessageRepository;
import com.ekufrin.infinum.marketplace.service.ChatService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.security.Principal;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ChatServiceTest {

    @Mock
    private ConversationRepository conversationRepository;
    @Mock
    private MessageRepository messageRepository;
    @InjectMocks
    private ChatService chatService;

    @Test
    void save_ConversationExistsAndPrincipalProvided_ShouldSaveMessage() {
        UUID conversationId = UUID.randomUUID();
        UUID senderId = UUID.randomUUID();
        Conversation conversation = new Conversation();
        conversation.setId(conversationId);
        ChatMessageSendRequest request = new ChatMessageSendRequest(conversationId, "Hello");
        Principal principal = mock(Principal.class);

        when(principal.getName()).thenReturn(senderId.toString());
        when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(conversationRepository.existsByIdAndAuthorIdOrVisitorId(conversationId, senderId))
                .thenReturn(true);
        when(messageRepository.save(any(Message.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        Message result = chatService.save(request, principal);

        assertThat(result).isNotNull();
        assertThat(result.getConversation()).isEqualTo(conversation);
        assertThat(result.getSenderId()).isEqualTo(senderId);
        assertThat(result.getContent()).isEqualTo("Hello");
        assertThat(result.getSentAt()).isNotNull();
        verify(messageRepository).save(result);
    }

    @Test
    void save_PrincipalNull_ShouldSaveMessageWithDefaultSender() {
        UUID conversationId = UUID.randomUUID();
        UUID defaultSenderId = UUID.fromString("00000000-0000-0000-0000-000000000000");
        Conversation conversation = new Conversation();
        conversation.setId(conversationId);
        ChatMessageSendRequest request = new ChatMessageSendRequest(conversationId, "Hello");

        when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.save(any(Message.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));
        when(conversationRepository.existsByIdAndAuthorIdOrVisitorId(conversationId, defaultSenderId))
                .thenReturn(true);
        Message result = chatService.save(request, null);

        assertThat(result).isNotNull();
        assertThat(result.getConversation()).isEqualTo(conversation);
        assertThat(result.getSenderId()).isEqualTo(defaultSenderId);
        assertThat(result.getContent()).isEqualTo("Hello");
        assertThat(result.getSentAt()).isNotNull();
        verify(messageRepository).save(result);
    }

    @Test
    void save_ConversationNotFound_ShouldThrowDBException() {
        UUID conversationId = UUID.randomUUID();
        ChatMessageSendRequest request = new ChatMessageSendRequest(conversationId, "Hello");

        when(conversationRepository.findById(conversationId)).thenReturn(Optional.empty());
        when(conversationRepository.existsByIdAndAuthorIdOrVisitorId(any(), any()))
                .thenReturn(true);
        assertThatThrownBy(() -> chatService.save(request, null))
                .isInstanceOf(com.ekufrin.infinum.marketplace.exception.DBException.class)
                .hasMessage("Conversation not found");
    }

    @Test
    void save_PrincipalNameNotUuid_ShouldThrowIllegalArgument() {
        UUID conversationId = UUID.randomUUID();
        Conversation conversation = new Conversation();
        conversation.setId(conversationId);
        ChatMessageSendRequest request = new ChatMessageSendRequest(conversationId, "Hello");
        Principal principal = mock(Principal.class);

        when(principal.getName()).thenReturn("not-a-uuid");
        when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));

        assertThatThrownBy(() -> chatService.save(request, principal))
                .isInstanceOf(IllegalArgumentException.class);
    }
}
