package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.model.Category;
import com.ekufrin.infinum.marketplace.repository.CategoryRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
class CategoryRepositoryTest {
    @Autowired
    private CategoryRepository categoryRepository;

    @Test
    void findByName_ValidArgumentGiven_ShouldReturnCategory() {
        Category category = categoryRepository.findByName("Electronics");
        assertThat(category).isNotNull();
        assertThat(category.getName()).isEqualTo("Electronics");
    }

    @Test
    void existsByName_ValidArgumentGiven_ShouldReturnTrue() {
        boolean exists = categoryRepository.existsByNameIgnoreCase("Books");
        assertThat(exists).isTrue();
    }

    @Test
    void existsByName_InvalidArgumentGiven_ShouldReturnFalse() {
        boolean exists = categoryRepository.existsByNameIgnoreCase("NonExistentCategory");
        assertThat(exists).isFalse();
    }
}
