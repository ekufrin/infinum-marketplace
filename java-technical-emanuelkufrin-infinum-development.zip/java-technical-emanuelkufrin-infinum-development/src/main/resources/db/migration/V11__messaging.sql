CREATE TABLE IF NOT EXISTS conversation
(
    id         UUID PRIMARY KEY,
    ad_id      UUID                     NOT NULL,
    author_id  UUID                     NOT NULL,
    visitor_id UUID                     NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS message
(
    id              UUID PRIMARY KEY,
    conversation_id UUID                     NOT NULL,
    sender_id       UUID                     NOT NULL,
    content         TEXT                     NOT NULL,
    sent_at         TIMESTAMP WITH TIME ZONE NOT NULL,
    CONSTRAINT fk_messages_conversation FOREIGN KEY (conversation_id) REFERENCES conversation (id) ON DELETE CASCADE
);