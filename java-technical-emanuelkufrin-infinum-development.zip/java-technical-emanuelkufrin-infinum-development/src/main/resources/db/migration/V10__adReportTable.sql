CREATE TABLE IF NOT EXISTS ad_report
(
    id            UUID PRIMARY KEY,
    ad_id         UUID                     NOT NULL,
    report_type   VARCHAR(50)              NOT NULL,
    report_reason TEXT                     NOT NULL,
    created_at    TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    reviewed_at   TIMESTAMP WITH TIME ZONE NULL,
    reviewed_by   UUID                     NULL,
    FOREIGN KEY (ad_id) REFERENCES ad (id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_by) REFERENCES app_user (id) ON DELETE SET NULL
);