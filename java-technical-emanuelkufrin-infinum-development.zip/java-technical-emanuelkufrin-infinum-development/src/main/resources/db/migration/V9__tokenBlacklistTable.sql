CREATE TABLE token_blacklist
(
    id         UUID PRIMARY KEY,
    token      VARCHAR(512)             NOT NULL UNIQUE,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL
);