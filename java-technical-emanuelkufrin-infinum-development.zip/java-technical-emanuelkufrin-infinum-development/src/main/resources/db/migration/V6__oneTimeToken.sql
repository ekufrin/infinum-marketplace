ALTER TABLE ad
    ADD COLUMN IF NOT EXISTS expiration_notified_at TIMESTAMP WITH TIME ZONE;

CREATE TABLE IF NOT EXISTS one_time_token
(
    id         UUID PRIMARY KEY,
    value      VARCHAR(255)             NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL
);
