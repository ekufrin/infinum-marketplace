CREATE TABLE IF NOT EXISTS audit_log
(
    id           UUID PRIMARY KEY,
    action       VARCHAR(255)             NOT NULL,
    entity       VARCHAR(255)             NOT NULL,
    entity_id    UUID,
    old_value    TEXT,
    new_value    TEXT,
    performed_by VARCHAR(255),
    performed_at TIMESTAMP WITH TIME ZONE NOT NULL
);
