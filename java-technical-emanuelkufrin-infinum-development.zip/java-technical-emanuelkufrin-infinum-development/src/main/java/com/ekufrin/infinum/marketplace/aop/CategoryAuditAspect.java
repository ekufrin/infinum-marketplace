package com.ekufrin.infinum.marketplace.aop;

import com.ekufrin.infinum.marketplace.model.Category;
import com.ekufrin.infinum.marketplace.service.AuditService;
import com.ekufrin.infinum.marketplace.service.CategoryService;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Aspect
@Component
public class CategoryAuditAspect {
    private final AuditService auditService;
    private final CategoryService categoryService;
    private final ThreadLocal<Category> previousCategory = new ThreadLocal<>();

    public CategoryAuditAspect(AuditService auditService, CategoryService categoryService) {
        this.categoryService = categoryService;
        this.auditService = auditService;
    }

    @AfterReturning(pointcut = "execution(* com.ekufrin.infinum.marketplace.controller.CategoryController.addCategory(..))", returning = "result")
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void logCategoryCreation(JoinPoint joinPoint, Object result) {
        if (!(result instanceof ResponseEntity<?> response)) {
            auditService.log("CREATE_CATEGORY", "Category", null, null, null, currentUser());
            return;
        }
        Object body = response.getBody();
        if (body instanceof Category category) {
            auditService.log("CREATE_CATEGORY", "Category", category.getId(), null, category.getName(), currentUser());
        } else {
            auditService.log("CREATE_CATEGORY", "Category", null, null, body, currentUser());
        }
    }

    @Before("execution(* com.ekufrin.infinum.marketplace.controller.CategoryController.updateCategory(..))")
    public void saveCurrentCategory(JoinPoint joinPoint) {
        Object[] args = joinPoint.getArgs();
        UUID idArg = null;
        if (args != null && args.length >= 1) {
            Object idObj = args[0];
            if (idObj instanceof String idStr) {
                try {
                    idArg = UUID.fromString(idStr);
                } catch (IllegalArgumentException _) {

                }
            } else if (idObj instanceof UUID uuid) {
                idArg = uuid;
            }
        }
        if (idArg != null) {
            try {
                Optional<Category> opt = categoryService.findById(idArg);
                if (opt.isEmpty()) {
                    previousCategory.remove();
                    return;
                }
                Category category = opt.get();
                categoryService.detach(category);
                Category clone = new Category();
                clone.setId(category.getId());
                clone.setName(category.getName());
                clone.setActive(category.getActive());
                clone.setCreatedAt(category.getCreatedAt());
                previousCategory.set(clone);
            } catch (Exception e) {
                previousCategory.remove();
            }
        } else {
            previousCategory.remove();
        }
    }

    @AfterReturning(pointcut = "execution(* com.ekufrin.infinum.marketplace.controller.CategoryController.updateCategory(..))", returning = "result")
    public void logCategoryUpdate(JoinPoint joinPoint, Object result) {
        Category oldCategory = previousCategory.get();

        try {
            if (!(result instanceof ResponseEntity<?> response)) return;

            Object body = response.getBody();
            if (!(body instanceof Category category)) return;

            if (oldCategory != null) {
                if (!Objects.equals(oldCategory.getName(), category.getName())) {
                    auditService.log(
                            "UPDATE_CATEGORY_NAME",
                            "Category",
                            category.getId(),
                            oldCategory.getName(),
                            category.getName(),
                            currentUser()
                    );
                }

                if (!Objects.equals(oldCategory.getActive(), category.getActive())) {
                    auditService.log(
                            "UPDATE_CATEGORY_ACTIVE",
                            "Category",
                            category.getId(),
                            oldCategory.getActive(),
                            category.getActive(),
                            currentUser()
                    );
                }
            }

        } finally {
            previousCategory.remove();
        }
    }


    private String currentUser() {
        try {
            return SecurityContextHolder.getContext().getAuthentication().getName();
        } catch (Exception _) {
            return "system";
        }
    }
}