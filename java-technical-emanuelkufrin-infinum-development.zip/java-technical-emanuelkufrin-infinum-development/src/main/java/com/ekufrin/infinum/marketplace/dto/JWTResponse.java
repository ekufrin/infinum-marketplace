package com.ekufrin.infinum.marketplace.dto;

public record JWTResponse(String token, String tokenType, long expiresIn) {
}
