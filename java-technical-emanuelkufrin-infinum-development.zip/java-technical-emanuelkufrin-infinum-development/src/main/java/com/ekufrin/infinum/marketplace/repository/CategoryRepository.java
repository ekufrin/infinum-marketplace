package com.ekufrin.infinum.marketplace.repository;

import com.ekufrin.infinum.marketplace.model.Category;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.UUID;

public interface CategoryRepository extends JpaRepository<Category, UUID> {
    Category findByName(String name);

    boolean existsByNameIgnoreCase(String name);

    @Query("""
                SELECT c FROM Category c
                WHERE
                    (
                        COALESCE(:search, '') = ''
                        OR LOWER(c.name) LIKE LOWER(CONCAT('%', :search, '%'))
                    )
                    AND (
                        :active IS NULL
                        OR c.active = :active
                    )
            """)
    Page<Category> findAllFiltered(
            @Param("search") String search,
            @Param("active") Boolean active,
            Pageable pageable
    );

    Category findByNameIgnoreCase(String name);

    Optional<Category> findByIdAndActiveIsTrue(UUID id);
}
