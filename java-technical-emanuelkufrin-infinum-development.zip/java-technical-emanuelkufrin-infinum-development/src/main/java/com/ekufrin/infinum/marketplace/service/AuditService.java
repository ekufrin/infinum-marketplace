package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.model.AuditLog;
import com.ekufrin.infinum.marketplace.repository.AuditLogRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

@Service
public class AuditService {
    private final AuditLogRepository auditLogRepository;

    public AuditService(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    public void log(String action, String entityName, UUID entityId, Object oldValue, Object newValue, String performedBy) {
        AuditLog log = new AuditLog.Builder()
                .action(action)
                .entity(entityName)
                .entityId(entityId)
                .oldValue(serialize(oldValue))
                .newValue(serialize(newValue))
                .performedBy(performedBy)
                .performedAt(Instant.now())
                .build();

        auditLogRepository.save(log);
    }

    private String serialize(Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception _) {
            return String.valueOf(obj);
        }
    }
}
