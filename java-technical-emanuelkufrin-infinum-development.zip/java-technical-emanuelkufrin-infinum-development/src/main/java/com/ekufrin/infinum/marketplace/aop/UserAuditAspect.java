package com.ekufrin.infinum.marketplace.aop;

import com.ekufrin.infinum.marketplace.dto.PunishmentCreateRequest;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.repository.UserRepository;
import com.ekufrin.infinum.marketplace.service.AuditService;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

@Aspect
@Component
public class UserAuditAspect {
    private static final Logger LOGGER = Logger.getLogger(UserAuditAspect.class.getName());
    private final AuditService auditService;
    private final UserRepository userRepository;

    public UserAuditAspect(AuditService auditService, UserRepository userRepository) {
        this.userRepository = userRepository;
        this.auditService = auditService;
    }

    @AfterReturning(pointcut = "execution(* com.ekufrin.infinum.marketplace.service.UserService.addUser(..))", returning = "result")
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void logUserCreation(JoinPoint joinPoint, Object result) {
        User user = (User) result;
        auditService.log(
                "CREATE_USER",
                "User",
                user.getId(),
                null,
                user,
                currentUser()
        );
    }

    @AfterReturning(pointcut = "execution(* com.ekufrin.infinum.marketplace.service.UserService.changeUserPassword(..))", returning = "result")
    public void logUserPasswordChange(JoinPoint joinPoint, Object result) {
        User user = (User) result;

        auditService.log(
                "CHANGE_USER_PASSWORD",
                "User",
                user.getId(),
                "PROTECTED",
                "PROTECTED",
                currentUser()
        );
    }

    @Around(value = "execution(* com.ekufrin.infinum.marketplace.service.UserService.punishUser(..)) && args(userId, request)", argNames = "pjp,userId,request")
    public Object auditPunishUser(ProceedingJoinPoint pjp, UUID userId, PunishmentCreateRequest request) throws RuntimeException {
        Optional<User> beforeOpt = userRepository.findById(userId);
        boolean previousActive = beforeOpt.map(User::isActive).orElse(true);
        String username = beforeOpt.map(User::getUserUsername).orElse("unknown");
        String email = beforeOpt.map(User::getEmail).orElse("unknown");

        try {
            Object result = pjp.proceed();
            Optional<User> afterOpt = userRepository.findById(userId);
            boolean newActive = afterOpt.map(User::isActive).orElse(previousActive);
            String message;
            if (request.message() == null && request.banUser()) {
                message = "Your account have been banned due to multiple violations of our terms of service.";
            } else {
                message = request.message() != null ? request.message() : null;
            }
            String auditEntry = String.format(
                    "previousActive=%s newActive=%s ban=%s reason=%s message=%s",
                    previousActive, newActive, request.banUser(), request.type(), message
            );
            auditService.log(
                    "PUNISH_USER",
                    "User",
                    userId,
                    null,
                    auditEntry,
                    currentUser()
            );
            return result;
        } catch (Throwable t) {
            String errorAudit = String.format(
                    "action=punishUser targetId=%s targetUsername=%s targetEmail=%s previousActive=%s ban=%s reason=%s message=%s",
                    userId, username, email, previousActive, request.banUser(), request.type(), request.message()
            );
            LOGGER.log(Level.WARNING, errorAudit, t);
            throw new RuntimeException(t);
        }
    }

    private String currentUser() {
        try {
            return SecurityContextHolder.getContext().getAuthentication().getName();
        } catch (Exception _) {
            return "system";
        }
    }
}
