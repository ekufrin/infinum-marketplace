package com.ekufrin.infinum.marketplace.repository;

import com.ekufrin.infinum.marketplace.model.Conversation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;
import java.util.UUID;

public interface ConversationRepository extends JpaRepository<Conversation, UUID> {
    Optional<Conversation> findByAdIdAndVisitorId(UUID adId, UUID currentUserId);

    @Query("""
                    SELECT CASE WHEN COUNT(c) > 0 THEN true ELSE false END
                    FROM Conversation c
                    WHERE c.id = :id AND (c.authorId = :userId OR c.visitorId = :userId)
            """)
    boolean existsByIdAndAuthorIdOrVisitorId(UUID id, UUID userId);

}
