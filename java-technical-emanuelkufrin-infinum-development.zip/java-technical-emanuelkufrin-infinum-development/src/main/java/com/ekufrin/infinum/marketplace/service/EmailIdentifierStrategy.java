package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.interfaces.UserIdentifierStrategy;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.repository.UserRepository;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class EmailIdentifierStrategy implements UserIdentifierStrategy {
    private final UserRepository repo;

    public EmailIdentifierStrategy(UserRepository repo) {
        this.repo = repo;
    }

    @Override
    public boolean supports(String identifier) {
        return identifier.contains("@");
    }

    @Override
    public Optional<User> findUser(String identifier) {
        return repo.findByEmail(identifier);
    }
}
