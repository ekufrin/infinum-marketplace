package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.dto.UserLoginRequest;
import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.exception.EmailException;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.repository.UserRepository;
import jakarta.transaction.Transactional;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.ott.GenerateOneTimeTokenRequest;
import org.springframework.security.authentication.ott.OneTimeToken;
import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationToken;
import org.springframework.security.authentication.ott.OneTimeTokenService;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@Service
public class AuthService {
    public static final Duration EXPIRES_IN = Duration.ofMinutes(5);
    private static final String TEMPLATE_ID = "d-7c797cde2ec24e6988e2633ef40ca76d";
    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final OneTimeTokenService oneTimeTokenService;
    private final EmailSenderService emailSenderService;
    @Value("${ott.renewal.url}")
    private String renewalUrl;

    public AuthService(AuthenticationManager authenticationManager, UserRepository userRepository, OneTimeTokenService oneTimeTokenService, EmailSenderService emailSenderService) {
        this.emailSenderService = emailSenderService;
        this.authenticationManager = authenticationManager;
        this.userRepository = userRepository;
        this.oneTimeTokenService = oneTimeTokenService;
    }

    public Optional<User> authenticate(@NotNull UserLoginRequest userLoginRequest) throws AuthenticationServiceException {
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(userLoginRequest.email(), userLoginRequest.password()));
        Optional<User> user = userRepository.findByEmail(userLoginRequest.email());
        if (user.isEmpty()) {
            return Optional.empty();
        }
        if (!user.get().isActive()) {
            throw new AuthenticationServiceException("User is not active");
        }
        return user;
    }

    public void createAndSendOTTokenEmail(String email) {
        User user = userRepository.findByEmail(email).orElseThrow(() -> new DBException("User not found"));
        OneTimeToken token = oneTimeTokenService.generate(new GenerateOneTimeTokenRequest(user.getId().toString(), EXPIRES_IN));
        String renewalLink = renewalUrl + token.getTokenValue();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy. '@' HH:mm")
                .withZone(ZoneOffset.UTC);

        Map<String, Object> dynamicData = new HashMap<>();
        dynamicData.put("username", user.getUserUsername());
        dynamicData.put("renewLink", renewalLink);
        dynamicData.put("expiresAt", formatter.format(Instant.now().plus(5, ChronoUnit.MINUTES)));
        dynamicData.put("subject", "Your One Time Token Login for username {" + user.getUserUsername() + "}");
        try {
            emailSenderService.sendEmail(
                    user.getEmail(),
                    TEMPLATE_ID,
                    dynamicData
            );
        } catch (IOException e) {
            throw new EmailException("Failed to send OTT login email.", e);
        }
    }

    @Transactional
    public User validateOTTLogin(OneTimeTokenAuthenticationToken token) {
        OneTimeToken tokenValueOpt = oneTimeTokenService.consume(token);
        assert tokenValueOpt != null;
        UUID userId = UUID.fromString(tokenValueOpt.getUsername());
        return userRepository.findById(userId)
                .orElseThrow(() -> new DBException("User not found"));
    }
}
