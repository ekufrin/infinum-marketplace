package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.model.Conversation;
import com.ekufrin.infinum.marketplace.repository.AdRepository;
import com.ekufrin.infinum.marketplace.repository.ConversationRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

@Service
public class ConversationService {

    private final ConversationRepository conversationRepository;
    private final AdRepository adRepository;

    public ConversationService(ConversationRepository conversationRepository, AdRepository adRepository) {
        this.conversationRepository = conversationRepository;
        this.adRepository = adRepository;
    }

    public Conversation startConversation(UUID adId, UserDetails userDetails) {
        UUID authorId = adRepository.getAuthorIdByAdId(adId)
                .orElseThrow(() -> new DBException("Ad author not found"));
        UUID visitorId = UUID.fromString(userDetails.getUsername());

        return conversationRepository.findByAdIdAndVisitorId(adId, visitorId)
                .orElseGet(() -> {
                    Conversation newConversation = new Conversation();
                    newConversation.setAdId(adId);
                    newConversation.setVisitorId(visitorId);
                    newConversation.setAuthorId(authorId);
                    newConversation.setCreatedAt(Instant.now());
                    return conversationRepository.save(newConversation);
                });
    }
}
