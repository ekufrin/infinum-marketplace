package com.ekufrin.infinum.marketplace.repository;

import com.ekufrin.infinum.marketplace.model.Ad;
import com.ekufrin.infinum.marketplace.model.Image;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface ImageRepository extends JpaRepository<Image, UUID> {
    List<Image> findAllByIdInAndAdIsNull(List<UUID> ids);

    @Query("select count(i) from Image i where i.id in :ids and (i.ad is null or i.ad.id = :adId)")
    long countAssignableToAd(@Param("adId") UUID adId, @Param("ids") List<UUID> ids);

    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("update Image i set i.ad = :ad where i.id in :ids and i.ad is null")
    int assignToAdIfUnassigned(@Param("ad") Ad ad, @Param("ids") List<UUID> ids);

    @Query("select i.id from Image i where i.ad.id = :adId and i.id not in :ids")
    List<UUID> findIdsByAdExcept(@Param("adId") UUID adId, @Param("ids") List<UUID> ids);

    @Query("select i.id from Image i where i.ad.id = :adId")
    List<UUID> findIdsByAd(@Param("adId") UUID adId);

    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("delete from Image i where i.ad.id = :adId and i.id not in :ids")
    int deleteAllForAdExcept(@Param("adId") UUID adId, @Param("ids") List<UUID> ids);

    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("delete from Image i where i.ad.id = :adId")
    int deleteAllForAd(@Param("adId") UUID adId);
}
