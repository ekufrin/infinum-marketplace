package com.ekufrin.infinum.marketplace.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public record OTTLoginRequest(
        @NotNull(message = "Email must not be null")
        @Email(message = "Email should be in valid format",
                regexp = "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,63}",
                flags = Pattern.Flag.CASE_INSENSITIVE)
        String email
) {
}
