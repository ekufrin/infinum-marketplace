package com.ekufrin.infinum.marketplace.controller;

import com.ekufrin.infinum.marketplace.dto.JWTResponse;
import com.ekufrin.infinum.marketplace.dto.OTTLoginRequest;
import com.ekufrin.infinum.marketplace.dto.UserLoginRequest;
import com.ekufrin.infinum.marketplace.dto.UserRegisterRequest;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.service.AuthService;
import com.ekufrin.infinum.marketplace.service.JWTService;
import com.ekufrin.infinum.marketplace.service.TokenBlacklistService;
import com.ekufrin.infinum.marketplace.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.Optional;

@RestController
@RequestMapping("/auth")
public class AuthController {
    private final JWTService jwtService;
    private final AuthService authService;
    private final UserService userService;
    private final TokenBlacklistService tokenBlacklistService;

    public AuthController(JWTService jwtService, UserService userService, AuthService authService, TokenBlacklistService tokenBlacklistService) {
        this.tokenBlacklistService = tokenBlacklistService;
        this.jwtService = jwtService;
        this.authService = authService;
        this.userService = userService;
    }

    @PostMapping("/register")
    public ResponseEntity<JWTResponse> registerUser(@RequestBody @Valid UserRegisterRequest userRegisterRequest) {
        User user = userService.addUser(userRegisterRequest, null);
        JWTResponse jwtResponse = generateTokenResponse(user);
        return ResponseEntity.status(HttpStatus.CREATED).header("Authorization", jwtResponse.tokenType() + " " + jwtResponse.token()).body(jwtResponse);
    }

    @PostMapping("/login")
    public ResponseEntity<JWTResponse> loginUser(@RequestBody @Valid UserLoginRequest userLoginRequest) {
        Optional<User> user = authService.authenticate(userLoginRequest);
        if (user.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        JWTResponse jwtResponse = generateTokenResponse(user.get());
        return ResponseEntity.ok().header("Authorization", jwtResponse.tokenType() + " " + jwtResponse.token()).body(jwtResponse);
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logoutUser(@RequestHeader("Authorization") String authorizationHeader) {
        if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
            return ResponseEntity.badRequest().build();
        }
        String token = authorizationHeader.replace("Bearer ", "");
        Instant expiration = jwtService.extractClaim(token, claims -> claims.getExpiration().toInstant());
        tokenBlacklistService.blacklist(token, expiration);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/ott-request")
    public ResponseEntity<Void> requestOneTimeToken(@RequestBody @Valid OTTLoginRequest request) {
        String email = request.email();
        authService.createAndSendOTTokenEmail(email);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/ott-login")
    public ResponseEntity<JWTResponse> loginWithOneTimeToken(@RequestParam("token") String tokenValue) {
        OneTimeTokenAuthenticationToken authenticationToken = new OneTimeTokenAuthenticationToken(tokenValue);
        User user = authService.validateOTTLogin(authenticationToken);
        JWTResponse jwtResponse = generateTokenResponse(user);
        return ResponseEntity.ok().header("Authorization", jwtResponse.tokenType() + " " + jwtResponse.token()).body(jwtResponse);
    }

    private JWTResponse generateTokenResponse(User user) {
        String token = jwtService.generateToken(user);
        String tokenType = "Bearer";
        long expiresIn = jwtService.getExpirationTime();
        return new JWTResponse(token, tokenType, expiresIn);
    }


}
