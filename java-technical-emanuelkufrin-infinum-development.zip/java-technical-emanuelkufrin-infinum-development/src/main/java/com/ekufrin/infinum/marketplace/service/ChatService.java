package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.dto.ChatMessageSendRequest;
import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.model.Conversation;
import com.ekufrin.infinum.marketplace.model.Message;
import com.ekufrin.infinum.marketplace.repository.ConversationRepository;
import com.ekufrin.infinum.marketplace.repository.MessageRepository;
import org.springframework.stereotype.Service;

import java.security.Principal;
import java.time.Instant;
import java.util.UUID;

@Service
public class ChatService {
    private final MessageRepository messageRepository;
    private final ConversationRepository conversationRepository;

    public ChatService(MessageRepository messageRepository, ConversationRepository conversationRepository) {
        this.messageRepository = messageRepository;
        this.conversationRepository = conversationRepository;
    }

    private void verifyConversationAccess(UUID conversationId, UUID userId) {
        boolean hasAccess = conversationRepository.existsByIdAndAuthorIdOrVisitorId(conversationId, userId);
        if (!hasAccess) {
            throw new DBException("You don't have permission to access this conversation");
        }
    }

    public Message save(ChatMessageSendRequest message, Principal principal) {
        UUID senderId = UUID.fromString(principal.getName());
        Conversation conversation = conversationRepository.findById(message.conversationId())
                .orElseThrow(() -> new DBException("Conversation not found"));
        verifyConversationAccess(conversation.getId(), senderId);

        Message newMessage = new Message();
        newMessage.setConversation(conversation);
        newMessage.setSenderId(senderId);
        newMessage.setContent(message.content());
        newMessage.setSentAt(Instant.now());

        return messageRepository.save(newMessage);
    }
}
