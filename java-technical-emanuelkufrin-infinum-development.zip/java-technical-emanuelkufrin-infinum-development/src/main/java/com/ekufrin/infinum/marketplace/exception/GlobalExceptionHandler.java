package com.ekufrin.infinum.marketplace.exception;

import com.ekufrin.infinum.marketplace.dto.ErrorResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(AlreadyExistsInDB.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public ErrorResponse handleAlreadyExists(AlreadyExistsInDB e) {
        return new ErrorResponse(ErrorResponse.CONFLICT_ERROR, e.getMessage(), HttpStatus.CONFLICT.value());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleValidationExceptions(MethodArgumentNotValidException e) {
        String errorMessage = e.getBindingResult().getAllErrors().getFirst().getDefaultMessage();
        return new ErrorResponse(ErrorResponse.BAD_REQUEST_ERROR, errorMessage, HttpStatus.BAD_REQUEST.value());

    }

    @ExceptionHandler(AuthenticationException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ErrorResponse handleAuthenticationException(AuthenticationException ex) {
        LOGGER.error("Authentication error: {}", ex.getMessage());
        return new ErrorResponse(ErrorResponse.UNAUTHORIZED_ERROR, HttpStatus.UNAUTHORIZED.value());
    }

    @ExceptionHandler(BadCredentialsException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ErrorResponse handleBadCredentialsException() {
        return new ErrorResponse(ErrorResponse.UNAUTHORIZED_ERROR, "Invalid credentials", HttpStatus.UNAUTHORIZED.value());
    }

    @ExceptionHandler(PasswordMismatch.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handlePasswordMismatch(PasswordMismatch e) {
        return new ErrorResponse(ErrorResponse.BAD_REQUEST_ERROR, e.getMessage(), HttpStatus.BAD_REQUEST.value());
    }

    @ExceptionHandler(DBException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse handleDBException(DBException e) {
        LOGGER.error("Database error while fetching object. Error: {}", e.getMessage());
        return new ErrorResponse(ErrorResponse.NOT_FOUND_ERROR, e.getMessage(), HttpStatus.NOT_FOUND.value());
    }

    @ExceptionHandler(UploadException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleUploadException(UploadException e) {
        LOGGER.error("Upload exception: {}", e.getMessage());
        return new ErrorResponse(ErrorResponse.BAD_REQUEST_ERROR, e.getMessage(), HttpStatus.BAD_REQUEST.value());
    }

    @ExceptionHandler(AuthenticationServiceException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ErrorResponse handleAuthenticationServiceException(AuthenticationServiceException e) {
        return new ErrorResponse(ErrorResponse.UNAUTHORIZED_ERROR, e.getMessage(), HttpStatus.UNAUTHORIZED.value());
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleHttpMessageNotReadableException(HttpMessageNotReadableException e) {
        LOGGER.error("HTTP Message not readable: {}", e.getMessage());
        return new ErrorResponse(ErrorResponse.BAD_REQUEST_ERROR, "Please check your JSON body input.", HttpStatus.BAD_REQUEST.value());
    }

    @ExceptionHandler(EmailException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse handleEmailException(EmailException e) {
        LOGGER.error("{} : {}", e.getMessage(), e.getCause().getMessage());
        return new ErrorResponse(ErrorResponse.INTERNAL_SERVER_ERROR, "An error occurred while sending email.", HttpStatus.INTERNAL_SERVER_ERROR.value());
    }
}