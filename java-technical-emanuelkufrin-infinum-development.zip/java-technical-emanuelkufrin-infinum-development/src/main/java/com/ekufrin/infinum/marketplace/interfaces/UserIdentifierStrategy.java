package com.ekufrin.infinum.marketplace.interfaces;

import com.ekufrin.infinum.marketplace.model.User;

import java.util.Optional;

public interface UserIdentifierStrategy {
    boolean supports(String identifier);

    Optional<User> findUser(String identifier);
}
