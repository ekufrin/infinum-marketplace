package com.ekufrin.infinum.marketplace.model;

import com.ekufrin.infinum.marketplace.enums.AdReportType;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import org.hibernate.annotations.UuidGenerator;

import java.io.Serializable;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "ad_report")
public class AdReport implements Serializable {
    @Id
    @UuidGenerator
    private UUID id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ad_id")
    @JsonBackReference("ad-reports")
    private Ad ad;
    @Enumerated(EnumType.STRING)
    @Column(name = "report_type")
    private AdReportType type;
    @Column(name = "report_reason")
    private String reason;
    private Instant createdAt;
    private Instant reviewedAt;
    @ManyToOne
    @JoinColumn(name = "reviewed_by")
    @JsonIgnore
    private User reviewedBy;

    public AdReport() {
    }

    public AdReport(UUID id, Ad ad, AdReportType type, String reason, Instant createdAt, Instant reviewedAt) {
        this.id = id;
        this.ad = ad;
        this.type = type;
        this.reason = reason;
        this.createdAt = createdAt;
        this.reviewedAt = reviewedAt;
    }

    public User getReviewedBy() {
        return reviewedBy;
    }

    public void setReviewedBy(User reviewedBy) {
        this.reviewedBy = reviewedBy;
    }

    @JsonProperty("reviewedBy")
    public UUID getReviewedById() {
        return reviewedBy != null ? reviewedBy.getId() : null;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Ad getAd() {
        return ad;
    }

    public void setAd(Ad ad) {
        this.ad = ad;
    }

    public AdReportType getType() {
        return type;
    }

    public void setType(AdReportType type) {
        this.type = type;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getReviewedAt() {
        return reviewedAt;
    }

    public void setReviewedAt(Instant reviewedAt) {
        this.reviewedAt = reviewedAt;
    }
}
