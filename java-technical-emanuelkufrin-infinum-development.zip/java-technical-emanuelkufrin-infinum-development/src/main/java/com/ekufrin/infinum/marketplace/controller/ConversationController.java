package com.ekufrin.infinum.marketplace.controller;

import com.ekufrin.infinum.marketplace.model.Conversation;
import com.ekufrin.infinum.marketplace.service.ConversationService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/conversations")
public class ConversationController {
    private final ConversationService conversationService;

    public ConversationController(ConversationService conversationService) {
        this.conversationService = conversationService;
    }

    @PostMapping("/start/{adId}")
    public Conversation startConversation(@PathVariable UUID adId, @AuthenticationPrincipal UserDetails userDetails) {
        return conversationService.startConversation(adId, userDetails);
    }
}
