package com.ekufrin.infinum.marketplace.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import org.hibernate.annotations.UuidGenerator;

import java.time.Instant;
import java.util.UUID;

@Entity
public class Message {
    @Id
    @UuidGenerator
    private UUID id;
    @ManyToOne
    private Conversation conversation;
    private UUID senderId;
    private String content;
    private Instant sentAt;

    public Message() {
    }

    public Message(UUID id, Conversation conversation, UUID senderId, String content, Instant sentAt) {
        this.id = id;
        this.conversation = conversation;
        this.senderId = senderId;
        this.content = content;
        this.sentAt = sentAt;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Conversation getConversation() {
        return conversation;
    }

    public void setConversation(Conversation conversation) {
        this.conversation = conversation;
    }

    public UUID getSenderId() {
        return senderId;
    }

    public void setSenderId(UUID senderId) {
        this.senderId = senderId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String message) {
        this.content = message;
    }

    public Instant getSentAt() {
        return sentAt;
    }

    public void setSentAt(Instant timestamp) {
        this.sentAt = timestamp;
    }
}
