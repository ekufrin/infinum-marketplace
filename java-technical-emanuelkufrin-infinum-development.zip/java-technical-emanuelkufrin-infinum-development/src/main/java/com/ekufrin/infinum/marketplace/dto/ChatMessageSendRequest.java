package com.ekufrin.infinum.marketplace.dto;

import java.util.UUID;

public record ChatMessageSendRequest(
        UUID conversationId,
        String content
) {
}
