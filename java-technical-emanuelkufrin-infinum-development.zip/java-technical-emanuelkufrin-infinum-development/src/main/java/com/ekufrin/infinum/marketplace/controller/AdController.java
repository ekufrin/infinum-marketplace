package com.ekufrin.infinum.marketplace.controller;

import com.ekufrin.infinum.marketplace.dto.AdCreateRequest;
import com.ekufrin.infinum.marketplace.dto.AdReportCreateRequest;
import com.ekufrin.infinum.marketplace.dto.AdResponse;
import com.ekufrin.infinum.marketplace.dto.PagedResponse;
import com.ekufrin.infinum.marketplace.enums.Condition;
import com.ekufrin.infinum.marketplace.model.AdReport;
import com.ekufrin.infinum.marketplace.service.AdService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.SortDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationToken;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/ads")
public class AdController {
    private final AdService adService;

    public AdController(AdService adService) {
        this.adService = adService;
    }

    @PostMapping
    public ResponseEntity<AdResponse> createAd(@RequestBody @Valid AdCreateRequest request, @AuthenticationPrincipal UserDetails user) {
        AdResponse ad = adService.createAd(request, user);
        return ResponseEntity.status(HttpStatus.CREATED).body(ad);
    }

    @GetMapping
    public ResponseEntity<PagedResponse<AdResponse>> getAllAds(@RequestParam(required = false) String title,
                                                               @RequestParam(required = false) String category,
                                                               @RequestParam(required = false) Condition condition,
                                                               @RequestParam(required = false) Double minPrice,
                                                               @RequestParam(required = false) Double maxPrice,
                                                               @SortDefault(value = "expiresAt", direction = Sort.Direction.DESC) Pageable pageable) {
        return ResponseEntity.ok().body(PagedResponse.from(adService.getAllAdsWithFilterAndSorting(title, category, condition, minPrice, maxPrice, pageable)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<AdResponse> getAdById(@PathVariable UUID id) {
        return ResponseEntity.ok().body(adService.getAdById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<AdResponse> editAd(@PathVariable UUID id,
                                             @RequestBody @Valid AdCreateRequest request,
                                             @AuthenticationPrincipal UserDetails user) {
        AdResponse updatedAd = adService.editAd(id, request, user);
        return ResponseEntity.ok().body(updatedAd);
    }

    @GetMapping("/renew")
    public ResponseEntity<String> renewAd(@RequestParam("token") String tokenValue) {
        OneTimeTokenAuthenticationToken token = new OneTimeTokenAuthenticationToken(tokenValue);
        boolean isRenewed = adService.renewAdByToken(token);
        return isRenewed ? ResponseEntity.ok("Ad renewed sucessfully for next 30 days.") : ResponseEntity.badRequest().body("Invalid or expired token.");
    }

    @PostMapping("/{id}/report")
    public ResponseEntity<AdReport> reportAd(@PathVariable UUID id,
                                             @RequestBody @Valid AdReportCreateRequest request) {
        AdReport createdReport = adService.reportAd(id, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdReport);
    }

    @PutMapping("/{adReportId}/resolve-report")
    public ResponseEntity<AdReport> resolveAdReport(@PathVariable UUID adReportId, @AuthenticationPrincipal UserDetails user) {
        AdReport report = adService.resolveAdReport(adReportId, user);
        return ResponseEntity.ok().body(report);
    }
}
