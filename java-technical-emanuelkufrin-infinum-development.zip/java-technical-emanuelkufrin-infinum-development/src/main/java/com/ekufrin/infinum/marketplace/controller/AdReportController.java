package com.ekufrin.infinum.marketplace.controller;

import com.ekufrin.infinum.marketplace.dto.PagedResponse;
import com.ekufrin.infinum.marketplace.model.AdReport;
import com.ekufrin.infinum.marketplace.service.AdReportService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/ad-reports")
public class AdReportController {
    private final AdReportService adReportService;

    public AdReportController(AdReportService adReportService) {
        this.adReportService = adReportService;
    }

    @GetMapping
    public ResponseEntity<PagedResponse<AdReport>> getAllAdReports(Pageable pageable) {
        Page<AdReport> adReports = adReportService.getAllAdReports(pageable);
        return ResponseEntity.ok(PagedResponse.from(adReports));
    }

    @GetMapping("/{id}")
    public ResponseEntity<AdReport> getAdReportById(@PathVariable UUID id) {
        AdReport adReport = adReportService.getAdReportById(id);
        return ResponseEntity.ok(adReport);
    }
}
