package com.ekufrin.infinum.marketplace.enums;

public enum Role {
    USER,
    ADMIN,
    OWNER
}
