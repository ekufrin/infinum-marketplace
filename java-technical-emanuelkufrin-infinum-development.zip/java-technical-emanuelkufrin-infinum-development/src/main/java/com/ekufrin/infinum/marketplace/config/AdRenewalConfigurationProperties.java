package com.ekufrin.infinum.marketplace.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "ad.renewal")
public class AdRenewalConfigurationProperties extends ThirdPartyAPIConfigurationProperties {
    private String url;

    @Override
    public String getUrl() {
        return url;
    }

    @Override
    public String setUrl(String url) {
        this.url = url;
        return this.url;
    }
}
