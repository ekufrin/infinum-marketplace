package com.ekufrin.infinum.marketplace.repository;

import com.ekufrin.infinum.marketplace.model.Location;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface LocationRepository extends JpaRepository<Location, UUID> {
    Optional<Location> findByAddress(String address);

    Optional<Location> findFirstByAddress(String address);
}
