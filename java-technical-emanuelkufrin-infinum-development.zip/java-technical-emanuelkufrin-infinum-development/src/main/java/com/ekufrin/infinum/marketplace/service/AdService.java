package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.config.AdRenewalConfigurationProperties;
import com.ekufrin.infinum.marketplace.config.AdReportConfigurationProperties;
import com.ekufrin.infinum.marketplace.dto.AdCreateRequest;
import com.ekufrin.infinum.marketplace.dto.AdReportCreateRequest;
import com.ekufrin.infinum.marketplace.dto.AdResponse;
import com.ekufrin.infinum.marketplace.dto.ContactInfoResponse;
import com.ekufrin.infinum.marketplace.enums.Condition;
import com.ekufrin.infinum.marketplace.enums.Role;
import com.ekufrin.infinum.marketplace.enums.Status;
import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.exception.EmailException;
import com.ekufrin.infinum.marketplace.exception.UploadException;
import com.ekufrin.infinum.marketplace.model.Ad;
import com.ekufrin.infinum.marketplace.model.AdReport;
import com.ekufrin.infinum.marketplace.model.Category;
import com.ekufrin.infinum.marketplace.model.ContactInfo;
import com.ekufrin.infinum.marketplace.model.Location;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.repository.AdReportRepository;
import com.ekufrin.infinum.marketplace.repository.AdRepository;
import com.ekufrin.infinum.marketplace.repository.CategoryRepository;
import com.ekufrin.infinum.marketplace.repository.ContactInfoRepository;
import com.ekufrin.infinum.marketplace.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.authentication.ott.GenerateOneTimeTokenRequest;
import org.springframework.security.authentication.ott.OneTimeToken;
import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

@Service
public class AdService {
    public static final Duration EXPIRES_IN = Duration.ofDays(3);
    private static final String AD_RENEWAL_TEMPLATE_ID = "d-948fe5bf407b4869ac1693fe1af7c316";
    private static final String AD_REPORT_TEMPLATE_ID = "d-95b386e96741432eb197945c8ac09e9b";
    private final AdRepository adRepository;
    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;
    private final ContactInfoRepository contactInfoRepository;
    private final AdReportRepository adReportRepository;
    private final ImageService imageService;
    private final LocationService locationService;
    private final OTTService oneTimeTokenService;
    private final EmailSenderService emailSenderService;
    private final AdRenewalConfigurationProperties adRenewalConfigurationProperties;
    private final AdReportConfigurationProperties adReportConfigurationProperties;
    private final Logger LOGGER = Logger.getLogger(AdService.class.getName());

    public AdService(AdRepository adRepository, UserRepository userRepository, CategoryRepository categoryRepository, ContactInfoRepository contactInfoRepository, ImageService imageService, LocationService locationService, OTTService oneTimeTokenService, EmailSenderService emailSenderService, AdRenewalConfigurationProperties adRenewalConfigurationProperties, AdReportRepository adReportRepository, AdReportConfigurationProperties adReportConfigurationProperties) {
        this.adReportConfigurationProperties = adReportConfigurationProperties;
        this.oneTimeTokenService = oneTimeTokenService;
        this.emailSenderService = emailSenderService;
        this.locationService = locationService;
        this.imageService = imageService;
        this.contactInfoRepository = contactInfoRepository;
        this.adRepository = adRepository;
        this.userRepository = userRepository;
        this.categoryRepository = categoryRepository;
        this.adReportRepository = adReportRepository;
        this.adRenewalConfigurationProperties = adRenewalConfigurationProperties;
    }

    private static AdResponse toDTO(Ad ad) {
        return new AdResponse(
                ad.getId(),
                ad.getTitle(),
                ad.getDescription(),
                ad.getPrice(),
                new ContactInfoResponse(
                        ad.getContactInfo().getId(),
                        ad.getContactInfo().getEmail(),
                        ad.getContactInfo().getPhoneNumber()
                ),
                ad.getCategory().getName(),
                ad.getCondition().name(),
                ad.getStatus().name(),
                ad.getExpiresAt(),
                ad.getImages().stream().map(ImageService::toDTO).toList(),
                ad.getLocation() != null ? LocationService.toDTO(ad.getLocation()) : null
        );
    }


    @Transactional
    public AdResponse createAd(AdCreateRequest request, UserDetails userDetails) {
        List<UUID> imageIds = request.getImageIds();
        if (imageIds == null || imageIds.isEmpty()) {
            throw new UploadException("At least one image must be uploaded.");
        }
        if (imageIds.size() > 5) {
            throw new UploadException("Maximum of 5 images allowed.");
        }
        Category category = categoryRepository.findByIdAndActiveIsTrue(request.getCategoryId()).orElseThrow(
                () -> new DBException("Category not found or is deactivated."));
        User author = userRepository.findByIdWithContactInfo(UUID.fromString(userDetails.getUsername())).orElseThrow(
                () -> new DBException("User not found."));
        ContactInfo contactInfo = contactInfoRepository.findById(request.getContactInfoId()).orElseThrow(
                () -> new DBException("Contact info not found."));
        Location location = locationService.findByAddress(request.getLocation().getAddress()).orElse(
                locationService.addLocation(request.getLocation().getAddress())
        );

        if (!contactInfo.getUser().getId().equals(author.getId())) {
            throw new DBException("Contact info does not belong to authenticated user.");
        }

        Ad ad = new Ad();
        ad.setTitle(request.getTitle());
        ad.setDescription(request.getDescription());
        ad.setCategory(category);
        ad.setCondition(request.getCondition());
        ad.setPrice(request.getPrice());
        ad.setExpiresAt(this.expireDateGenerator());
        ad.setContactInfo(contactInfo);
        ad.setStatus(Status.ACTIVE);
        ad.setAuthor(author);
        ad.setLocation(location);

        Ad savedAd = adRepository.saveAndFlush(ad);
        imageService.assignImagesToAd(request.getImageIds(), savedAd);
        savedAd = adRepository.findByIdWithImages(savedAd.getId())
                .orElseThrow(() -> new DBException("Ad not found after save"));

        return toDTO(savedAd);
    }

    private Instant expireDateGenerator() {
        return Instant.now().plus(30, ChronoUnit.DAYS);
    }

    public Page<AdResponse> getAllAdsWithFilterAndSorting(String title, String category, Condition condition, Double minPrice, Double maxPrice, Pageable pageable) {
        return adRepository.findAllFiltered(title, category, condition, minPrice, maxPrice, pageable)
                .map(AdService::toDTO);
    }

    public AdResponse getAdById(UUID id) {
        Ad ad = adRepository.findByIdWithImages(id).orElseThrow(
                () -> new DBException("Ad not found.")
        );
        return toDTO(ad);
    }

    public Page<AdResponse> getAdsByUser(UserDetails user, Pageable pageable) {
        return adRepository.findAllByAuthorId(UUID.fromString(user.getUsername()), pageable)
                .map(AdService::toDTO);
    }

    public AdResponse editAd(UUID id, AdCreateRequest request, UserDetails user) {
        Ad ad = adRepository.findByIdWithImages(id).orElseThrow(
                () -> new DBException("Ad not found.")
        );
        User author = userRepository.findById(UUID.fromString(user.getUsername())).orElseThrow(
                () -> new DBException("User not found.")
        );

        Ad editedAd;

        if (author.getRole() == Role.ADMIN) {
            if (ad.getExpiresAt().isAfter(Instant.now())) {
                editedAd = editAdWithNewData(request, ad);
            } else {
                throw new DBException("Ad has expired");
            }
        } else {
            if (!ad.getAuthor().getId().equals(UUID.fromString(user.getUsername()))) {
                throw new DBException("You can only edit your own ads.");
            }
            editedAd = editAdWithNewData(request, ad);
            if (editedAd.getExpiresAt().isBefore(Instant.now()) || editedAd.getStatus().equals(Status.EXPIRED)) {
                editedAd.setExpiresAt(this.expireDateGenerator());
                editedAd.setStatus(Status.ACTIVE);
            }
        }

        Ad updatedAd = adRepository.saveAndFlush(editedAd);
        imageService.assignImagesToAd(request.getImageIds(), updatedAd);
        updatedAd = adRepository.findByIdWithImages(updatedAd.getId())
                .orElseThrow(() -> new DBException("Ad not found after update"));

        return toDTO(updatedAd);
    }

    public void createAndSendRenewalTokenEmail(UUID adId) {
        Ad ad = adRepository.findByIdWithImages(UUID.fromString(adId.toString())).orElseThrow(
                () -> new DBException("Ad not found.")
        );
        OneTimeToken token = oneTimeTokenService.generate(new GenerateOneTimeTokenRequest(adId.toString(), EXPIRES_IN));
        String renewalLink = adRenewalConfigurationProperties.getUrl() + token.getTokenValue();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy. '@' HH:mm")
                .withZone(ZoneOffset.UTC);

        Map<String, Object> dynamicData = new HashMap<>();
        dynamicData.put("username", ad.getAuthor().getName());
        dynamicData.put("title", ad.getTitle());
        dynamicData.put("expiredAt", formatter.format(ad.getExpiresAt()));
        dynamicData.put("renewLink", renewalLink);
        dynamicData.put("expiresAt", formatter.format(Instant.now().plus(3, ChronoUnit.DAYS)));
        dynamicData.put("subject", "Your ad {" + ad.getTitle() + "} has expired - Renew now!");
        try {
            emailSenderService.sendEmail(
                    ad.getAuthor().getEmail(),
                    AD_RENEWAL_TEMPLATE_ID,
                    dynamicData
            );
        } catch (IOException e) {
            throw new EmailException("Failed to send renewal email.", e);
        }
    }

    @Transactional
    public boolean renewAdByToken(OneTimeTokenAuthenticationToken token) {
        OneTimeToken tokenValueOpt = oneTimeTokenService.consume(token);

        assert tokenValueOpt != null;
        UUID adId = UUID.fromString(tokenValueOpt.getUsername());
        Ad ad = adRepository.findById(adId)
                .orElseThrow(() -> new DBException("Ad not found"));

        ad.setExpiresAt(expireDateGenerator());
        ad.setStatus(Status.ACTIVE);
        ad.setExpirationNotifiedAt(null);
        adRepository.save(ad);
        return true;
    }

    public AdReport reportAd(UUID adId, AdReportCreateRequest request) {
        Ad ad = adRepository.findById(adId).orElseThrow(
                () -> new DBException("Ad not found.")
        );
        List<User> admins = userRepository.findAllByRole(Role.ADMIN);

        AdReport adReport = new AdReport();
        adReport.setAd(ad);
        adReport.setType(request.type());
        adReport.setReason(request.reason());
        adReport.setCreatedAt(Instant.now());

        AdReport generatedReport = adReportRepository.save(adReport);
        String reportURL = adReportConfigurationProperties.getUrl() + generatedReport.getId().toString() + "/report";

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy. '@' HH:mm")
                .withZone(ZoneOffset.UTC);

        Map<String, Object> dynamicData = new HashMap<>();
        dynamicData.put("title", ad.getTitle());
        dynamicData.put("createdAt", formatter.format(adReport.getCreatedAt()));
        dynamicData.put("reason", request.reason());
        dynamicData.put("reportURL", reportURL);
        dynamicData.put("subject", "New Ad Report Submitted for {" + ad.getTitle() + "}");

        for (User admin : admins) {
            try {
                emailSenderService.sendEmail(
                        admin.getEmail(),
                        AD_REPORT_TEMPLATE_ID,
                        dynamicData
                );
            } catch (IOException e) {
                LOGGER.log(Level.SEVERE, "Failed to send ad report notification email to admin.", e);
            }
        }
        return adReport;
    }

    public AdReport resolveAdReport(UUID id, UserDetails user) {
        User admin = userRepository.findById(UUID.fromString(user.getUsername())).orElseThrow(
                () -> new DBException("User not found.")
        );
        AdReport report = adReportRepository.findById(id).orElseThrow(
                () -> new DBException("Ad report not found.")
        );

        report.setReviewedBy(admin);
        report.setReviewedAt(Instant.now());
        return adReportRepository.save(report);
    }

    private Ad editAdWithNewData(AdCreateRequest request, Ad ad) {
        ad.setTitle(request.getTitle());
        ad.setDescription(request.getDescription());
        Category category = categoryRepository.findByIdAndActiveIsTrue(request.getCategoryId()).orElseThrow(
                () -> new DBException("Category not found or is deactivated."));
        ad.setCategory(category);
        ad.setCondition(request.getCondition());
        ad.setPrice(request.getPrice());
        ContactInfo contactInfo = contactInfoRepository.findById(request.getContactInfoId()).orElseThrow(
                () -> new DBException("Contact info not found."));
        ad.setContactInfo(contactInfo);
        ad.setLocation(locationService.findByAddress(request.getLocation().getAddress()).orElse(
                locationService.addLocation(request.getLocation().getAddress())
        ));
        return ad;
    }
}
