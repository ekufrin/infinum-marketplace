package com.ekufrin.infinum.marketplace.controller;

import com.ekufrin.infinum.marketplace.dto.ChatMessageSendRequest;
import com.ekufrin.infinum.marketplace.model.Message;
import com.ekufrin.infinum.marketplace.service.ChatService;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import java.security.Principal;

@Controller
public class ChatController {
    private final SimpMessagingTemplate simpMessagingTemplate;
    private final ChatService chatService;

    public ChatController(SimpMessagingTemplate simpMessagingTemplate, ChatService chatService) {
        this.simpMessagingTemplate = simpMessagingTemplate;
        this.chatService = chatService;
    }

    @MessageMapping("/chat.send")
    public void sendMessage(ChatMessageSendRequest message, Principal principal) {
        Message saved = chatService.save(message, principal);
        String destination = "/topic/conversation." + saved.getConversation().getId();
        simpMessagingTemplate.convertAndSend(destination, saved);
    }
}
