package com.ekufrin.infinum.marketplace.dto;

import java.util.UUID;

public record ImageResponse(
        UUID id
) {
}
