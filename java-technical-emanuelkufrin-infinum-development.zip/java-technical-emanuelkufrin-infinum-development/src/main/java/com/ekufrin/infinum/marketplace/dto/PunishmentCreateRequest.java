package com.ekufrin.infinum.marketplace.dto;

import com.ekufrin.infinum.marketplace.enums.AdReportType;
import jakarta.validation.constraints.NotNull;
import org.springframework.boot.context.properties.bind.DefaultValue;

public record PunishmentCreateRequest(
        @NotNull(message = "Ad report type must not be null")
        AdReportType type,
        String message,
        @DefaultValue("false")
        boolean banUser
) {
}
