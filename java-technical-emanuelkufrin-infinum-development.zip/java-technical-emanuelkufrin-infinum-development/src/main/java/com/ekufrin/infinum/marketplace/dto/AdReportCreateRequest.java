package com.ekufrin.infinum.marketplace.dto;

import com.ekufrin.infinum.marketplace.enums.AdReportType;
import jakarta.validation.constraints.NotNull;

public record AdReportCreateRequest(
        @NotNull(message = "Report type must not be null")
        AdReportType type,
        @NotNull(message = "Report reason must not be null")
        String reason
) {
}
