package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.model.TokenBlacklist;
import com.ekufrin.infinum.marketplace.repository.TokenBlacklistRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
public class TokenBlacklistService {
    private final TokenBlacklistRepository tokenBlacklistRepository;

    public TokenBlacklistService(TokenBlacklistRepository tokenBlacklistRepository) {
        this.tokenBlacklistRepository = tokenBlacklistRepository;
    }

    public void blacklist(String token, Instant expiresAt) {
        TokenBlacklist tokenBlacklist = new TokenBlacklist();
        tokenBlacklist.setToken(token);
        tokenBlacklist.setExpiresAt(expiresAt);
        tokenBlacklistRepository.save(tokenBlacklist);
    }

    public boolean isBlacklisted(String token) {
        return tokenBlacklistRepository.existsByToken(token);
    }

    @Scheduled(cron = "0 0 * * * *")
    public void cleanupExpired() {
        tokenBlacklistRepository.deleteAll(tokenBlacklistRepository.findAll().stream()
                .filter(t -> t.getExpiresAt().isBefore(Instant.now()))
                .toList());
    }
}
