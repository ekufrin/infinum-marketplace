package com.ekufrin.infinum.marketplace.controller;

import com.ekufrin.infinum.marketplace.dto.ImageResponse;
import com.ekufrin.infinum.marketplace.service.ImageService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/images")
public class ImageController {
    private final ImageService imageService;

    public ImageController(ImageService imageService) {
        this.imageService = imageService;
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<List<ImageResponse>> uploadImages(@RequestParam("files") List<MultipartFile> files) {
        List<ImageResponse> imageUrls = imageService.uploadImages(files);
        return ResponseEntity.status(HttpStatus.CREATED).body(imageUrls);
    }

}
