package com.ekufrin.infinum.marketplace.exception;

public class UploadException extends RuntimeException {
    public UploadException(String message) {
        super(message);
    }
}
