package com.ekufrin.infinum.marketplace.config;

import com.ekufrin.infinum.marketplace.service.JWTService;
import com.ekufrin.infinum.marketplace.service.TokenBlacklistService;
import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

public class JWTAuthenticationFilter extends OncePerRequestFilter {
    private static final Logger LOGGER = LoggerFactory.getLogger(JWTAuthenticationFilter.class);
    private final JWTService jwtService;
    private final UserDetailsService userDetailsService;
    private final AuthenticationEntryPoint authenticationEntryPoint;
    private final TokenBlacklistService tokenBlacklistService;

    public JWTAuthenticationFilter(JWTService jwtService, UserDetailsService userDetailsService, AuthenticationEntryPoint authenticationEntryPoint, TokenBlacklistService tokenBlacklistService) {
        this.tokenBlacklistService = tokenBlacklistService;
        this.jwtService = jwtService;
        this.userDetailsService = userDetailsService;
        this.authenticationEntryPoint = authenticationEntryPoint;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        final String authHeader = request.getHeader("Authorization");

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }
        try {
            final String jwt = authHeader.substring(7);
            final String userId = jwtService.extractUserId(jwt);

            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

            if (userId != null && authentication == null) {
                UserDetails userDetails = this.userDetailsService.loadUserByUsername(userId);

                if (tokenBlacklistService.isBlacklisted(jwt)) {
                    throw new JwtException("Token " + jwt + " is blacklisted");
                }

                if (jwtService.isTokenValid(jwt, userDetails)) {
                    UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());

                    authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(authToken);
                }
            }
            filterChain.doFilter(request, response);
        } catch (UsernameNotFoundException ex) {
            LOGGER.error("User not found error: {}", ex.getMessage());
            authenticationEntryPoint.commence(request, response,
                    new AuthenticationServiceException("User not found", ex));
        } catch (JwtException ex) {
            LOGGER.error("JWT error: {}", ex.getMessage());
            authenticationEntryPoint.commence(request, response,
                    new AuthenticationServiceException("Invalid or expired JWT token", ex));
        } catch (IllegalArgumentException ex) {
            LOGGER.error("Illegal Argument error: {}", ex.getMessage());
            authenticationEntryPoint.commence(request, response,
                    new AuthenticationServiceException("Invalid token format", ex));
        } catch (NullPointerException ex) {
            LOGGER.error("Null pointer error: {}", ex.getMessage());
            authenticationEntryPoint.commence(request, response,
                    new AuthenticationServiceException("Unexpected error during authentication", ex));
        } catch (Exception ex) {
            LOGGER.error("Error: {}", ex.getMessage());
            authenticationEntryPoint.commence(request, response,
                    new AuthenticationServiceException(ex.getCause().getMessage(), ex));
        }
    }
}
