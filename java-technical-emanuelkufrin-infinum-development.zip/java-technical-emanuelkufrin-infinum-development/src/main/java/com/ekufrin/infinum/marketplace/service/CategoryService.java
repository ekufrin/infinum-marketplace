package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.dto.CategoryChangeRequest;
import com.ekufrin.infinum.marketplace.dto.CategoryCreateRequest;
import com.ekufrin.infinum.marketplace.exception.AlreadyExistsInDB;
import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.model.Category;
import com.ekufrin.infinum.marketplace.repository.CategoryRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

@Service
public class CategoryService {
    private final CategoryRepository categoryRepository;
    @PersistenceContext
    private EntityManager entityManager;

    CategoryService(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    public Category addCategory(CategoryCreateRequest request) {
        if (categoryRepository.existsByNameIgnoreCase(request.name())) {
            throw new AlreadyExistsInDB(request.name());
        }

        Instant createdAt = Instant.now();

        Boolean status = request.active() != null ? request.active() : Boolean.TRUE;
        Category category = new Category();
        category.setName(request.name());
        category.setActive(status);
        category.setCreatedAt(createdAt);

        return categoryRepository.save(category);
    }

    public Page<Category> getAllCategoriesAsPageWithFilterAndSorting(String search, Boolean active, Pageable pageable) {
        return categoryRepository.findAllFiltered(search, active, pageable);
    }

    public Category updateCategory(String identifier, CategoryChangeRequest request) {
        if (categoryRepository.existsByNameIgnoreCase(request.name())) {
            throw new AlreadyExistsInDB(request.name());
        }
        Optional<Category> category = identifier.matches("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
                ? categoryRepository.findById(UUID.fromString(identifier))
                : Optional.ofNullable(categoryRepository.findByNameIgnoreCase(identifier));
        if (category.isEmpty()) {
            throw new DBException("Category not found");
        }
        category.get().setActive(request.active() != null ? request.active() : category.get().getActive());
        category.get().setName(request.name() != null ? request.name() : category.get().getName());
        return categoryRepository.save(category.get());
    }

    public Optional<Category> findById(UUID id) {
        return categoryRepository.findById(id);
    }

    public void detach(Category category) {
        entityManager.detach(category);
    }
}
