package com.ekufrin.infinum.marketplace.dto;

import com.ekufrin.infinum.marketplace.enums.Condition;
import com.ekufrin.infinum.marketplace.model.Location;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import java.util.List;
import java.util.UUID;

public class AdCreateRequest {
    @NotBlank(message = "Title is required")
    @Size(min = 5, max = 120, message = "Title must be between 5 and 120 characters long")
    private String title;
    @NotBlank(message = "Description is required")
    @Size(max = 2000, message = "Description cannot exceed 2000 characters")
    private String description;
    @NotNull(message = "Category is required")
    private UUID categoryId;
    @NotNull(message = "Condition is required")
    private Condition condition;
    @NotNull(message = "Price is required")
    @Positive(message = "Price must be a positive value")
    private Double price;
    @NotNull(message = "Contact info is required")
    private UUID contactInfoId;
    @NotNull(message = "At least one image is required")
    @Size(max = 5, message = "A maximum of 5 images are allowed")
    private List<UUID> imageIds;
    @NotNull(message = "Location is required")
    private Location location;

    public AdCreateRequest() {
    }

    public AdCreateRequest(String title, String description, UUID categoryId, Condition condition, Double price, UUID contactInfoId, List<UUID> imageIds, Location location) {
        this.title = title;
        this.description = description;
        this.categoryId = categoryId;
        this.condition = condition;
        this.price = price;
        this.contactInfoId = contactInfoId;
        this.imageIds = imageIds;
        this.location = location;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Condition getCondition() {
        return condition;
    }

    public void setCondition(Condition condition) {
        this.condition = condition;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public List<UUID> getImageIds() {
        return imageIds;
    }

    public void setImageIds(List<UUID> imageIds) {
        this.imageIds = imageIds;
    }

    public UUID getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(UUID categoryId) {
        this.categoryId = categoryId;
    }

    public UUID getContactInfoId() {
        return contactInfoId;
    }

    public void setContactInfoId(UUID contactInfoId) {
        this.contactInfoId = contactInfoId;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }


}