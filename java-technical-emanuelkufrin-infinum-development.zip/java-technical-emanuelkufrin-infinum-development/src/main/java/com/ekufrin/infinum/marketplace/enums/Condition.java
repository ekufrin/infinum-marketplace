package com.ekufrin.infinum.marketplace.enums;

public enum Condition {
    NEW,
    USED,
    REFURBISHED
}
