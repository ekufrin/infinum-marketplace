package com.ekufrin.infinum.marketplace.config;

import com.ekufrin.infinum.marketplace.repository.OTTRepository;
import com.ekufrin.infinum.marketplace.service.OTTService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.ott.OneTimeTokenService;

@Configuration
public class OTTConfiguration {
    @Bean
    public OneTimeTokenService oneTimeTokenService(OTTRepository oneTimeTokenRepository) {
        return new OTTService(oneTimeTokenRepository);
    }

}
