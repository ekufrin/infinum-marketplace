package com.ekufrin.infinum.marketplace.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.Size;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record CategoryChangeRequest(
        @Size(min = 1, message = "Name is required")
        String name,
        Boolean active
) {
}
