package com.ekufrin.infinum.marketplace.dto;

import java.util.UUID;

public record ContactInfoResponse(
        UUID id,
        String email,
        String phoneNumber
) {
}
