package com.ekufrin.infinum.marketplace.enums;

public enum AdReportType {
    SPAM,
    INAPPROPRIATE_CONTENT,
    FRAUD,
    OTHER
}
