package com.ekufrin.infinum.marketplace.dto;

import jakarta.validation.constraints.NotNull;

public record ResetPasswordChange(
        @NotNull(message = "Password must not be null")
        String password
) {
}
