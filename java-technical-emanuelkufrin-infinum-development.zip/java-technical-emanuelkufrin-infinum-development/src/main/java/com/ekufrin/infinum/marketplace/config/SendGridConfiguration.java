package com.ekufrin.infinum.marketplace.config;

import com.sendgrid.SendGrid;
import com.sendgrid.helpers.mail.objects.Email;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties(SendGridConfigurationProperties.class)
public class SendGridConfiguration {
    private final SendGridConfigurationProperties sendGridConfigurationProperties;


    public SendGridConfiguration(SendGridConfigurationProperties sendGridConfigurationProperties) {
        this.sendGridConfigurationProperties = sendGridConfigurationProperties;
    }

    @Bean
    public SendGrid sendGrid() {
        return new SendGrid(sendGridConfigurationProperties.getApiKey());
    }

    @Bean
    public Email fromEmail() {
        return new Email(sendGridConfigurationProperties.getFromEmail(), sendGridConfigurationProperties.getFromName());
    }
}
