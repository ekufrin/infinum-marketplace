package com.ekufrin.infinum.marketplace.repository;

import com.ekufrin.infinum.marketplace.model.OTT;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface OTTRepository extends JpaRepository<OTT, UUID> {
    Optional<OTT> findById(UUID id);
}
