package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.dto.ContactInfoRequest;
import com.ekufrin.infinum.marketplace.dto.ContactInfoResponse;
import com.ekufrin.infinum.marketplace.dto.PunishmentCreateRequest;
import com.ekufrin.infinum.marketplace.dto.ResetPasswordChange;
import com.ekufrin.infinum.marketplace.dto.UserDTO;
import com.ekufrin.infinum.marketplace.dto.UserPasswordChange;
import com.ekufrin.infinum.marketplace.dto.UserRegisterRequest;
import com.ekufrin.infinum.marketplace.enums.Role;
import com.ekufrin.infinum.marketplace.exception.AlreadyExistsInDB;
import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.exception.EmailException;
import com.ekufrin.infinum.marketplace.exception.PasswordMismatch;
import com.ekufrin.infinum.marketplace.model.AdReport;
import com.ekufrin.infinum.marketplace.model.ContactInfo;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.repository.AdReportRepository;
import com.ekufrin.infinum.marketplace.repository.ContactInfoRepository;
import com.ekufrin.infinum.marketplace.repository.OTTRepository;
import com.ekufrin.infinum.marketplace.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.authentication.ott.GenerateOneTimeTokenRequest;
import org.springframework.security.authentication.ott.OneTimeToken;
import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationToken;
import org.springframework.security.authentication.ott.OneTimeTokenService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class UserService {

    public static final Duration EXPIRES_IN = Duration.ofMinutes(5);
    public static final String PASSWORD_RESET_OTT_TEMPLATE_ID = "d-04ff3227634a4f0ea0b122d70504605b";
    public static final String PUNISHMENT_TEMPLATE_ID = "d-f200903696eb4dc1af229a4cc091671a";
    private final UserRepository userRepository;
    private final ContactInfoRepository contactInfoRepository;
    private final OTTRepository ottRepository;
    private final AdReportRepository adReportRepository;
    private final OneTimeTokenService oneTimeTokenService;
    private final EmailSenderService emailSenderService;
    private final BCryptPasswordEncoder passwordEncoder;
    @Value("${password.reset.url}")
    private String renewalUrl;

    public UserService(UserRepository userRepository, ContactInfoRepository contactInfoRepository, BCryptPasswordEncoder passwordEncoder, OneTimeTokenService oneTimeTokenService, EmailSenderService emailSenderService, OTTRepository ottRepository, AdReportRepository adReportRepository) {
        this.adReportRepository = adReportRepository;
        this.ottRepository = ottRepository;
        this.oneTimeTokenService = oneTimeTokenService;
        this.emailSenderService = emailSenderService;
        this.userRepository = userRepository;
        this.contactInfoRepository = contactInfoRepository;
        this.passwordEncoder = passwordEncoder;
    }

    private static UserDTO toDTO(User user) {
        return new UserDTO(
                user.getId(),
                user.getName(),
                user.getUserUsername(),
                user.getEmail(),
                user.getRole(),
                user.isActive(),
                user.getCreatedAt()
        );
    }

    static ContactInfoResponse toDTO(ContactInfo contactInfo) {
        return new ContactInfoResponse(
                contactInfo.getId(),
                contactInfo.getEmail(),
                contactInfo.getPhoneNumber()
        );
    }

    public User addUser(UserRegisterRequest userRegisterRequest, UserDetails userDetails) {
        Role defaultRole = Role.USER;

        if (userDetails != null) {
            if (!getUserById(userDetails.getUsername()).role().equals(Role.OWNER)) {
                throw new DBException("Only owners can create users with custom roles.");
            }
            if (userRegisterRequest.role() != null && userRegisterRequest.role().equals(Role.OWNER)) {
                throw new DBException("Cannot create owner user.");
            }
            defaultRole = userRegisterRequest.role() == null ? Role.USER : userRegisterRequest.role();
        }

        if (emailExists(userRegisterRequest.email())) {
            throw new AlreadyExistsInDB(userRegisterRequest.email());
        }

        String encodedPassword = passwordEncoder.encode(userRegisterRequest.password());
        Instant createdAt = Instant.now();
        String username = generateUsername(userRegisterRequest.email());

        User user = new User.Builder()
                .name(userRegisterRequest.name())
                .email(userRegisterRequest.email())
                .username(username)
                .password(encodedPassword)
                .isActive(true)
                .role(defaultRole)
                .createdAt(createdAt)
                .build();

        return userRepository.save(user);
    }

    public User changeUserPassword(String id, UserPasswordChange userPasswordChange) {
        Optional<User> user = userRepository.findById(UUID.fromString(id));
        if (user.isEmpty()) {
            throw new DBException("User not found.");
        }
        String currentPassword = user.get().getPassword();
        if (!passwordEncoder.matches(userPasswordChange.oldPassword(), currentPassword)) {
            throw new PasswordMismatch("Old password does not match the current password.");
        }
        if (passwordEncoder.matches(userPasswordChange.newPassword(), currentPassword)) {
            throw new PasswordMismatch("New password must be different from the old password.");
        }
        String encodedPassword = passwordEncoder.encode(userPasswordChange.newPassword());
        user.get().setPassword(encodedPassword);
        return userRepository.save(user.get());
    }

    public Page<UserDTO> getAllUsersAsPageWithFilterAndSorting(String search, Boolean active, Pageable pageable) {
        return userRepository.findAllFiltered(search, active, pageable);
    }

    public UserDTO getUserByEmail(String email) {
        User user = userRepository.findByEmail(email).orElseThrow(() -> new DBException("User with email " + email + " not found."));
        return toDTO(user);
    }

    public UserDTO getUserById(String id) {
        User user = userRepository.findById(UUID.fromString(id)).orElseThrow(() -> new DBException("User with id " + id + " not found."));
        return toDTO(user);
    }

    public ContactInfoResponse createContactInfo(ContactInfoRequest request, UserDetails userDetails) {
        User user = userRepository.findById(UUID.fromString(userDetails.getUsername())).orElseThrow(
                () -> new DBException("User not found")
        );
        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setEmail(request.email());
        contactInfo.setPhoneNumber(request.phoneNumber());
        contactInfo.setUser(user);
        return toDTO(contactInfoRepository.save(contactInfo));
    }

    public Page<ContactInfoResponse> getAllContactInfoForUser(UUID id, Pageable pageable) {
        return contactInfoRepository.findAllByUser_Id(id, pageable).map(UserService::toDTO);
    }

    public void createAndSendOTTokenEmail(String email) {
        User user = userRepository.findByEmail(email).orElseThrow(() -> new DBException("User not found"));
        OneTimeToken token = oneTimeTokenService.generate(new GenerateOneTimeTokenRequest(user.getId().toString(), EXPIRES_IN));
        String renewalLink = renewalUrl + token.getTokenValue();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy. '@' HH:mm")
                .withZone(ZoneOffset.UTC);

        Map<String, Object> dynamicData = new HashMap<>();
        dynamicData.put("username", user.getUserUsername());
        dynamicData.put("renewLink", renewalLink);
        dynamicData.put("expiresAt", formatter.format(Instant.now().plus(5, ChronoUnit.MINUTES)));
        dynamicData.put("subject", "Your password reset OTT for username {" + user.getUserUsername() + "}");
        try {
            emailSenderService.sendEmail(
                    user.getEmail(),
                    PASSWORD_RESET_OTT_TEMPLATE_ID,
                    dynamicData
            );
        } catch (IOException e) {
            throw new EmailException("Failed to send OTT login email.", e);
        }
    }

    @Transactional
    public boolean validateOTTPasswordResetToken(OneTimeTokenAuthenticationToken token) {
        return ottRepository.findById(UUID.fromString(token.getTokenValue()))
                .filter(t -> t.getExpiresAt().isAfter(Instant.now()))
                .isPresent();
    }

    @Transactional
    public User validateOTTPasswordChange(OneTimeTokenAuthenticationToken token, ResetPasswordChange resetPasswordChange) {
        OneTimeToken tokenValueOpt = oneTimeTokenService.consume(token);
        assert tokenValueOpt != null;
        UUID userId = UUID.fromString(tokenValueOpt.getUsername());
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new DBException("User not found"));
        String encodedPassword = passwordEncoder.encode(resetPasswordChange.password());
        user.setPassword(encodedPassword);
        return userRepository.save(user);
    }

    public Page<AdReport> getAllAdReportsForUser(UUID userId, Pageable pageable) {
        return adReportRepository.findAllByAd_Author_Id(userId, pageable);
    }

    public void punishUser(UUID userId, PunishmentCreateRequest request) {
        User user = userRepository.findUserByIdAndRoleEquals(userId, Role.USER)
                .orElseThrow(() -> new DBException("User not found"));
        String message = null;
        if (request.banUser()) {
            user.setActive(false);
            userRepository.save(user);
            message = "Your account have been banned due to multiple violations of our terms of service.";
        }
        Map<String, Object> dynamicData = new HashMap<>();
        dynamicData.put("username", user.getUserUsername());
        dynamicData.put("reason", request.type().toString());
        dynamicData.put("message", request.message() != null ? request.message() : message);
        dynamicData.put("subject", "Violation notice for username {" + user.getUserUsername() + "}");
        try {
            emailSenderService.sendEmail(
                    user.getEmail(),
                    PUNISHMENT_TEMPLATE_ID,
                    dynamicData
            );
        } catch (IOException e) {
            throw new EmailException("Failed to send punishment email.", e);
        }
    }

    private boolean emailExists(String email) {
        return userRepository.existsByEmailIgnoreCase(email);
    }

    private String generateUsername(String email) {
        Pattern pattern = Pattern.compile("^([A-Za-z0-9._%+-]+)@([A-Za-z0-9.-]+)\\.[A-Za-z]{2,}$");
        Matcher matcher = pattern.matcher(email);

        if (!matcher.matches()) {
            throw new IllegalArgumentException("Wrong email format: " + email);
        }

        String baseUsername = matcher.group(1);
        String newUsername = baseUsername;
        int suffix = 1;

        while (userRepository.existsByUsernameIgnoreCase(newUsername)) {
            newUsername = baseUsername + suffix;
            suffix++;
        }
        return newUsername;
    }
}
