package com.ekufrin.infinum.marketplace.dto;

import com.ekufrin.infinum.marketplace.enums.Role;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record UserRegisterRequest(
        @NotBlank(message = "Name is required")
        @Size(max = 100, message = "Name must be at most 100 characters long")
        String name,
        @NotBlank(message = "Email is required")
        @Email(message = "Email should be in valid format",
                regexp = "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,63}",
                flags = Pattern.Flag.CASE_INSENSITIVE)
        @Size(max = 100, message = "Email must be at most 100 characters long")
        String email,
        @NotBlank(message = "Password is required")
        @Size(min = 10, max = 255, message = "Password must be between 10 and 255 characters long")
        String password,
        Role role) {
}