package com.ekufrin.infinum.marketplace.dto;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public record AdResponse(
        UUID id,
        String title,
        String description,
        Double price,
        ContactInfoResponse contactInfo,
        String category,
        String condition,
        String status,
        Instant expiresAt,
        List<ImageResponse> images,
        LocationResponse location
) {
}
