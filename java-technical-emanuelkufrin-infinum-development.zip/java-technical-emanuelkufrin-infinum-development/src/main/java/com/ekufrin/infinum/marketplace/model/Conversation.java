package com.ekufrin.infinum.marketplace.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import org.hibernate.annotations.UuidGenerator;

import java.time.Instant;
import java.util.UUID;

@Entity
public class Conversation {
    @Id
    @UuidGenerator
    private UUID id;
    private UUID adId;
    private UUID authorId;
    private UUID visitorId;
    private Instant createdAt;

    public Conversation() {
    }

    public Conversation(UUID id, UUID adId, UUID authorId, UUID visitorId, Instant createdAt) {
        this.id = id;
        this.adId = adId;
        this.authorId = authorId;
        this.visitorId = visitorId;
        this.createdAt = createdAt;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getAdId() {
        return adId;
    }

    public void setAdId(UUID adId) {
        this.adId = adId;
    }

    public UUID getAuthorId() {
        return authorId;
    }

    public void setAuthorId(UUID authorId) {
        this.authorId = authorId;
    }

    public UUID getVisitorId() {
        return visitorId;
    }

    public void setVisitorId(UUID visitorId) {
        this.visitorId = visitorId;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}
