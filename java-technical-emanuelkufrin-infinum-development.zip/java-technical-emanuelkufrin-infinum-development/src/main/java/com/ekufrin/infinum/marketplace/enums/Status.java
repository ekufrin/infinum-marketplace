package com.ekufrin.infinum.marketplace.enums;

public enum Status {
    ACTIVE,
    EXPIRED,
    DELETED
}
