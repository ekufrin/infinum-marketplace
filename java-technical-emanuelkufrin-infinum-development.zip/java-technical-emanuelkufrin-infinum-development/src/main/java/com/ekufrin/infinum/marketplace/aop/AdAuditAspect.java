package com.ekufrin.infinum.marketplace.aop;

import com.ekufrin.infinum.marketplace.dto.AdResponse;
import com.ekufrin.infinum.marketplace.service.AdService;
import com.ekufrin.infinum.marketplace.service.AuditService;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;
import java.util.UUID;

@Aspect
@Component
public class AdAuditAspect {

    private final AuditService auditService;
    private final AdService adService;
    private final ThreadLocal<AdResponse> previousAd = new ThreadLocal<>();

    public AdAuditAspect(AuditService auditService, AdService adService) {
        this.auditService = auditService;
        this.adService = adService;
    }

    @AfterReturning(pointcut = "execution(* com.ekufrin.infinum.marketplace.controller.AdController.createAd(..))", returning = "result")
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void logAdCreation(JoinPoint joinPoint, Object result) {
        if (!(result instanceof ResponseEntity<?> response)) return;
        Object body = response.getBody();
        if (!(body instanceof AdResponse ad)) return;
        auditService.log("CREATE_AD", "Ad", ad.id(), null, ad.title(), currentUser());
    }

    @Before("execution(* com.ekufrin.infinum.marketplace.controller.AdController.editAd(..))")
    public void snapshotCurrentAd(JoinPoint joinPoint) {
        previousAd.remove();
        UUID id = extractUuid(joinPoint.getArgs(), 0);
        if (id == null) return;
        try {
            AdResponse current = adService.getAdById(id);
            if (current == null) return;
            AdResponse snapshot = new AdResponse(
                    current.id(),
                    current.title(),
                    current.description(),
                    current.price(),
                    current.contactInfo(),
                    current.category(),
                    current.condition(),
                    current.status(),
                    current.expiresAt(),
                    current.images(),
                    current.location()
            );
            previousAd.set(snapshot);
        } catch (Exception _) {
            previousAd.remove();
        }
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @AfterReturning(pointcut = "execution(* com.ekufrin.infinum.marketplace.controller.AdController.editAd(..))", returning = "result")
    public void logAdUpdate(JoinPoint joinPoint, Object result) {
        AdResponse oldAd = previousAd.get();
        try {
            if (!(result instanceof ResponseEntity<?> response)) return;
            Object body = response.getBody();
            if (!(body instanceof AdResponse updated)) return;
            if (oldAd != null) {
                if (!Objects.equals(oldAd.title(), updated.title())) {
                    logAdChange("UPDATE_AD_TITLE", updated.id(), oldAd.title(), updated.title());
                }
                if (!Objects.equals(oldAd.description(), updated.description())) {
                    logAdChange("UPDATE_AD_DESCRIPTION", updated.id(), oldAd.description(), updated.description());
                }
                if (!Objects.equals(oldAd.price(), updated.price())) {
                    logAdChange("UPDATE_AD_PRICE", updated.id(), oldAd.price(), updated.price());
                }
                if (!Objects.equals(oldAd.category(), updated.category())) {
                    logAdChange("UPDATE_AD_CATEGORY", updated.id(), oldAd.category(), updated.category());
                }
                if (!Objects.equals(oldAd.condition(), updated.condition())) {
                    logAdChange("UPDATE_AD_CONDITION", updated.id(), oldAd.condition(), updated.condition());
                }
                if (!Objects.equals(oldAd.status(), updated.status())) {
                    logAdChange("UPDATE_AD_STATUS", updated.id(), oldAd.status(), updated.status());
                }
                if (!Objects.equals(oldAd.contactInfo(), updated.contactInfo())) {
                    logAdChange(
                            "UPDATE_AD_CONTACT_INFO",
                            updated.id(),
                            oldAd.contactInfo().email() + ", " + oldAd.contactInfo().phoneNumber(),
                            updated.contactInfo().email() + ", " + updated.contactInfo().phoneNumber()
                    );
                }
                if (!Objects.equals(oldAd.location(), updated.location())) {
                    logAdChange(
                            "UPDATE_AD_LOCATION",
                            updated.id(),
                            oldAd.location().geoLocation() + ", " + oldAd.location().address(),
                            updated.location().geoLocation() + ", " + updated.location().address()
                    );
                }
                if (!Objects.equals(oldAd.images(), updated.images())) {
                    logAdChange("UPDATE_AD_IMAGES", updated.id(), oldAd.images().size(), updated.images().size());
                }
            }
        } finally {
            previousAd.remove();
        }
    }

    @AfterReturning(pointcut = "execution(* com.ekufrin.infinum.marketplace.controller.AdController.renewAd(..))", returning = "result")
    public void logAdRenew(JoinPoint joinPoint, Object result) {
        if (!(result instanceof ResponseEntity<?>)) return;
        String token = extractString(joinPoint.getArgs(), 0);
        String masked = maskToken(token);
        auditService.log(
                "RENEW_AD",
                "Ad",
                null,
                masked,
                "RENEWED_WITH_TOKEN",
                currentUser()
        );
    }

    private void logAdChange(String action, UUID adId, Object oldValue, Object newValue) {
        auditService.log(action, "Ad", adId, oldValue, newValue, currentUser());
    }

    private UUID extractUuid(Object[] args, int index) {
        if (args == null || args.length <= index) return null;
        Object idObj = args[index];
        if (idObj instanceof UUID uuid) return uuid;
        if (idObj instanceof String s) {
            try {
                return UUID.fromString(s);
            } catch (IllegalArgumentException _) {
                return null;
            }
        }
        return null;
    }

    private String extractString(Object[] args, int index) {
        if (args == null || args.length <= index) return null;
        Object v = args[index];
        return v instanceof String s ? s : null;
    }

    private String maskToken(String token) {
        if (token == null || token.isBlank()) return null;
        int len = token.length();
        if (len <= 6) return "***";
        return token.substring(0, 3) + "****" + token.substring(len - 3);
    }

    private String currentUser() {
        try {
            return SecurityContextHolder.getContext().getAuthentication().getName();
        } catch (Exception _) {
            return "system";
        }
    }
}