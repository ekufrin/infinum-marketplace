package com.ekufrin.infinum.marketplace.repository;

import com.ekufrin.infinum.marketplace.model.TokenBlacklist;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface TokenBlacklistRepository extends JpaRepository<TokenBlacklist, UUID> {
    boolean existsByToken(String token);
}
