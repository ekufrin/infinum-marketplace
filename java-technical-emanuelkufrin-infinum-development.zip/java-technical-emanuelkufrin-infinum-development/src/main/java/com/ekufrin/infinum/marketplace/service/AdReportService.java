package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.model.AdReport;
import com.ekufrin.infinum.marketplace.repository.AdReportRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class AdReportService {
    private final AdReportRepository adReportRepository;

    public AdReportService(AdReportRepository adReportRepository) {
        this.adReportRepository = adReportRepository;
    }

    public Page<AdReport> getAllAdReports(Pageable pageable) {
        return adReportRepository.findAll(pageable);
    }

    public AdReport getAdReportById(UUID id) {
        return adReportRepository.findAdReportById(id).orElseThrow(
                () -> new DBException("Ad report with id " + id + " not found")
        );
    }
}
