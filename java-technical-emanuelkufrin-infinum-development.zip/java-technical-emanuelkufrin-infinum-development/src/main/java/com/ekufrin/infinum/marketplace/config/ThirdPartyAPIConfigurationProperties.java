package com.ekufrin.infinum.marketplace.config;

import org.springframework.stereotype.Component;

@Component
abstract class ThirdPartyAPIConfigurationProperties {
    public abstract String getUrl();

    public abstract String setUrl(String url);
}
