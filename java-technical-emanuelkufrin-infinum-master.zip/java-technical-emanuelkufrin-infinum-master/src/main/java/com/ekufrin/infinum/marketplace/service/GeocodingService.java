package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.model.Location;
import com.ekufrin.infinum.marketplace.repository.LocationRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

@Service
public class GeocodingService {
    private static final Logger LOGGER = LoggerFactory.getLogger(GeocodingService.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final String NOMINATIM_URL = "https://nominatim.openstreetmap.org/search";
    private final RestTemplate restTemplate;
    private final LocationRepository locationRepository;

    public GeocodingService(RestTemplate restTemplate, LocationRepository locationRepository) {
        this.restTemplate = restTemplate;
        this.locationRepository = locationRepository;
    }

    @Cacheable(value = "geoCache", key = "#address", unless = "#result == null")
    public String getCoordinatesFromAddress(String address) {
        try {
            String encodedAddress = URLEncoder.encode(address, StandardCharsets.UTF_8);
            String url = NOMINATIM_URL + "?q=" + encodedAddress + "&format=json&limit=1";

            String response = restTemplate.getForObject(url, String.class);

            if (response == null || response.isBlank()) {
                return fetchFromDB(address);
            }

            JsonNode root = MAPPER.readTree(response);
            if (!root.isArray() || root.isEmpty()) {
                return fetchFromDB(address);
            }

            JsonNode location = root.get(0);
            String lat = location.path("lat").asText(null);
            String lon = location.path("lon").asText(null);
            if (lat == null || lon == null) {
                return fetchFromDB(address);
            }

            return lat + "," + lon;

        } catch (Exception e) {
            LOGGER.error("Geocoding failed for [{}] with error {}: ", address, e.getMessage());
            return fetchFromDB(address);
        }
    }

    private String fetchFromDB(String address) {
        Optional<Location> existing = locationRepository.findByAddress(address);
        if (existing.isPresent() && existing.get().getGeoLocation() != null) {
            LOGGER.info("Using fallback coordinates from DB for address: {}", address);
            return existing.get().getGeoLocation();
        }
        LOGGER.error("No coordinates found for address [{}]", address);
        return null;
    }

}
