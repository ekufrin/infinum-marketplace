package com.ekufrin.infinum.marketplace.exception;

public class AlreadyExistsInDB extends RuntimeException {
    public AlreadyExistsInDB(String object) {
        super(String.format("%s already exists.", object));
    }
}
