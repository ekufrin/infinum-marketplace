package com.ekufrin.infinum.marketplace.validation;

import com.ekufrin.infinum.marketplace.dto.ContactInfoRequest;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class AtLeastOneContactValidator implements ConstraintValidator<AtLeastOneContact, ContactInfoRequest> {
    @Override
    public boolean isValid(ContactInfoRequest contactInfoRequest, ConstraintValidatorContext constraintValidatorContext) {
        if (contactInfoRequest == null) {
            return true;
        }

        boolean hasEmail = contactInfoRequest.email() != null && !contactInfoRequest.email().isBlank();
        boolean hasPhoneNumber = contactInfoRequest.phoneNumber() != null && !contactInfoRequest.phoneNumber().isBlank();

        if (!hasEmail && !hasPhoneNumber) {
            constraintValidatorContext.disableDefaultConstraintViolation();
            constraintValidatorContext.buildConstraintViolationWithTemplate("At least one contact method (email or phone number) must be provided.")
                    .addConstraintViolation();
            return false;
        }
        return true;
    }
}
