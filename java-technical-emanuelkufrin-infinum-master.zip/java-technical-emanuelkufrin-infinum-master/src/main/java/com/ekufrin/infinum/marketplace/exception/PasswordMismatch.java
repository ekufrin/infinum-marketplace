package com.ekufrin.infinum.marketplace.exception;

public class PasswordMismatch extends RuntimeException {
    public PasswordMismatch(String message) {
        super(message);
    }
}
