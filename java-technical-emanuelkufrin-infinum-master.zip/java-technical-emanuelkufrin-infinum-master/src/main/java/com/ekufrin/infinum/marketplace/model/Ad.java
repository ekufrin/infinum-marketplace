package com.ekufrin.infinum.marketplace.model;

import com.ekufrin.infinum.marketplace.enums.Condition;
import com.ekufrin.infinum.marketplace.enums.Status;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import org.hibernate.annotations.UuidGenerator;

import java.io.Serializable;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "ad")
public class Ad implements Serializable {
    @Id
    @UuidGenerator
    private UUID id;
    @Column(name = "title", nullable = false)
    private String title;
    @Column(name = "description", nullable = false, length = 2000)
    private String description;
    @JoinColumn(name = "category_id", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY)
    @JsonBackReference("category-ads")
    private Category category;
    @Column(name = "condition", nullable = false)
    @Enumerated(EnumType.STRING)
    private Condition condition;
    @Column(name = "price", nullable = false)
    private Double price;
    @OneToMany(mappedBy = "ad", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<Image> images;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "location_id", nullable = false)
    @JsonBackReference("location-ads")
    private Location location;
    @Column(name = "expires_at", nullable = false)
    private Instant expiresAt;
    @Column(name = "status", nullable = false)
    @Enumerated(EnumType.STRING)
    private Status status;
    @ManyToOne(fetch = FetchType.LAZY)
    @JsonBackReference
    private User author;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "contact_info_id", nullable = false)
    @JsonBackReference("contactInfo-ads")
    private ContactInfo contactInfo;
    private Instant expirationNotifiedAt;

    public Ad(UUID id, String title, String description, Category category, Condition condition, Double price, List<Image> images, Location location, Instant expiresAt, Status status, User author, ContactInfo contactInfo, Instant expirationNotifiedAt) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.category = category;
        this.condition = condition;
        this.price = price;
        this.images = images;
        this.location = location;
        this.expiresAt = expiresAt;
        this.status = status;
        this.author = author;
        this.contactInfo = contactInfo;
        this.expirationNotifiedAt = expirationNotifiedAt;
    }

    public Ad() {

    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Condition getCondition() {
        return condition;
    }

    public void setCondition(Condition condition) {
        this.condition = condition;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public List<Image> getImages() {
        return images;
    }

    public void setImages(List<Image> images) {
        this.images = images;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public Instant getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(Instant expiresAt) {
        this.expiresAt = expiresAt;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public User getAuthor() {
        return author;
    }

    public void setAuthor(User author) {
        this.author = author;
    }

    public ContactInfo getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }

    public Instant getExpirationNotifiedAt() {
        return expirationNotifiedAt;
    }

    public void setExpirationNotifiedAt(Instant expirationNotifiedAt) {
        this.expirationNotifiedAt = expirationNotifiedAt;
    }


}
