package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.enums.Status;
import com.ekufrin.infinum.marketplace.model.Ad;
import com.ekufrin.infinum.marketplace.repository.AdRepository;
import jakarta.transaction.Transactional;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
public class SchedulerService {
    private final AdService adService;
    private final AdRepository adRepository;

    public SchedulerService(AdService adService, AdRepository adRepository) {
        this.adRepository = adRepository;
        this.adService = adService;
    }

    @Scheduled(cron = "0 0 8 * * *", zone = "UTC")
    @Transactional
    public void expireAdsDailyAt8AM() {
        Instant now = Instant.now();
        List<Ad> expiredAds = adRepository.findExpiredAds();
        for (Ad ad : expiredAds) {
            adService.createAndSendRenewalTokenEmail(ad.getId());
            ad.setExpirationNotifiedAt(now);
            ad.setStatus(Status.EXPIRED);
            adRepository.save(ad);
        }
    }
}
