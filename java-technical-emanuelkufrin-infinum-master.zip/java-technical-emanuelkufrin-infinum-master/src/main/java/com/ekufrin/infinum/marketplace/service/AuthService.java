package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.dto.UserLoginRequest;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.repository.UserRepository;
import jakarta.validation.constraints.NotNull;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {
    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;

    public AuthService(AuthenticationManager authenticationManager, UserRepository userRepository) {
        this.authenticationManager = authenticationManager;
        this.userRepository = userRepository;
    }

    public Optional<User> authenticate(@NotNull UserLoginRequest userLoginRequest) throws AuthenticationServiceException {
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(userLoginRequest.email(), userLoginRequest.password()));
        Optional<User> user = userRepository.findByEmail(userLoginRequest.email());
        if (user.isEmpty()) {
            return Optional.empty();
        }
        if (!user.get().isActive()) {
            throw new AuthenticationServiceException("User is not active");
        }
        return user;
    }
}
