package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.model.OTT;
import com.ekufrin.infinum.marketplace.repository.OTTRepository;
import jakarta.transaction.Transactional;
import org.springframework.security.authentication.ott.DefaultOneTimeToken;
import org.springframework.security.authentication.ott.GenerateOneTimeTokenRequest;
import org.springframework.security.authentication.ott.OneTimeToken;
import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationToken;
import org.springframework.security.authentication.ott.OneTimeTokenService;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

@Service
public class OTTService implements OneTimeTokenService {

    private final OTTRepository ottRepository;

    public OTTService(OTTRepository ottRepository) {
        this.ottRepository = ottRepository;
    }

    @Override
    @Transactional
    public OneTimeToken generate(GenerateOneTimeTokenRequest request) {
        OTT token = new OTT();
        token.setValue(request.getUsername());
        token.setExpiresAt(Instant.now().plus(request.getExpiresIn()));

        OTT saved = ottRepository.save(token);
        return new DefaultOneTimeToken(saved.getId().toString(), saved.getValue(), saved.getExpiresAt());
    }

    @Override
    @Transactional
    public OneTimeToken consume(OneTimeTokenAuthenticationToken authenticationToken) {
        OTT token = ottRepository.findById(UUID.fromString(authenticationToken.getTokenValue()))
                .filter(t -> t.getExpiresAt().isAfter(Instant.now()))
                .orElseThrow(() -> new DBException("Invalid or expired OTT"));

        ottRepository.delete(token);
        return new DefaultOneTimeToken(token.getId().toString(), token.getValue(), Instant.now());
    }
}
