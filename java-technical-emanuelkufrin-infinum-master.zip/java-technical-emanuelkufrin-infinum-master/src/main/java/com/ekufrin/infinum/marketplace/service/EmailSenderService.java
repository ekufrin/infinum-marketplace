package com.ekufrin.infinum.marketplace.service;

import com.sendgrid.Method;
import com.sendgrid.Request;
import com.sendgrid.Response;
import com.sendgrid.SendGrid;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Email;
import com.sendgrid.helpers.mail.objects.Personalization;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Map;

@Service
public class EmailSenderService {
    private static final String EMAIL_ENDPOINT = "mail/send";
    private static final Logger log = LoggerFactory.getLogger(EmailSenderService.class);
    private final SendGrid sendGrid;
    private final Email fromEmail;

    public EmailSenderService(SendGrid sendGrid, Email fromEmail) {
        this.fromEmail = fromEmail;
        this.sendGrid = sendGrid;
    }

    public void sendEmail(String toAddress, String templateId, Map<String, Object> dynamicData) throws IOException {
        Email toEmail = new Email(toAddress);
        Mail mail = new Mail();
        mail.setFrom(fromEmail);
        mail.setTemplateId(templateId);

        Personalization personalization = new Personalization();
        personalization.addTo(toEmail);

        dynamicData.forEach(personalization::addDynamicTemplateData);
        mail.addPersonalization(personalization);


        Request request = new Request();
        request.setMethod(Method.POST);
        request.setEndpoint(EMAIL_ENDPOINT);
        request.setBody(mail.build());

        Response response = sendGrid.api(request);

        log.info("[EMAIL] Sent ad expired, response: status={}", response.getStatusCode());
    }
}
