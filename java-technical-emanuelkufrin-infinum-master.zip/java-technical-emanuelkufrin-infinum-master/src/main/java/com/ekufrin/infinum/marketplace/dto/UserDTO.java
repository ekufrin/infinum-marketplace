package com.ekufrin.infinum.marketplace.dto;

import com.ekufrin.infinum.marketplace.enums.Role;

import java.time.Instant;
import java.util.UUID;

public record UserDTO(
        UUID id,
        String name,
        String username,
        String email,
        Role role,
        Boolean isActive,
        Instant createdAt
) {
}
