package com.ekufrin.infinum.marketplace.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import org.hibernate.annotations.UuidGenerator;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "location")
public class Location implements Serializable {
    @Id
    @UuidGenerator
    private UUID id;
    @Column(name = "address", nullable = false)
    private String address;
    @Column(name = "geo_location")
    private String geoLocation;
    @OneToMany(mappedBy = "location")
    @JsonManagedReference("location-ads")
    private List<Ad> ads;

    public Location(UUID id, String address, String geoLocation, List<Ad> ads) {
        this.id = id;
        this.address = address;
        this.geoLocation = geoLocation;
        this.ads = ads;
    }

    public Location() {

    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGeoLocation() {
        return geoLocation;
    }

    public void setGeoLocation(String geoLocation) {
        this.geoLocation = geoLocation;
    }

    public List<Ad> getAds() {
        return ads;
    }

    public void setAds(List<Ad> ads) {
        this.ads = ads;
    }
}
