package com.ekufrin.infinum.marketplace.controller;

import com.ekufrin.infinum.marketplace.dto.JWTResponse;
import com.ekufrin.infinum.marketplace.dto.UserLoginRequest;
import com.ekufrin.infinum.marketplace.dto.UserRegisterRequest;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.service.AuthService;
import com.ekufrin.infinum.marketplace.service.JWTService;
import com.ekufrin.infinum.marketplace.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/auth")
public class AuthController {
    private final JWTService jwtService;
    private final AuthService authService;
    private final UserService userService;

    public AuthController(JWTService jwtService, UserService userService, AuthService authService) {
        this.jwtService = jwtService;
        this.authService = authService;
        this.userService = userService;
    }

    @PostMapping("/register")
    public ResponseEntity<JWTResponse> registerUser(@RequestBody @Valid UserRegisterRequest userRegisterRequest) {
        User user = userService.addUser(userRegisterRequest);
        JWTResponse jwtResponse = generateTokenResponse(user);
        return ResponseEntity.status(HttpStatus.CREATED).header("Authorization", jwtResponse.tokenType() + " " + jwtResponse.token()).body(jwtResponse);
    }

    @PostMapping("/login")
    public ResponseEntity<JWTResponse> loginUser(@RequestBody @Valid UserLoginRequest userLoginRequest) {
        Optional<User> user = authService.authenticate(userLoginRequest);
        if (user.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        JWTResponse jwtResponse = generateTokenResponse(user.get());
        return ResponseEntity.ok().header("Authorization", jwtResponse.tokenType() + " " + jwtResponse.token()).body(jwtResponse);
    }

    private JWTResponse generateTokenResponse(User user) {
        String token = jwtService.generateToken(user);
        String tokenType = "Bearer";
        long expiresIn = jwtService.getExpirationTime();
        return new JWTResponse(token, tokenType, expiresIn);
    }


}
