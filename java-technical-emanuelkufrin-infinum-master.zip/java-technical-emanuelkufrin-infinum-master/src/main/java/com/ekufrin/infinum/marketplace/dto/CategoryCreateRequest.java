package com.ekufrin.infinum.marketplace.dto;

import jakarta.validation.constraints.NotBlank;

public record CategoryCreateRequest(
        @NotBlank(message = "Name is required")
        String name,
        Boolean active
) {
}
