package com.ekufrin.infinum.marketplace.controller;

import com.ekufrin.infinum.marketplace.dto.CategoryChangeRequest;
import com.ekufrin.infinum.marketplace.dto.CategoryCreateRequest;
import com.ekufrin.infinum.marketplace.dto.PagedResponse;
import com.ekufrin.infinum.marketplace.model.Category;
import com.ekufrin.infinum.marketplace.service.CategoryService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/categories")
public class CategoryController {
    private final CategoryService categoryService;

    public CategoryController(CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @PostMapping
    public ResponseEntity<Category> addCategory(@RequestBody @Valid CategoryCreateRequest request) {
        Category createdCategory = categoryService.addCategory(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdCategory);
    }

    @GetMapping
    public ResponseEntity<PagedResponse<Category>> getAllCategories(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) Boolean active,
            Pageable pageable
    ) {
        return ResponseEntity.ok(PagedResponse.from(categoryService.getAllCategoriesAsPageWithFilterAndSorting(search, active, pageable)));
    }

    @PatchMapping("/{identifier}")
    public ResponseEntity<Category> updateCategory(@PathVariable String identifier, @RequestBody @Valid CategoryChangeRequest request) {
        Category renamedCategory = categoryService.updateCategory(identifier, request);
        return ResponseEntity.ok(renamedCategory);
    }
}
