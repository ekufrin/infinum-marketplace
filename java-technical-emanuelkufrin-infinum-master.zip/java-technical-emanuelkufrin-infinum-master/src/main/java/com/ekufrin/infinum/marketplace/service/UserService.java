package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.dto.ContactInfoRequest;
import com.ekufrin.infinum.marketplace.dto.ContactInfoResponse;
import com.ekufrin.infinum.marketplace.dto.UserDTO;
import com.ekufrin.infinum.marketplace.dto.UserPasswordChange;
import com.ekufrin.infinum.marketplace.dto.UserRegisterRequest;
import com.ekufrin.infinum.marketplace.enums.Role;
import com.ekufrin.infinum.marketplace.exception.AlreadyExistsInDB;
import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.exception.PasswordMismatch;
import com.ekufrin.infinum.marketplace.model.ContactInfo;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.repository.ContactInfoRepository;
import com.ekufrin.infinum.marketplace.repository.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final ContactInfoRepository contactInfoRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, ContactInfoRepository contactInfoRepository, BCryptPasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.contactInfoRepository = contactInfoRepository;
        this.passwordEncoder = passwordEncoder;
    }

    private static UserDTO toDTO(User user) {
        return new UserDTO(
                user.getId(),
                user.getName(),
                user.getUserUsername(),
                user.getEmail(),
                user.getRole(),
                user.isActive(),
                user.getCreatedAt()
        );
    }

    static ContactInfoResponse toDTO(ContactInfo contactInfo) {
        return new ContactInfoResponse(
                contactInfo.getId(),
                contactInfo.getEmail(),
                contactInfo.getPhoneNumber()
        );
    }

    public User addUser(UserRegisterRequest userRegisterRequest) {
        if (emailExists(userRegisterRequest.email())) {
            throw new AlreadyExistsInDB(userRegisterRequest.email());
        }
        String encodedPassword = passwordEncoder.encode(userRegisterRequest.password());

        Instant createdAt = Instant.now();
        String username = generateUsername(userRegisterRequest.email());

        User user = new User.Builder()
                .name(userRegisterRequest.name())
                .email(userRegisterRequest.email())
                .username(username)
                .password(encodedPassword)
                .isActive(true)
                .role(Role.USER)
                .createdAt(createdAt)
                .build();

        return userRepository.save(user);
    }

    public User changeUserPassword(String id, UserPasswordChange userPasswordChange) {
        Optional<User> user = userRepository.findById(UUID.fromString(id));
        if (user.isEmpty()) {
            throw new DBException("User not found.");
        }
        String currentPassword = user.get().getPassword();
        if (!passwordEncoder.matches(userPasswordChange.oldPassword(), currentPassword)) {
            throw new PasswordMismatch("Old password does not match the current password.");
        }
        if (passwordEncoder.matches(userPasswordChange.newPassword(), currentPassword)) {
            throw new PasswordMismatch("New password must be different from the old password.");
        }
        String encodedPassword = passwordEncoder.encode(userPasswordChange.newPassword());
        user.get().setPassword(encodedPassword);
        return userRepository.save(user.get());
    }

    public Page<UserDTO> getAllUsersAsPageWithFilterAndSorting(String search, Boolean active, Pageable pageable) {
        return userRepository.findAllFiltered(search, active, pageable);
    }

    public UserDTO getUserByEmail(String email) {
        User user = userRepository.findByEmail(email).orElseThrow(() -> new DBException("User with email " + email + " not found."));
        return toDTO(user);
    }

    public UserDTO getUserById(String id) {
        User user = userRepository.findById(UUID.fromString(id)).orElseThrow(() -> new DBException("User with id " + id + " not found."));
        return toDTO(user);
    }

    public ContactInfoResponse createContactInfo(ContactInfoRequest request, UserDetails userDetails) {
        User user = userRepository.findById(UUID.fromString(userDetails.getUsername())).orElseThrow(
                () -> new DBException("User not found")
        );
        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setEmail(request.email());
        contactInfo.setPhoneNumber(request.phoneNumber());
        contactInfo.setUser(user);
        return toDTO(contactInfoRepository.save(contactInfo));
    }

    public Page<ContactInfoResponse> getAllContactInfoForUser(UUID id, Pageable pageable) {
        return contactInfoRepository.findAllByUser_Id(id, pageable).map(UserService::toDTO);
    }

    private boolean emailExists(String email) {
        return userRepository.existsByEmailIgnoreCase(email);
    }

    private String generateUsername(String email) {
        Pattern pattern = Pattern.compile("^([A-Za-z0-9._%+-]+)@([A-Za-z0-9.-]+)\\.[A-Za-z]{2,}$");
        Matcher matcher = pattern.matcher(email);

        if (!matcher.matches()) {
            throw new IllegalArgumentException("Wrong email format: " + email);
        }

        String baseUsername = matcher.group(1);
        String newUsername = baseUsername;
        int suffix = 1;

        while (userRepository.existsByUsernameIgnoreCase(newUsername)) {
            newUsername = baseUsername + suffix;
            suffix++;
        }
        return newUsername;
    }
}
