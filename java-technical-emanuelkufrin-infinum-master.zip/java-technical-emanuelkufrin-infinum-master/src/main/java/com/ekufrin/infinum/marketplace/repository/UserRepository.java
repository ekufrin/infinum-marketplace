package com.ekufrin.infinum.marketplace.repository;

import com.ekufrin.infinum.marketplace.dto.UserDTO;
import com.ekufrin.infinum.marketplace.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface UserRepository extends JpaRepository<User, UUID> {
    Optional<User> findByEmail(String email);

    boolean existsByEmailIgnoreCase(String email);

    boolean existsByUsernameIgnoreCase(String username);

    @Query("""
                SELECT new com.ekufrin.infinum.marketplace.dto.UserDTO(
                    u.id,
                    u.name,
                    u.username,
                    u.email,
                    u.role,
                    u.isActive,
                    u.createdAt
                )
                FROM User u
                WHERE
                    (
                        :search IS NULL
                        OR :search = ''
                        OR LOWER(u.username) LIKE LOWER(CONCAT('%', :search, '%'))
                        OR LOWER(u.email) LIKE LOWER(CONCAT('%', :search, '%'))
                    )
                    AND (
                        :active IS NULL
                        OR u.isActive = :active
                    )
            """)
    Page<UserDTO> findAllFiltered(
            @Param("search") String search,
            @Param("active") Boolean active,
            Pageable pageable
    );

    @Query("SELECT u FROM User u LEFT JOIN FETCH u.contactInfo WHERE u.id = :id")
    Optional<User> findByIdWithContactInfo(@Param("id") UUID id);
}
