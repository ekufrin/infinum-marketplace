package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.interfaces.UserIdentifierStrategy;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.repository.UserRepository;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.UUID;

@Component
public class UuidIdentifierStrategy implements UserIdentifierStrategy {
    private final UserRepository repo;

    public UuidIdentifierStrategy(UserRepository repo) {
        this.repo = repo;
    }

    @Override
    public boolean supports(String identifier) {
        try {
            UUID.fromString(identifier);
            return true;
        } catch (Exception _) {
            return false;
        }
    }

    @Override
    public Optional<User> findUser(String identifier) {
        return repo.findById(UUID.fromString(identifier));
    }
}
