package com.ekufrin.infinum.marketplace.dto;

import com.ekufrin.infinum.marketplace.validation.AtLeastOneContact;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;

@AtLeastOneContact
public record ContactInfoRequest(
        @Email(message = "Email should be in valid format",
                regexp = "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,63}",
                flags = Pattern.Flag.CASE_INSENSITIVE)
        String email,
        @Pattern(message = "Phone number should be in format ex. +385...",
                regexp = "^\\+[0-9]{1,3}[0-9\\-\\(\\)\\/\\.\\s]{6,14}$")
        String phoneNumber
) {
}
