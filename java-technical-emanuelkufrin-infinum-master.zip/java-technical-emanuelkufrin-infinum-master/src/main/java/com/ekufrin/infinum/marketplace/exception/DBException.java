package com.ekufrin.infinum.marketplace.exception;

public class DBException extends RuntimeException {
    public DBException(String message) {
        super(message);
    }
}
