package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.dto.LocationResponse;
import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.model.Location;
import com.ekufrin.infinum.marketplace.repository.LocationRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LocationService {
    private final LocationRepository locationRepository;
    private final GeocodingService geocodingService;

    public LocationService(LocationRepository locationRepository, GeocodingService geocodingService) {
        this.locationRepository = locationRepository;
        this.geocodingService = geocodingService;
    }

    static LocationResponse toDTO(Location location) {
        return new LocationResponse(
                location.getAddress(),
                location.getGeoLocation()
        );
    }

    public Location addLocation(String address) {
        if (address == null || address.isBlank()) {
            throw new DBException("Address cannot be null or empty.");
        }
        String geoLocation = geocodingService.getCoordinatesFromAddress(address);
        if (geoLocation == null) {
            throw new DBException("Could not determine geolocation for the provided address.");
        }
        Location location = new Location();
        location.setAddress(address);
        location.setGeoLocation(geoLocation);
        return locationRepository.save(location);
    }

    public Optional<Location> findByAddress(String address) {
        Optional<Location> existing = locationRepository.findFirstByAddress(address);
        if (existing.isPresent()) {
            Location newLocation = new Location();
            newLocation.setAddress(existing.get().getAddress());
            newLocation.setGeoLocation(existing.get().getGeoLocation());
            return Optional.of(locationRepository.save(newLocation));
        }
        return Optional.empty();
    }
}
