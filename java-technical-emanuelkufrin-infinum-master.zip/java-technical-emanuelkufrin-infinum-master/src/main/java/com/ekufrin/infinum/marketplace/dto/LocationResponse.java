package com.ekufrin.infinum.marketplace.dto;

public record LocationResponse(
        String address,
        String geoLocation
) {
}
