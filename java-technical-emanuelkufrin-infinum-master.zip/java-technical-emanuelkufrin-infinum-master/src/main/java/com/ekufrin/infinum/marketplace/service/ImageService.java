package com.ekufrin.infinum.marketplace.service;

import com.ekufrin.infinum.marketplace.dto.ImageResponse;
import com.ekufrin.infinum.marketplace.exception.UploadException;
import com.ekufrin.infinum.marketplace.model.Ad;
import com.ekufrin.infinum.marketplace.model.Image;
import com.ekufrin.infinum.marketplace.repository.ImageRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.UUID;

@Service
public class ImageService {
    private static final Path IMAGE_UPLOAD_DIR = Paths.get(System.getProperty("user.dir"), "uploads", "images");
    private static final Long MAX_FILE_SIZE = 5 * 1024 * 1024L; // 5 MB
    private static final List<String> ALLOWED_CONTENT_TYPES = List.of("image/jpeg", "image/png");
    private final ImageRepository imageRepository;

    public ImageService(ImageRepository imageRepository) {
        this.imageRepository = imageRepository;
    }

    static ImageResponse toDTO(Image image) {
        return new ImageResponse(image.getId());
    }

    @Transactional
    public List<ImageResponse> uploadImages(List<MultipartFile> files) {
        if (files.size() > 5) {
            throw new UploadException("Cannot upload more than 5 files at once");
        }

        List<Image> uploadedImages = new ArrayList<>();

        try {
            if (!Files.exists(IMAGE_UPLOAD_DIR)) {
                Files.createDirectories(IMAGE_UPLOAD_DIR);
            }

            for (MultipartFile file : files) {
                validateFile(file);

                UUID id = UUID.randomUUID();
                String ext = file.getOriginalFilename() != null ? file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")) : ".jpg";
                String filename = id + ext;
                Path filePath = IMAGE_UPLOAD_DIR.resolve(filename);
                Files.write(filePath, file.getBytes());

                Image image = new Image();
                image.setId(id);
                image.setCreatedAt(Instant.now());
                image.setAd(null);

                uploadedImages.add(image);
            }

            return imageRepository.saveAll(uploadedImages).stream().map(ImageService::toDTO).toList();

        } catch (IOException e) {
            throw new UploadException("Failed to save image: " + e.getMessage());
        }
    }

    @Transactional
    public void assignImagesToAd(List<UUID> imageIds, Ad ad) {
        ArrayList<UUID> ids = new ArrayList<>(new LinkedHashSet<>(imageIds));
        if (ids.size() > 5) {
            throw new UploadException("An ad can have at most 5 images.");
        }
        if (ids.isEmpty()) {
            List<UUID> toDelete = imageRepository.findIdsByAd(ad.getId());
            deleteFilesByImageIds(toDelete);
            imageRepository.deleteAllForAd(ad.getId());
            return;
        }
        long allowed = imageRepository.countAssignableToAd(ad.getId(), ids);
        if (allowed != ids.size()) {
            throw new UploadException("Some images are invalid or already assigned to another ad.");
        }
        var toDelete = imageRepository.findIdsByAdExcept(ad.getId(), ids);
        deleteFilesByImageIds(toDelete);
        imageRepository.deleteAllForAdExcept(ad.getId(), ids);
        imageRepository.assignToAdIfUnassigned(ad, ids);
    }


    private void validateFile(MultipartFile file) {
        if (file.isEmpty()) {
            throw new UploadException("File is empty");
        }
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new UploadException("File size exceeds the maximum limit of 5MB");
        }
        if (!ALLOWED_CONTENT_TYPES.contains(file.getContentType())) {
            throw new UploadException("Invalid file type. Only JPG and PNG are allowed");
        }
    }

    private void deleteFilesByImageIds(Collection<UUID> ids) {
        for (UUID id : ids) {
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(IMAGE_UPLOAD_DIR, id.toString() + ".*")) {
                for (Path p : stream) {
                    try {
                        Files.deleteIfExists(p);
                    } catch (IOException _) {
                        throw new UploadException("Failed to delete image file: " + p.getFileName());
                    }
                }
            } catch (IOException _) {
                throw new UploadException("Failed to list image files for deletion");
            }
        }
    }
}