package com.ekufrin.infinum.marketplace.repository;

import com.ekufrin.infinum.marketplace.enums.Condition;
import com.ekufrin.infinum.marketplace.model.Ad;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface AdRepository extends JpaRepository<Ad, UUID> {
    @Query("SELECT DISTINCT a FROM Ad a LEFT JOIN FETCH a.images WHERE a.id = :id")
    Optional<Ad> findByIdWithImages(@Param("id") UUID id);

    @Query("""
            SELECT a FROM Ad a
            WHERE
                (:title IS NULL OR :title = '' OR LOWER(a.title) LIKE LOWER(CONCAT('%', :title, '%')))
                AND (:category IS NULL OR :category = '' OR LOWER(a.category.name) LIKE LOWER(CONCAT('%', :category, '%')))
                AND (:condition IS NULL OR a.condition = :condition)
                AND (:minPrice IS NULL OR a.price >= :minPrice)
                AND (:maxPrice IS NULL OR a.price <= :maxPrice)
                AND a.status = com.ekufrin.infinum.marketplace.enums.Status.ACTIVE
            """)
    Page<Ad> findAllFiltered(@Param("title") String title,
                             @Param("category") String category,
                             @Param("condition") Condition condition,
                             @Param("minPrice") Double minPrice,
                             @Param("maxPrice") Double maxPrice,
                             Pageable pageable);

    @Query("SELECT a FROM Ad a WHERE a.author.id = :uuid")
    Page<Ad> findAllByAuthorId(UUID uuid, Pageable pageable);

    @Query("""
            
            SELECT a FROM Ad a
            WHERE a.expiresAt < CURRENT TIMESTAMP
            AND a.expirationNotifiedAt IS NULL
            """)
    List<Ad> findExpiredAds();
}
