package com.ekufrin.infinum.marketplace.repository;

import com.ekufrin.infinum.marketplace.model.ContactInfo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface ContactInfoRepository extends JpaRepository<ContactInfo, UUID> {
    Page<ContactInfo> findAllByUser_Id(UUID userId, Pageable pageable);
}
