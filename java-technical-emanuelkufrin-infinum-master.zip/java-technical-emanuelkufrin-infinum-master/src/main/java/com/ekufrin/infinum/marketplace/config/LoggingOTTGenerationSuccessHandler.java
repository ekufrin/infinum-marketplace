package com.ekufrin.infinum.marketplace.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.ott.OneTimeToken;
import org.springframework.security.web.authentication.ott.OneTimeTokenGenerationSuccessHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class LoggingOTTGenerationSuccessHandler implements OneTimeTokenGenerationSuccessHandler {
    private static final Logger log = LoggerFactory.getLogger(LoggingOTTGenerationSuccessHandler.class);

    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response, OneTimeToken token) throws IOException {
        log.info("One-time token generated for value '{}', token='{}', expiresIn={}",
                token.getTokenValue(), token.getTokenValue(), token.getExpiresAt());
        response.setStatus(HttpServletResponse.SC_OK);
    }
}
