package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.config.SecurityConfiguration;
import com.ekufrin.infinum.marketplace.controller.AdController;
import com.ekufrin.infinum.marketplace.dto.AdCreateRequest;
import com.ekufrin.infinum.marketplace.dto.AdResponse;
import com.ekufrin.infinum.marketplace.dto.ContactInfoResponse;
import com.ekufrin.infinum.marketplace.dto.LocationResponse;
import com.ekufrin.infinum.marketplace.enums.Condition;
import com.ekufrin.infinum.marketplace.enums.Status;
import com.ekufrin.infinum.marketplace.model.Location;
import com.ekufrin.infinum.marketplace.service.AdService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = AdController.class, excludeAutoConfiguration = {SecurityConfiguration.class})
@AutoConfigureMockMvc(addFilters = false)
class AdControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockitoBean
    private AdService adService;
    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void createAd_ValidRequest_ReturnsCreated() throws Exception {
        UUID categoryId = UUID.randomUUID();
        UUID contactInfoId = UUID.randomUUID();
        Location location = new Location(UUID.randomUUID(), "123 Main St", "12.34,56.78", List.of());

        AdCreateRequest request = new AdCreateRequest(
                "Test Ad",
                "Description",
                categoryId,
                Condition.NEW,
                100.00,
                contactInfoId,
                List.of(),
                location
        );

        AdResponse response = new AdResponse(
                "Test Ad",
                "Description",
                100.00,
                new ContactInfoResponse(UUID.randomUUID(), "test@example.com", "+1234567890"),
                "Electronics",
                "NEW",
                "ACTIVE",
                Instant.now().plus(30, ChronoUnit.DAYS),
                List.of(),
                new LocationResponse("123 Main St", "12.34,56.78")
        );

        when(adService.createAd(any(AdCreateRequest.class), any())).thenReturn(response);

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.title").value("Test Ad"))
                .andExpect(jsonPath("$.description").value("Description"))
                .andExpect(jsonPath("$.price").value(100.00));

        verify(adService).createAd(any(AdCreateRequest.class), any());
    }


    @Test
    void createAd_EmptyTitle_ReturnsBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "",
                "Description",
                UUID.randomUUID(),
                Condition.NEW,
                100.00,
                UUID.randomUUID(),
                List.of(),
                new Location(UUID.randomUUID(), "123 Main St", "12.34,56.78", List.of())
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void createAd_MissingDescription_ReturnsBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Test Ad",
                null,
                UUID.randomUUID(),
                Condition.NEW,
                100.00,
                UUID.randomUUID(),
                List.of(),
                new Location(UUID.randomUUID(), "123 Main St", "12.34,56.78", List.of())
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void createAd_NegativePrice_ReturnsBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Test Ad",
                "Description",
                UUID.randomUUID(),
                Condition.NEW,
                -10.00,
                UUID.randomUUID(),
                List.of(),
                new Location(UUID.randomUUID(), "123 Main St", "12.34,56.78", List.of())
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void createAd_NullPrice_ReturnsBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Test Ad",
                "Description",
                UUID.randomUUID(),
                Condition.NEW,
                null,
                UUID.randomUUID(),
                List.of(),
                new Location(UUID.randomUUID(), "123 Main St", "12.34,56.78", List.of())
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void createAd_MissingContactInfoId_ReturnsBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Test Ad",
                "Description",
                UUID.randomUUID(),
                Condition.NEW,
                100.00,
                null,
                List.of(),
                new Location(UUID.randomUUID(), "123 Main St", "12.34,56.78", List.of())
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void createAd_ZeroPrice_ReturnsBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Free Item",
                "Free stuff",
                UUID.randomUUID(),
                Condition.NEW,
                0.0,
                UUID.randomUUID(),
                List.of(),
                new Location(UUID.randomUUID(), "123 Main St", "12.34,56.78", List.of())
        );
        AdResponse response = new AdResponse(
                "Free Item",
                "Free stuff",
                0.0,
                new ContactInfoResponse(UUID.randomUUID(), "test@example.com", "+1234567890"),
                "Electronics",
                "NEW",
                "ACTIVE",
                Instant.now().plus(30, ChronoUnit.DAYS),
                List.of(),
                new LocationResponse("123 Main St", "12.34,56.78")
        );

        when(adService.createAd(any(AdCreateRequest.class), any(UserDetails.class))).thenReturn(response);

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Price must be a positive value"));
    }

    @Test
    void givenNoFilters_whenGetAllAds_thenReturnsPagedAds() throws Exception {
        AdResponse response = new AdResponse(
                "iPhone 13",
                "Almost new",
                500.0,
                new ContactInfoResponse(UUID.randomUUID(), "seller@example.com", "+385911111111"),
                "Electronics",
                Condition.USED.name(),
                Status.ACTIVE.name(),
                Instant.now().plus(30, ChronoUnit.DAYS),
                List.of(),
                new LocationResponse("Ilica 42, 10000 Zagreb", "45.8150,15.9819")
        );

        when(adService.getAllAdsWithFilterAndSorting(isNull(), isNull(), isNull(), isNull(), isNull(), any(Pageable.class)))
                .thenReturn(new PageImpl<>(List.of(response)));

        mockMvc.perform(get("/ads")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[0].title").value("iPhone 13"))
                .andExpect(jsonPath("$.content[0].price").value(500.0))
                .andExpect(jsonPath("$.totalElements").value(1));
    }

    @Test
    void givenPageableWithSort_whenGetAllAds_thenServiceReceivesDefaultSortExpiresAtDesc() throws Exception {
        when(adService.getAllAdsWithFilterAndSorting(any(), any(), any(), any(), any(), any(Pageable.class)))
                .thenReturn(Page.empty());

        mockMvc.perform(get("/ads")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

        ArgumentCaptor<Pageable> pageableCaptor = ArgumentCaptor.forClass(Pageable.class);
        verify(adService).getAllAdsWithFilterAndSorting(any(), any(), any(), any(), any(), pageableCaptor.capture());
        Pageable captured = pageableCaptor.getValue();
        assertThat(captured.getSort().getOrderFor("expiresAt")).isNotNull();
        assertThat(Objects.requireNonNull(captured.getSort().getOrderFor("expiresAt")).isDescending()).isTrue();
    }

    @Test
    void givenFilters_whenGetAllAds_thenPassesParamsAndReturnsEmpty() throws Exception {
        when(adService.getAllAdsWithFilterAndSorting(any(), any(), any(), any(), any(), any(Pageable.class)))
                .thenReturn(Page.empty());

        mockMvc.perform(get("/ads")
                        .param("title", "gaming")
                        .param("category", "Electronics")
                        .param("condition", "USED")
                        .param("minPrice", "800")
                        .param("maxPrice", "900")
                        .param("page", "0")
                        .param("size", "10")
                        .param("sort", "price,asc")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.totalElements").value(0));

        ArgumentCaptor<String> titleCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> categoryCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Condition> conditionCaptor = ArgumentCaptor.forClass(Condition.class);
        ArgumentCaptor<Double> minCaptor = ArgumentCaptor.forClass(Double.class);
        ArgumentCaptor<Double> maxCaptor = ArgumentCaptor.forClass(Double.class);
        ArgumentCaptor<Pageable> pageableCaptor = ArgumentCaptor.forClass(Pageable.class);

        verify(adService).getAllAdsWithFilterAndSorting(
                titleCaptor.capture(),
                categoryCaptor.capture(),
                conditionCaptor.capture(),
                minCaptor.capture(),
                maxCaptor.capture(),
                pageableCaptor.capture()
        );

        assertThat(titleCaptor.getValue()).isEqualTo("gaming");
        assertThat(categoryCaptor.getValue()).isEqualTo("Electronics");
        assertThat(conditionCaptor.getValue()).isEqualTo(Condition.USED);
        assertThat(minCaptor.getValue()).isEqualTo(800.0);
        assertThat(maxCaptor.getValue()).isEqualTo(900.0);
        Pageable capturedPageable = pageableCaptor.getValue();
        assertThat(capturedPageable.getPageNumber()).isZero();
        assertThat(capturedPageable.getPageSize()).isEqualTo(10);
        assertThat(capturedPageable.getSort().getOrderFor("price")).isNotNull();
        assertThat(Objects.requireNonNull(capturedPageable.getSort().getOrderFor("price")).isAscending()).isTrue();
    }

    @Test
    void getAdById_ReturnsAdResponse_WhenAdExists() throws Exception {
        UUID id = UUID.randomUUID();
        AdResponse response = new AdResponse(
                "iPhone 13",
                "Almost new",
                500.0,
                new ContactInfoResponse(UUID.randomUUID(), "seller@example.com", "+385911111111"),
                "Electronics",
                Condition.USED.name(),
                Status.ACTIVE.name(),
                Instant.now().plus(30, ChronoUnit.DAYS),
                List.of(),
                new LocationResponse("Ilica 42, 10000 Zagreb", "45.8150,15.9819")
        );

        when(adService.getAdById(id)).thenReturn(response);

        mockMvc.perform(get("/ads/{id}", id)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("iPhone 13"))
                .andExpect(jsonPath("$.price").value(500.0))
                .andExpect(jsonPath("$.category").value("Electronics"))
                .andExpect(jsonPath("$.condition").value(Condition.USED.name()))
                .andExpect(jsonPath("$.status").value(Status.ACTIVE.name()));
    }

    @Test
    void getAdById_ReturnsNotFound_WhenAdMissing() throws Exception {
        UUID id = UUID.randomUUID();
        when(adService.getAdById(id)).thenThrow(new com.ekufrin.infinum.marketplace.exception.DBException("Ad not found."));

        mockMvc.perform(get("/ads/{id}", id)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Ad not found."));
    }

    @Test
    void editAd_ValidRequest_ReturnsUpdatedAd() throws Exception {
        UUID adId = UUID.randomUUID();
        AdCreateRequest request = new AdCreateRequest(
                "Updated Title",
                "Updated Description",
                UUID.randomUUID(),
                Condition.USED,
                200.0,
                UUID.randomUUID(),
                List.of(UUID.randomUUID()),
                new Location(UUID.randomUUID(), "Updated Address", "45.8150,15.9819", List.of())
        );

        AdResponse response = new AdResponse(
                "Updated Title",
                "Updated Description",
                200.0,
                new ContactInfoResponse(UUID.randomUUID(), "updated@example.com", "+385911111111"),
                "Updated Category",
                "USED",
                "ACTIVE",
                Instant.now().plus(30, ChronoUnit.DAYS),
                List.of(),
                new LocationResponse("Updated Address", "45.8150,15.9819")
        );

        when(adService.editAd(eq(adId), any(AdCreateRequest.class), any())).thenReturn(response);

        mockMvc.perform(put("/ads/{id}", adId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Updated Title"))
                .andExpect(jsonPath("$.description").value("Updated Description"))
                .andExpect(jsonPath("$.price").value(200.0))
                .andExpect(jsonPath("$.condition").value("USED"))
                .andExpect(jsonPath("$.status").value("ACTIVE"))
                .andExpect(jsonPath("$.location.address").value("Updated Address"));

        verify(adService).editAd(eq(adId), any(AdCreateRequest.class), any());
    }

    @Test
    void editAd_InvalidAdId_ReturnsNotFound() throws Exception {
        UUID adId = UUID.randomUUID();
        AdCreateRequest request = new AdCreateRequest(
                "Updated Title",
                "Updated Description",
                UUID.randomUUID(),
                Condition.USED,
                200.0,
                UUID.randomUUID(),
                List.of(UUID.randomUUID()),
                new Location(UUID.randomUUID(), "Updated Address", "45.8150,15.9819", List.of())
        );

        when(adService.editAd(eq(adId), any(AdCreateRequest.class), any()))
                .thenThrow(new com.ekufrin.infinum.marketplace.exception.DBException("Ad not found."));

        mockMvc.perform(put("/ads/{id}", adId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Ad not found."));

        verify(adService).editAd(eq(adId), any(AdCreateRequest.class), any());
    }

    @Test
    void renewAd_ValidToken_ReturnsSuccessMessage() throws Exception {
        String validToken = "validToken";

        when(adService.renewAdByToken(any(OneTimeTokenAuthenticationToken.class))).thenReturn(true);

        mockMvc.perform(get("/ads/renew")
                        .param("token", validToken)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").value("Ad renewed sucessfully for next 30 days."));

        verify(adService).renewAdByToken(any(OneTimeTokenAuthenticationToken.class));
    }

    @Test
    void renewAd_InvalidToken_ReturnsBadRequestWithErrorMessage() throws Exception {
        String invalidToken = "invalidToken";

        when(adService.renewAdByToken(any(OneTimeTokenAuthenticationToken.class))).thenReturn(false);

        mockMvc.perform(get("/ads/renew")
                        .param("token", invalidToken)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$").value("Invalid or expired token."));

        verify(adService).renewAdByToken(any(OneTimeTokenAuthenticationToken.class));
    }
}
