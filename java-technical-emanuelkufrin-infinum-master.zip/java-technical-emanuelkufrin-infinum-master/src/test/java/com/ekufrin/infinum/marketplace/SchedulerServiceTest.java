package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.enums.Status;
import com.ekufrin.infinum.marketplace.model.Ad;
import com.ekufrin.infinum.marketplace.repository.AdRepository;
import com.ekufrin.infinum.marketplace.service.AdService;
import com.ekufrin.infinum.marketplace.service.SchedulerService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SchedulerServiceTest {

    @Mock
    private AdRepository adRepository;

    @Mock
    private AdService adService;

    @InjectMocks
    private SchedulerService schedulerService;

    @Test
    void expireAdsDailyAt8AM_ShouldProcessExpiredAdsAndSendRenewalEmails() {
        Instant now = Instant.now();
        Instant dayAgo = now.minus(1, ChronoUnit.DAYS);

        Ad ad1 = new Ad();
        ad1.setId(UUID.randomUUID());
        ad1.setExpiresAt(dayAgo.plus(1, ChronoUnit.HOURS));
        ad1.setExpirationNotifiedAt(null);
        ad1.setStatus(Status.ACTIVE);

        Ad ad2 = new Ad();
        ad2.setId(UUID.randomUUID());
        ad2.setExpiresAt(dayAgo.plus(2, ChronoUnit.HOURS));
        ad2.setExpirationNotifiedAt(null);
        ad2.setStatus(Status.ACTIVE);

        when(adRepository.findExpiredAds())
                .thenReturn(List.of(ad1, ad2));

        schedulerService.expireAdsDailyAt8AM();

        verify(adService).createAndSendRenewalTokenEmail(ad1.getId());
        verify(adService).createAndSendRenewalTokenEmail(ad2.getId());
        verify(adRepository).save(ad1);
        verify(adRepository).save(ad2);

        assertThat(ad1.getExpirationNotifiedAt()).isNotNull();
        assertThat(ad1.getStatus()).isEqualTo(Status.EXPIRED);
        assertThat(ad2.getExpirationNotifiedAt()).isNotNull();
        assertThat(ad2.getStatus()).isEqualTo(Status.EXPIRED);
    }

    @Test
    void expireAdsDailyAt8AM_ShouldHandleNoExpiredAdsGracefully() {
        when(adRepository.findExpiredAds())
                .thenReturn(List.of());

        schedulerService.expireAdsDailyAt8AM();

        verify(adService, never()).createAndSendRenewalTokenEmail(any());
        verify(adRepository, never()).save(any());
    }

}
