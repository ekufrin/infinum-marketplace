package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.model.Location;
import com.ekufrin.infinum.marketplace.repository.LocationRepository;
import com.ekufrin.infinum.marketplace.service.GeocodingService;
import com.ekufrin.infinum.marketplace.service.LocationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LocationServiceTest {

    @Mock
    private LocationRepository locationRepository;

    @Mock
    private GeocodingService geocodingService;

    @InjectMocks
    private LocationService locationService;

    private Location testLocation;

    @BeforeEach
    void setUp() {
        testLocation = new Location();
        testLocation.setId(UUID.randomUUID());
        testLocation.setAddress("Zagreb, Croatia");
        testLocation.setGeoLocation("45.8150,15.9819");
    }

    @Test
    void addLocation_ValidAddress_ReturnsLocation() {
        when(geocodingService.getCoordinatesFromAddress("Zagreb, Croatia")).thenReturn("45.8150,15.9819");
        when(locationRepository.save(any(Location.class))).thenReturn(testLocation);

        Location result = locationService.addLocation("Zagreb, Croatia");

        assertThat(result).isNotNull();
        assertThat(result.getAddress()).isEqualTo("Zagreb, Croatia");
        assertThat(result.getGeoLocation()).isEqualTo("45.8150,15.9819");
        verify(geocodingService).getCoordinatesFromAddress("Zagreb, Croatia");
        verify(locationRepository).save(any(Location.class));
    }

    @Test
    void addLocation_NullAddress_ThrowsDBException() {
        assertThatThrownBy(() -> locationService.addLocation(null))
                .isInstanceOf(DBException.class)
                .hasMessage("Address cannot be null or empty.");

        verify(geocodingService, never()).getCoordinatesFromAddress(anyString());
        verify(locationRepository, never()).save(any(Location.class));
    }

    @Test
    void addLocation_GeocodingReturnsNull_ThrowsDBException() {
        when(geocodingService.getCoordinatesFromAddress("Invalid Address")).thenReturn(null);

        assertThatThrownBy(() -> locationService.addLocation("Invalid Address"))
                .isInstanceOf(DBException.class)
                .hasMessage("Could not determine geolocation for the provided address.");

        verify(geocodingService).getCoordinatesFromAddress("Invalid Address");
        verify(locationRepository, never()).save(any(Location.class));
    }

    @Test
    void addLocation_AddressWithSpecialCharacters_ReturnsLocation() {
        String specialAddress = "Trg bana Josipa Jelačića 10, Zagreb";
        when(geocodingService.getCoordinatesFromAddress(specialAddress)).thenReturn("45.8131,15.9775");
        when(locationRepository.save(any(Location.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Location result = locationService.addLocation(specialAddress);

        assertThat(result).isNotNull();
        assertThat(result.getAddress()).isEqualTo(specialAddress);
        assertThat(result.getGeoLocation()).isEqualTo("45.8131,15.9775");
    }

    @Test
    void addLocation_VeryLongAddress_ReturnsLocation() {
        String longAddress = "A".repeat(500);
        when(geocodingService.getCoordinatesFromAddress(longAddress)).thenReturn("45.8150,15.9819");
        when(locationRepository.save(any(Location.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Location result = locationService.addLocation(longAddress);

        assertThat(result).isNotNull();
        assertThat(result.getAddress()).isEqualTo(longAddress);
    }

    @Test
    void findByAddress_ExistingAddress_ReturnsLocation() {
        when(locationRepository.save(any(Location.class))).thenReturn(testLocation);
        when(locationRepository.findFirstByAddress("Zagreb, Croatia")).thenReturn(Optional.of(testLocation));

        Optional<Location> result = locationService.findByAddress("Zagreb, Croatia");

        assertThat(result).isPresent();
        assertThat(result.get().getAddress()).isEqualTo("Zagreb, Croatia");
    }

    @Test
    void findByAddress_NonExistingAddress_ReturnsEmpty() {
        when(locationRepository.findFirstByAddress("Unknown Address")).thenReturn(Optional.empty());

        Optional<Location> result = locationService.findByAddress("Unknown Address");

        assertThat(result).isEmpty();
    }

    @Test
    void findByAddress_NullAddress_ReturnsEmpty() {
        Optional<Location> result = locationService.findByAddress(null);

        assertThat(result).isEmpty();
    }

    @Test
    void findByAddress_CaseSensitivity_CallsRepository() {
        when(locationRepository.findFirstByAddress("ZAGREB, CROATIA")).thenReturn(Optional.empty());

        Optional<Location> result = locationService.findByAddress("ZAGREB, CROATIA");

        assertThat(result).isEmpty();
    }
}
