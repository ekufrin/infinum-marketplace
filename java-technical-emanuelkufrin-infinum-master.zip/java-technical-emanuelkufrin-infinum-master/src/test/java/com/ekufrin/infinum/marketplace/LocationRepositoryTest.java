package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.repository.LocationRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
class LocationRepositoryTest {
    @Autowired
    private LocationRepository locationRepository;

    @Test
    void findByAddress_ShouldReturnEmpty_WhenLocationFound() {
        var location = locationRepository.findByAddress("Nonexistent Address");
        assertThat(location).isEmpty();
    }

    @Test
    void findByAddress_ShouldReturnContactInfo_WhenLocationFound() {
        var contactInfo = locationRepository.findByAddress("Vukovarska 23, 51000 Rijeka");
        assertThat(contactInfo).isPresent();
        assertThat(contactInfo.get().getAddress()).isEqualTo("Vukovarska 23, 51000 Rijeka");
    }
}
