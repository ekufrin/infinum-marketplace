package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.dto.UserLoginRequest;
import com.ekufrin.infinum.marketplace.dto.UserRegisterRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.transaction.Transactional;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
class AuthControllerIntegrationTest {
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private Flyway flyway;
    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        flyway.clean();
        flyway.migrate();
    }

    @Test
    void registerUser_ValidUserRegisterRequestGiven_ShouldReturnJWTResponse() throws Exception {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest("Ivano Balić",
                "ivano.balic123@gmail.com", "SecureP@ssword1");
        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(userRegisterRequest)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.token").isNotEmpty())
                .andExpect(jsonPath("$.tokenType").value("Bearer"))
                .andExpect(jsonPath("$.expiresIn").value(3600L));
    }

    @Test
    void registerUser_EmailAlreadyExists_ShouldReturnConflict() throws Exception {
        UserRegisterRequest firstRequest = new UserRegisterRequest(
                "Ivano Balić",
                "ivano.balic@gmail.com",
                "SecureP@ssword1");

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(firstRequest)))
                .andExpect(status().isCreated());

        UserRegisterRequest duplicateRequest = new UserRegisterRequest(
                "Marko Marić",
                "ivano.balic@gmail.com",
                "AnotherP@ssword2");

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(duplicateRequest)))
                .andExpect(status().isConflict());
    }

    @Test
    void loginUser_ValidUserLoginRequestGiven_ShouldReturnJWTResponse() throws Exception {
        UserLoginRequest userLoginRequest = new UserLoginRequest("ivana.babic@example.com", "test123456");
        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(userLoginRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").isNotEmpty())
                .andExpect(jsonPath("$.tokenType").value("Bearer"))
                .andExpect(jsonPath("$.expiresIn").isNumber());
    }

    @Test
    void loginUser_InvalidUserLoginRequestGiven_ShouldReturn401Unauthorized() throws Exception {
        UserLoginRequest userLoginRequest = new UserLoginRequest("ivana.babic@example.com", "test123");
        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(userLoginRequest)))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("Invalid credentials"));
    }

}
