package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.dto.CategoryChangeRequest;
import com.ekufrin.infinum.marketplace.dto.CategoryCreateRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.transaction.Transactional;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.UUID;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
@WithMockUser(username = "admin", roles = {"ADMIN"})
class CategoryControllerIntegrationTest {
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private Flyway flyway;

    @BeforeEach
    void setUp() {
        flyway.clean();
        flyway.migrate();
    }

    @Test
    void addCategory_ValidArgumentGiven_ShouldAddCategory() throws Exception {
        CategoryCreateRequest request = new CategoryCreateRequest("Mobile devices", true);

        mockMvc.perform(post("/categories")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.name").value("Mobile devices"))
                .andExpect(jsonPath("$.active").value(true));
    }

    @Test
    void addCategory_InvalidArgumentGiven_ShouldReturnBadRequest() throws Exception {
        CategoryCreateRequest request = new CategoryCreateRequest(null, true);

        mockMvc.perform(post("/categories")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void addCategory_DuplicateNameGiven_ShouldReturnConflict() throws Exception {
        CategoryCreateRequest request = new CategoryCreateRequest("Books", true);

        mockMvc.perform(post("/categories")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isConflict());
    }

    @Test
    void getAllCategories_ShouldReturnListOfCategories() throws Exception {
        mockMvc.perform(get("/categories")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content.length()").value(6))
                .andExpect(jsonPath("$.content[0].name").value("Electronics"))
                .andExpect(jsonPath("$.content[1].name").value("Books"))
                .andExpect(jsonPath("$.content[2].active").value("false"));
    }

    @Test
    void getAllCategories_WithPageSizeTwo_ShouldReturnTwoCategoriesPaginated() throws Exception {
        mockMvc.perform(get("/categories?page=0&size=2")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content.length()").value(2))
                .andExpect(jsonPath("$.totalElements").value(6))
                .andExpect(jsonPath("$.totalPages").value(3))
                .andExpect(jsonPath("$.content[0].name").value("Electronics"))
                .andExpect(jsonPath("$.content[1].name").value("Books"));
    }

    @Test
    void getAllCategories_WithSearchParam_ShouldReturnFilteredCategories() throws Exception {
        mockMvc.perform(get("/categories")
                        .param("search", "Electro")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content.length()").value(1))
                .andExpect(jsonPath("$.content[0].name").value("Electronics"));
    }

    @Test
    void getAllCategories_WithStatusParam_ShouldReturnFilteredCategories() throws Exception {
        mockMvc.perform(get("/categories")
                        .param("active", "true")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content.length()").value(4))
                .andExpect(jsonPath("$.content[0].active").value(true))
                .andExpect(jsonPath("$.content[1].active").value(true));
    }


    @Test
    void updateCategoryName_ValidArgumentGiven_ShouldUpdateCategory() throws Exception {
        CategoryChangeRequest request = new CategoryChangeRequest("New Category Name", null);
        UUID id = UUID.fromString("11111111-1111-1111-1111-111111111111");

        mockMvc.perform(patch("/categories/{id}", id)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value(request.name()));
    }

    @Test
    void updateCategory_InvalidArgumentGiven_ShouldReturnBadRequest() throws Exception {
        CategoryChangeRequest request = new CategoryChangeRequest("", null);
        UUID id = UUID.fromString("11111111-1111-1111-1111-111111111111");

        mockMvc.perform(patch("/categories/{id}", id)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Name is required"));
    }

    @Test
    void updateCategoryName_DuplicateGiven_ShouldReturnConflict() throws Exception {
        CategoryChangeRequest request = new CategoryChangeRequest("Books", null);
        UUID id = UUID.fromString("44444444-4444-4444-4444-444444444444");

        mockMvc.perform(patch("/categories/{id}", id)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.message").value("Books already exists."));
    }

    @Test
    void updateCategoryStatus_ValidArgumentGiven_ShouldUpdateCategoryStatus() throws Exception {
        UUID id = UUID.fromString("22222222-2222-2222-2222-222222222222");
        CategoryChangeRequest request = new CategoryChangeRequest(null, true);
        mockMvc.perform(patch("/categories/{id}", id)
                        .content(objectMapper.writeValueAsString(request))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.active").value(true));
    }

    @Test
    void updateCategoryStatus_InvalidArgumentGiven_ShouldReturnOk() throws Exception {
        UUID id = UUID.fromString("22222222-2222-2222-2222-222222222222");
        CategoryChangeRequest request = new CategoryChangeRequest(null, null);
        mockMvc.perform(patch("/categories/{id}", id)
                        .content(objectMapper.writeValueAsString(request))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void updateCategoryStatus_NonExistentIdGiven_ShouldReturnNotFound() throws Exception {
        UUID id = UUID.fromString("99999999-9999-9999-9999-999999999999");
        CategoryChangeRequest request = new CategoryChangeRequest(null, true);
        mockMvc.perform(patch("/categories/{id}", id)
                        .content(objectMapper.writeValueAsString(request))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Category not found"));
    }
}
