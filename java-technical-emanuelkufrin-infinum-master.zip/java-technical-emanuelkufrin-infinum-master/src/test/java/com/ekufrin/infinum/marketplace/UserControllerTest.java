package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.controller.UserController;
import com.ekufrin.infinum.marketplace.dto.ContactInfoRequest;
import com.ekufrin.infinum.marketplace.dto.ContactInfoResponse;
import com.ekufrin.infinum.marketplace.dto.PagedResponse;
import com.ekufrin.infinum.marketplace.dto.UserDTO;
import com.ekufrin.infinum.marketplace.dto.UserPasswordChange;
import com.ekufrin.infinum.marketplace.enums.Role;
import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.service.UserService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.Instant;
import java.util.List;
import java.util.UUID;
import java.util.stream.IntStream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserControllerTest {
    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    @Test
    void changeUserPassword_ValidRequest_ReturnsNoContent() {
        String username = "testuser";
        UserDetails userDetails = org.springframework.security.core.userdetails.User
                .withUsername(username)
                .password("password")
                .roles("USER")
                .build();
        UserPasswordChange passwordChange = new UserPasswordChange("oldPass", "newPass");
        User user = new User.Builder().name("Test User").email("test.user@xyz.com").build();
        when(userService.changeUserPassword(username, passwordChange)).thenReturn(user);

        ResponseEntity<Void> response = userController.changeUserPassword(passwordChange, userDetails);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NO_CONTENT);
    }

    @Test
    void changeUserPassword_InvalidToken_ThrowsException() {
        UserPasswordChange passwordChange = new UserPasswordChange("oldPass", "newPass");
        UserDetails userDetails = null;

        assertThatThrownBy(() ->
                userController.changeUserPassword(passwordChange, userDetails)).isInstanceOf(NullPointerException.class);
    }

    @Test
    void changeUserPassword_NullAuthorizationHeader_ThrowsNullPointerException() {
        UserPasswordChange passwordChange = new UserPasswordChange("oldPass", "newPass");

        assertThatThrownBy(() -> userController.changeUserPassword(passwordChange, null))
                .isInstanceOf(NullPointerException.class);
    }

    @Test
    void changeUserPassword_WrongPassword_ThrowsException() {
        String username = "testuser";
        UserDetails userDetails = org.springframework.security.core.userdetails.User
                .withUsername(username)
                .password("password")
                .roles("USER")
                .build();
        UserPasswordChange passwordChange = new UserPasswordChange("wrongOldPass", "newPass");

        when(userService.changeUserPassword(username, passwordChange))
                .thenThrow(new IllegalArgumentException("Wrong password"));

        assertThatThrownBy(() -> userController.changeUserPassword(passwordChange, userDetails))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Wrong password");
    }

    @Test
    void getAllUsers_PageZero_ReturnsFirstPageWithData() {
        Pageable pageable = PageRequest.of(0, 20);

        UserDTO user1 = mock(UserDTO.class);
        UserDTO user2 = mock(UserDTO.class);
        Page<UserDTO> mockPage = new PageImpl<>(List.of(user1, user2), pageable, 2);

        when(userService.getAllUsersAsPageWithFilterAndSorting(null, null, pageable))
                .thenReturn(mockPage);

        ResponseEntity<?> response = userController.getAllUsers(null, null, pageable);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isInstanceOf(PagedResponse.class);

        PagedResponse<UserDTO> resultPage = (PagedResponse<UserDTO>) response.getBody();
        Assertions.assertNotNull(resultPage);
        assertThat(resultPage.content()).hasSize(2);
        assertThat(resultPage.totalPages()).isEqualTo(1);
    }


    @Test
    void getAllUsers_SizeExceedsMax_CapsToMaxAndReturnsData() {
        Pageable pageable = PageRequest.of(0, 100);

        List<UserDTO> users = IntStream.range(0, 100)
                .mapToObj(i -> {
                    return mock(UserDTO.class);
                })
                .toList();
        Page<UserDTO> mockPage = new PageImpl<>(users, pageable, 100);

        when(userService.getAllUsersAsPageWithFilterAndSorting(null, null, pageable))
                .thenReturn(mockPage);

        ResponseEntity<?> response = userController.getAllUsers(null, null, pageable);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isInstanceOf(PagedResponse.class);

        PagedResponse<UserDTO> pagedResponse = (PagedResponse<UserDTO>) response.getBody();
        Assertions.assertNotNull(pagedResponse);
        assertThat(pagedResponse.content()).hasSize(100);
        assertThat(pagedResponse.totalPages()).isLessThanOrEqualTo(100);
    }

    @Test
    void getAllUsers_InvalidSortParam_HandlesGracefullyWithDefaultSort() {
        Pageable pageable = PageRequest.of(0, 20, Sort.by("invalid").descending());

        UserDTO user = mock(UserDTO.class);

        Page<UserDTO> mockPage = new PageImpl<>(List.of(user), pageable, 1);

        when(userService.getAllUsersAsPageWithFilterAndSorting(null, null, pageable))
                .thenReturn(mockPage);

        ResponseEntity<?> response = userController.getAllUsers(null, null, pageable);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isInstanceOf(PagedResponse.class);

        PagedResponse<?> resultPage = (PagedResponse<?>) response.getBody();
        Assertions.assertNotNull(resultPage);
        assertThat(resultPage.content()).hasSize(1);
    }

    @Test
    void getAllUsers_WithSearchFilter_ReturnsFilteredResults() {
        Pageable pageable = PageRequest.of(0, 20);
        String search = "john";

        UserDTO user = mock(UserDTO.class);

        Page<UserDTO> mockPage = new PageImpl<>(List.of(user), pageable, 1);

        when(userService.getAllUsersAsPageWithFilterAndSorting(search, null, pageable))
                .thenReturn(mockPage);

        ResponseEntity<?> response = userController.getAllUsers(search, null, pageable);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isInstanceOf(PagedResponse.class);

        PagedResponse<?> resultPage = (PagedResponse<?>) response.getBody();
        Assertions.assertNotNull(resultPage);
        assertThat(resultPage.content()).hasSize(1);
    }


    @Test
    void getAllUsers_WithStatusTrue_ReturnsActiveUsersOnly() {
        Pageable pageable = PageRequest.of(0, 20);

        UserDTO activeUser = mock(UserDTO.class);

        Page<UserDTO> mockPage = new PageImpl<>(List.of(activeUser), pageable, 1);

        when(userService.getAllUsersAsPageWithFilterAndSorting(null, true, pageable))
                .thenReturn(mockPage);

        ResponseEntity<?> response = userController.getAllUsers(null, true, pageable);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isInstanceOf(PagedResponse.class);

        PagedResponse<?> resultPage = (PagedResponse<?>) response.getBody();
        Assertions.assertNotNull(resultPage);
        assertThat(resultPage.content()).hasSize(1);
    }

    @Test
    void getAllUsers_WithStatusFalse_ReturnsInactiveUsersOnly() {
        Pageable pageable = PageRequest.of(0, 20);

        UserDTO inactiveUser = mock(UserDTO.class);

        Page<UserDTO> mockPage = new PageImpl<>(List.of(inactiveUser), pageable, 1);

        when(userService.getAllUsersAsPageWithFilterAndSorting(null, false, pageable))
                .thenReturn(mockPage);

        ResponseEntity<?> response = userController.getAllUsers(null, false, pageable);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isInstanceOf(PagedResponse.class);

        PagedResponse<?> resultPage = (PagedResponse<?>) response.getBody();
        Assertions.assertNotNull(resultPage);
        assertThat(resultPage.content()).hasSize(1);
    }

    @Test
    void getAllUsers_EmptyResult_ReturnsEmptyPage() {
        Pageable pageable = PageRequest.of(0, 20);

        when(userService.getAllUsersAsPageWithFilterAndSorting("nonexistent", null, pageable))
                .thenReturn(Page.empty());

        ResponseEntity<?> response = userController.getAllUsers("nonexistent", null, pageable);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isInstanceOf(PagedResponse.class);

        PagedResponse<?> resultPage = (PagedResponse<?>) response.getBody();
        Assertions.assertNotNull(resultPage);
        assertThat(resultPage.content()).isEmpty();
        assertThat(resultPage.totalElements()).isZero();
    }

    @Test
    void getCurrentUserDetails_ValidUser_ReturnsUserDTO() {
        String username = "testuser";
        UserDetails userDetails = org.springframework.security.core.userdetails.User
                .withUsername(username)
                .password("password")
                .roles("USER")
                .build();
        UserDTO userDTO = new UserDTO(
                java.util.UUID.randomUUID(),
                "Test User",
                "testuser",
                "test.user@example.com",
                Role.USER,
                true,
                Instant.now());

        when(userService.getUserById(userDetails.getUsername())).thenReturn(userDTO);

        ResponseEntity<UserDTO> response = userController.getCurrentUserDetails(userDetails);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isEqualTo(userDTO);
    }

    @Test
    void getCurrentUserDetails_UserNotFound_ThrowsException() {
        String username = "nonexistentuser@test.com";
        UserDetails userDetails = org.springframework.security.core.userdetails.User
                .withUsername(username)
                .password("password")
                .roles("USER")
                .build();

        when(userService.getUserById(username)).thenThrow(new DBException("User not found"));

        assertThatThrownBy(() -> userController.getCurrentUserDetails(userDetails))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("User not found");
    }

    @Test
    void createContactInfo_ValidRequest_ReturnsCreated() {
        String username = "testuser";
        UserDetails userDetails = org.springframework.security.core.userdetails.User
                .withUsername(username)
                .password("password")
                .roles("USER")
                .build();

        ContactInfoRequest request = new ContactInfoRequest("test@example.com", "+1234567890");
        ContactInfoResponse response = new ContactInfoResponse(UUID.randomUUID(), "test@example.com", "+1234567890");

        when(userService.createContactInfo(request, userDetails)).thenReturn(response);

        ResponseEntity<ContactInfoResponse> result = userController.createContactInfo(request, userDetails);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(result.getBody()).isEqualTo(response);
    }

    @Test
    void createContactInfo_MissingEmail_ReturnsCreated() {
        String username = "testuser";
        UserDetails userDetails = org.springframework.security.core.userdetails.User
                .withUsername(username)
                .password("password")
                .roles("USER")
                .build();

        ContactInfoRequest request = new ContactInfoRequest(null, "+1234567890");
        ContactInfoResponse response = new ContactInfoResponse(UUID.randomUUID(), null, "+1234567890");

        when(userService.createContactInfo(request, userDetails)).thenReturn(response);

        ResponseEntity<ContactInfoResponse> result = userController.createContactInfo(request, userDetails);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(result.getBody()).isEqualTo(response);
    }

    @Test
    void createContactInfo_InvalidEmailFormat_ThrowsBadRequest() {
        String username = "testuser";
        UserDetails userDetails = org.springframework.security.core.userdetails.User
                .withUsername(username)
                .password("password")
                .roles("USER")
                .build();

        ContactInfoRequest request = new ContactInfoRequest("invalid-email", "+1234567890");

        when(userService.createContactInfo(request, userDetails))
                .thenThrow(new IllegalArgumentException("Invalid email"));

        assertThatThrownBy(() -> userController.createContactInfo(request, userDetails))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Invalid email");
    }

    @Test
    void createContactInfo_MissingPhoneNumber_ReturnsCreated() {
        String username = "testuser";
        UserDetails userDetails = org.springframework.security.core.userdetails.User
                .withUsername(username)
                .password("password")
                .roles("USER")
                .build();

        ContactInfoRequest request = new ContactInfoRequest("test@example.com", null);
        ContactInfoResponse response = new ContactInfoResponse(UUID.randomUUID(), "test@example.com", null);

        when(userService.createContactInfo(request, userDetails)).thenReturn(response);

        ResponseEntity<ContactInfoResponse> result = userController.createContactInfo(request, userDetails);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(result.getBody()).isEqualTo(response);
    }

    @Test
    void createContactInfo_EmptyPhoneNumber_ThrowsBadRequest() {
        String username = "testuser";
        UserDetails userDetails = org.springframework.security.core.userdetails.User
                .withUsername(username)
                .password("password")
                .roles("USER")
                .build();

        ContactInfoRequest request = new ContactInfoRequest("test@example.com", "");

        when(userService.createContactInfo(request, userDetails))
                .thenThrow(new IllegalArgumentException("Phone number cannot be empty"));

        assertThatThrownBy(() -> userController.createContactInfo(request, userDetails))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Phone number cannot be empty");
    }

    @Test
    void getContactInfos_ValidUserId_ReturnsContactInfos() {
        UUID userId = UUID.randomUUID();
        Pageable pageable = PageRequest.of(0, 20);

        ContactInfoResponse contactInfo1 = new ContactInfoResponse(UUID.randomUUID(), "test.user@example.com", "+1234567890");
        ContactInfoResponse contactInfo2 = new ContactInfoResponse(UUID.randomUUID(), "test.user2@example.com", null);
        Page<ContactInfoResponse> mockPage = new PageImpl<>(List.of(contactInfo1, contactInfo2), pageable, 2);

        when(userService.getAllContactInfoForUser(userId, pageable))
                .thenReturn(mockPage);

        ResponseEntity<PagedResponse<ContactInfoResponse>> response = userController.getContactInfos(userId, pageable);
        Assertions.assertNotNull(response.getBody());
        assertThat(response.getBody().totalElements()).isEqualTo(2);
        assertThat(response.getBody().content().getFirst()).isEqualTo(contactInfo1);
    }

    @Test
    void getContactInfos_NoContactInfos_ReturnsEmptyPage() {
        UUID userId = UUID.randomUUID();
        Pageable pageable = PageRequest.of(0, 20);

        Page<ContactInfoResponse> mockPage = Page.empty(pageable);

        when(userService.getAllContactInfoForUser(userId, pageable))
                .thenReturn(mockPage);

        ResponseEntity<PagedResponse<ContactInfoResponse>> response = userController.getContactInfos(userId, pageable);
        Assertions.assertNotNull(response.getBody());
        assertThat(response.getBody().totalElements()).isZero();
        assertThat(response.getBody().content()).isEmpty();
    }

    @Test
    void getContactInfosForCurrentUser_ValidUser_ReturnsContactInfos() {
        String username = UUID.randomUUID().toString();
        UserDetails userDetails = org.springframework.security.core.userdetails.User
                .withUsername(username)
                .password("password")
                .roles("USER")
                .build();
        Pageable pageable = PageRequest.of(0, 20);

        ContactInfoResponse contactInfo1 = new ContactInfoResponse(UUID.randomUUID(), "test.user@example.com", "+1234567890");
        ContactInfoResponse contactInfo2 = new ContactInfoResponse(UUID.randomUUID(), "test.user@example.com", null);
        Page<ContactInfoResponse> mockPage = new PageImpl<>(List.of(contactInfo1, contactInfo2), pageable, 2);
        when(userService.getAllContactInfoForUser(UUID.fromString(userDetails.getUsername()), pageable))
                .thenReturn(mockPage);
        ResponseEntity<PagedResponse<ContactInfoResponse>> response = userController.getContactInfosForCurrentUser(userDetails, pageable);
        Assertions.assertNotNull(response.getBody());
        assertThat(response.getBody().totalElements()).isEqualTo(2);
        assertThat(response.getBody().content().getFirst()).isEqualTo(contactInfo1);
    }

    @Test
    void getContactInfosForCurrentUser_NoContactInfos_ReturnsEmptyPage() {
        String username = UUID.randomUUID().toString();
        UserDetails userDetails = org.springframework.security.core.userdetails.User
                .withUsername(username)
                .password("password")
                .roles("USER")
                .build();
        Pageable pageable = PageRequest.of(0, 20);

        Page<ContactInfoResponse> mockPage = Page.empty(pageable);

        when(userService.getAllContactInfoForUser(UUID.fromString(userDetails.getUsername()), pageable))
                .thenReturn(mockPage);

        ResponseEntity<PagedResponse<ContactInfoResponse>> response = userController.getContactInfosForCurrentUser(userDetails, pageable);
        Assertions.assertNotNull(response.getBody());
        assertThat(response.getBody().totalElements()).isZero();
        assertThat(response.getBody().content()).isEmpty();
    }
}
