package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.controller.AuthController;
import com.ekufrin.infinum.marketplace.dto.UserLoginRequest;
import com.ekufrin.infinum.marketplace.dto.UserRegisterRequest;
import com.ekufrin.infinum.marketplace.enums.Role;
import com.ekufrin.infinum.marketplace.exception.AlreadyExistsInDB;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.service.AuthService;
import com.ekufrin.infinum.marketplace.service.JWTService;
import com.ekufrin.infinum.marketplace.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Optional;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = AuthController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
class AuthControllerTest {
    private final ObjectMapper objectMapper = new ObjectMapper();
    @Autowired
    private MockMvc mockMvc;
    @MockitoBean
    private UserService userService;
    @MockitoBean
    private JWTService jwtService;
    @MockitoBean
    private AuthService authService;
    @MockitoBean
    private UserDetailsService userDetailsService;

    @Test
    void registerUser_ValidUserRegisterRequestGiven_ShouldReturnJWTResponse() throws Exception {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Ivano Balić",
                "ivano.balic@gmail.com",
                "SecureP@ssword1");

        User expectedUser = new User.Builder()
                .name(userRegisterRequest.name())
                .email(userRegisterRequest.email())
                .password(userRegisterRequest.password())
                .isActive(true)
                .role(Role.USER)
                .build();

        when(userService.addUser(userRegisterRequest)).thenReturn(expectedUser);

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(userRegisterRequest)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.tokenType").value("Bearer"));
    }

    @Test
    void registerUser_DuplicateEmailGiven_ShouldReturnConflict() throws Exception {
        UserRegisterRequest duplicateEmailRequest = new UserRegisterRequest(
                "Marko Marić",
                "ivano.balic@gmail.com",
                "AnotherP@ssword2");

        when(userService.addUser(duplicateEmailRequest))
                .thenThrow(new AlreadyExistsInDB(duplicateEmailRequest.email()));

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(duplicateEmailRequest)))
                .andExpect(status().isConflict());
    }


    @Test
    void registerUser_InvalidEmailGiven_ShouldReturnBadRequest() throws Exception {
        UserRegisterRequest invalidEmailRequest = new UserRegisterRequest(
                "Ivano Balić",
                "invalid-email",
                "SecureP@ssword1");

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalidEmailRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void registerUser_EmptyNameGiven_ShouldReturnBadRequest() throws Exception {
        UserRegisterRequest emptyNameRequest = new UserRegisterRequest(
                "",
                "ivano.balic@gmail.com",
                "SecureP@ssword1");

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(emptyNameRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void registerUser_NullNameGiven_ShouldReturnBadRequest() throws Exception {
        UserRegisterRequest nullNameRequest = new UserRegisterRequest(
                null,
                "ivano.balic@gmail.com",
                "SecureP@ssword1");

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(nullNameRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void registerUser_WeakPasswordGiven_ShouldReturnBadRequest() throws Exception {
        UserRegisterRequest weakPasswordRequest = new UserRegisterRequest(
                "Ivano Balić",
                "ivano.balic@gmail.com",
                "weak");

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(weakPasswordRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void registerUser_EmptyPasswordGiven_ShouldReturnBadRequest() throws Exception {
        UserRegisterRequest emptyPasswordRequest = new UserRegisterRequest(
                "Ivano Balić",
                "ivano.balic@gmail.com",
                "");

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(emptyPasswordRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void registerUser_AllFieldsNullGiven_ShouldReturnBadRequest() throws Exception {
        UserRegisterRequest allNullRequest = new UserRegisterRequest(null, null, null);

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(allNullRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void loginUser_ValidUserLoginRequestGiven_ShouldReturnJWTResponse() throws Exception {
        UserLoginRequest userLoginRequest = new UserLoginRequest("mirko.mirkic@gmail.com", "fakePassword123");
        User expectedUser = new User.Builder()
                .name("Mirko Mirkic")
                .email(userLoginRequest.email())
                .password(userLoginRequest.password())
                .isActive(true)
                .role(Role.USER)
                .build();

        when(authService.authenticate(userLoginRequest)).thenReturn(Optional.of(expectedUser));

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(userLoginRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.tokenType").value("Bearer"))
                .andExpect(jsonPath("$.expiresIn").isNumber());
    }

    @Test
    void loginUser_InvalidCredentials_ShouldReturnUnauthorized() throws Exception {
        UserLoginRequest invalidRequest = new UserLoginRequest("user@example.com", "wrongPassword");

        when(authService.authenticate(invalidRequest)).thenReturn(Optional.empty());

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalidRequest)))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void loginUser_NonExistentEmail_ShouldReturnUnauthorized() throws Exception {
        UserLoginRequest nonExistentRequest = new UserLoginRequest("nonexistent@example.com", "anyPassword");

        when(authService.authenticate(nonExistentRequest)).thenReturn(Optional.empty());

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(nonExistentRequest)))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void loginUser_EmptyEmail_ShouldReturnBadRequest() throws Exception {
        UserLoginRequest emptyEmailRequest = new UserLoginRequest("", "password123");

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(emptyEmailRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void loginUser_NullEmail_ShouldReturnBadRequest() throws Exception {
        UserLoginRequest nullEmailRequest = new UserLoginRequest(null, "password123");

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(nullEmailRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void loginUser_EmptyPassword_ShouldReturnBadRequest() throws Exception {
        UserLoginRequest emptyPasswordRequest = new UserLoginRequest("user@example.com", "");

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(emptyPasswordRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void loginUser_NullPassword_ShouldReturnBadRequest() throws Exception {
        UserLoginRequest nullPasswordRequest = new UserLoginRequest("user@example.com", null);

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(nullPasswordRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void loginUser_InvalidEmailFormat_ShouldReturnBadRequest() throws Exception {
        UserLoginRequest invalidEmailFormatRequest = new UserLoginRequest("not-an-email", "password123");

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalidEmailFormatRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void loginUser_AllFieldsNull_ShouldReturnBadRequest() throws Exception {
        UserLoginRequest allNullRequest = new UserLoginRequest(null, null);

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(allNullRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void loginUser_WhitespacePassword_ShouldReturnBadRequest() throws Exception {
        UserLoginRequest whitespacePasswordRequest = new UserLoginRequest("user@example.com", "   ");

        when(authService.authenticate(whitespacePasswordRequest)).thenReturn(Optional.empty());

        mockMvc.perform(MockMvcRequestBuilders.post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(whitespacePasswordRequest)))
                .andExpect(status().isBadRequest());
    }


}
