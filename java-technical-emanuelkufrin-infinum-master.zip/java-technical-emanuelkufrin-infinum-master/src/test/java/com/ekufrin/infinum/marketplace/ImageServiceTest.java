package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.dto.ImageResponse;
import com.ekufrin.infinum.marketplace.exception.UploadException;
import com.ekufrin.infinum.marketplace.repository.ImageRepository;
import com.ekufrin.infinum.marketplace.service.ImageService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ImageServiceTest {
    @InjectMocks
    private ImageService imageService;
    @Mock
    private ImageRepository imageRepository;

    @Test
    void uploadImages_ShouldThrowException_WhenMoreThanFiveFiles() {
        List<MultipartFile> files = new ArrayList<>();
        for (int i = 0; i < 6; i++) {
            files.add(new MockMultipartFile("file" + i, new byte[1024]));
        }
        try {
            imageService.uploadImages(files);
        } catch (UploadException ex) {
            assertThat(ex.getMessage()).isEqualTo("Cannot upload more than 5 files at once");
        }
    }

    @Test
    void uploadImages_ShouldThrowException_WhenFileTooLarge() {
        List<MultipartFile> files = List.of(
                new MockMultipartFile("file", "large_image.jpg", "image/jpeg", new byte[6 * 1024 * 1024])
        );
        try {
            imageService.uploadImages(files);
        } catch (UploadException ex) {
            assertThat(ex.getMessage()).isEqualTo("File size exceeds the maximum limit of 5MB");
        }
    }

    @Test
    void uploadImages_ShouldThrowException_WhenInvalidContentType() {
        List<MultipartFile> files = List.of(
                new MockMultipartFile("file", "document.pdf", "application/pdf", new byte[1024])
        );
        try {
            imageService.uploadImages(files);
        } catch (UploadException ex) {
            assertThat(ex.getMessage()).isEqualTo("Invalid file type. Only JPG and PNG are allowed");
        }
    }

    @Test
    void uploadImages_ShouldUploadSuccessfully_WhenValidFiles() {
        List<MultipartFile> files = List.of(
                new MockMultipartFile("file1", "image1.jpg", "image/jpeg", new byte[1024]),
                new MockMultipartFile("file2", "image2.png", "image/png", new byte[2048])
        );
        when(imageRepository.saveAll(any())).thenAnswer(i -> i.getArguments()[0]);
        List<ImageResponse> responses = imageService.uploadImages(files);
        assertThat(responses).hasSize(2);
        assertThat(responses.get(0).id()).isNotNull();
        assertThat(responses.get(1).id()).isNotNull();
    }


}
