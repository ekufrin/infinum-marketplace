package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.dto.ContactInfoRequest;
import com.ekufrin.infinum.marketplace.dto.UserPasswordChange;
import com.ekufrin.infinum.marketplace.service.JWTService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.test.context.support.WithAnonymousUser;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@WithMockUser(username = "testuser")
@ActiveProfiles("test")
class UserControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private JWTService jwtService;

    @Autowired
    private UserDetailsService userDetailsService;

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111")
    void changeUserPassword_ValidRequestGiven_ReturnsNoContent() throws Exception {
        UserDetails userDetails = userDetailsService.loadUserByUsername("8d5cfe7c-1e1b-4a1e-b8f0-111111111111");
        String token = jwtService.generateToken(userDetails);

        UserPasswordChange passwordChange = new UserPasswordChange("test123456", "newPass456!");

        mockMvc.perform(post("/users/me/change-password")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(passwordChange)))
                .andExpect(status().isNoContent());
    }

    @Test
    @WithAnonymousUser
    void changeUserPassword_MissingAuthorizationHeader_ReturnsUnauthorized() throws Exception {
        UserPasswordChange passwordChange = new UserPasswordChange("oldPass123", "newPass123");

        mockMvc.perform(post("/users/me/change-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(passwordChange)))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void changeUserPassword_InvalidPasswordFormat_ReturnsBadRequest() throws Exception {
        UserDetails userDetails = userDetailsService.loadUserByUsername("luka.papac@example.com");
        String token = jwtService.generateToken(userDetails);
        UserPasswordChange passwordChange = new UserPasswordChange("", "");

        mockMvc.perform(post("/users/me/change-password")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(passwordChange)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void changeUserPassword_InvalidRequestGiven_ReturnsUnauthorized() throws Exception {
        UserDetails userDetails = userDetailsService.loadUserByUsername("luka.papac@example.com");
        String token = jwtService.generateToken(userDetails);
        UserPasswordChange passwordChange = new UserPasswordChange("oldPass123", "newPass123");

        mockMvc.perform(post("/users/me/change-password")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(passwordChange)))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void changeUserPassword_NullRequestBody_ReturnsBadRequest() throws Exception {
        UserDetails userDetails = userDetailsService.loadUserByUsername("luka.papac@example.com");
        String token = jwtService.generateToken(userDetails);

        mockMvc.perform(post("/users/me/change-password")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getAllUsers_DefaultParams_ReturnsOk() throws Exception {
        mockMvc.perform(get("/users"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content", hasSize(greaterThanOrEqualTo(10))))
                .andExpect(jsonPath("$.totalElements").value(10))
                .andExpect(jsonPath("$.totalPages").isNumber())
                .andExpect(jsonPath("$.page").value(1))
                .andExpect(jsonPath("$.size").value(20));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getAllUsers_PageZero_ReturnsFirstPage() throws Exception {
        mockMvc.perform(get("/users?page=0"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content", hasSize(10)))
                .andExpect(jsonPath("$.page").value(1))
                .andExpect(jsonPath("$.content[0].email").value("luka.papac@example.com"))
                .andExpect(jsonPath("$.content[0].username").value("luka.papac"));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getAllUsers_SizeExceedsMax_ReturnsAllUsers() throws Exception {
        mockMvc.perform(get("/users?size=200"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content", hasSize(10)))
                .andExpect(jsonPath("$.totalElements").value(10));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getAllUsers_SortByEmailDesc_ReturnsSortedResults() throws Exception {
        mockMvc.perform(get("/users?sort=email,desc"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content[0].email").value("tomislav.radic@example.com"))
                .andExpect(jsonPath("$.content[9].email").value("ana.horvat@example.com"));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getAllUsers_SearchByName_ReturnsFilteredResults() throws Exception {
        mockMvc.perform(get("/users?search=Ana"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content", hasSize(greaterThanOrEqualTo(1))))
                .andExpect(jsonPath("$.content[0].username").value("ana.horvat"))
                .andExpect(jsonPath("$.content[0].email").value("ana.horvat@example.com"));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getAllUsers_SearchByEmail_ReturnsFilteredResults() throws Exception {
        mockMvc.perform(get("/users?search=ivana.babic"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content", hasSize(1)))
                .andExpect(jsonPath("$.content[0].email").value("ivana.babic@example.com"))
                .andExpect(jsonPath("$.content[0].username").value("ivana.babic"));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getAllUsers_StatusTrue_ReturnsOnlyActiveUsers() throws Exception {
        mockMvc.perform(get("/users?active=true"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content", hasSize(10)))
                .andExpect(jsonPath("$.content[*].isActive", everyItem(is(true))));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getAllUsers_StatusFalse_ReturnsEmptyList() throws Exception {
        mockMvc.perform(get("/users?active=false"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content").isEmpty())
                .andExpect(jsonPath("$.totalElements").value(0));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getAllUsers_SearchWithSpecialChars_ReturnsEmpty() throws Exception {
        mockMvc.perform(get("/users?search=%25%5E%26%2A"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content").isEmpty());
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getAllUsers_PageExceedsTotal_ReturnsEmptyPage() throws Exception {
        mockMvc.perform(get("/users?page=100"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isEmpty())
                .andExpect(jsonPath("$.totalElements").value(10))
                .andExpect(jsonPath("$.page").value(100));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getAllUsers_CombinedFilters_ReturnsFilteredResults() throws Exception {
        mockMvc.perform(get("/users?search=Petar&status=true&sort=email,asc"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content", hasSize(1)))
                .andExpect(jsonPath("$.content[0].email").value("petar.peric@example.com"))
                .andExpect(jsonPath("$.content[0].isActive").value(true));
    }

    @Test
    @WithMockUser(roles = "USER")
    void getAllUsers_UserRole_ReturnsForbidden() throws Exception {
        mockMvc.perform(get("/users"))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithAnonymousUser
    void getAllUsers_AnonymousUser_ReturnsUnauthorized() throws Exception {
        mockMvc.perform(get("/users"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void getCurrentUserDetails_AuthenticatedUser_ReturnsUserDTO() throws Exception {
        String id = "c4c9a87b-3efb-41c8-bbb0-333333333333";

        mockMvc.perform(get("/users/me")
                        .with(user(id)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(id))
                .andExpect(jsonPath("$.name").value("Ivan Ivić"))
                .andExpect(jsonPath("$.role").value("USER"))
                .andExpect(jsonPath("$.isActive").value(true));
    }

    @Test
    @WithAnonymousUser
    void getCurrentUserDetails_AnonymousUser_Unauthorized() throws Exception {
        mockMvc.perform(get("/users/me"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(username = "d8e7f6a5-4321-41ff-8899-aaaaaaaaaaaa", roles = "USER")
    void createContactInfo_ValidRequest_ReturnsCreated() throws Exception {
        ContactInfoRequest request = new ContactInfoRequest("test@example.com", "+1234567890");

        mockMvc.perform(post("/users/contact-info")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.email").value("test@example.com"))
                .andExpect(jsonPath("$.phoneNumber").value("+1234567890"));
    }

    @Test
    @WithMockUser(username = "d8e7f6a5-4321-41ff-8899-aaaaaaaaaaaa", roles = "USER")
    void createContactInfo_MissingEmail_ReturnsCreated() throws Exception {
        ContactInfoRequest request = new ContactInfoRequest(null, "+1234567890");

        mockMvc.perform(post("/users/contact-info")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.phoneNumber").value("+1234567890"));
    }

    @Test
    @WithMockUser(username = "d8e7f6a5-4321-41ff-8899-aaaaaaaaaaaa", roles = "USER")
    void createContactInfo_InvalidEmailFormat_ReturnsBadRequest() throws Exception {
        ContactInfoRequest request = new ContactInfoRequest("invalid-email", "+1234567890");

        mockMvc.perform(post("/users/contact-info")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(username = "d8e7f6a5-4321-41ff-8899-aaaaaaaaaaaa", roles = "USER")
    void createContactInfo_MissingPhoneNumber_ReturnsCreated() throws Exception {
        ContactInfoRequest request = new ContactInfoRequest("test@example.com", null);

        mockMvc.perform(post("/users/contact-info")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.email").value("test@example.com"));
    }

    @Test
    @WithMockUser(username = "d8e7f6a5-4321-41ff-8899-aaaaaaaaaaaa", roles = "USER")
    void createContactInfo_EmptyPhoneNumber_ReturnsBadRequest() throws Exception {
        ContactInfoRequest request = new ContactInfoRequest("test@example.com", "");

        mockMvc.perform(post("/users/contact-info")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithAnonymousUser
    void createContactInfo_Unauthorized_ReturnsUnauthorized() throws Exception {
        ContactInfoRequest request = new ContactInfoRequest("test@example.com", "+1234567890");

        mockMvc.perform(post("/users/contact-info")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(username = "d8e7f6a5-4321-41ff-8899-aaaaaaaaaaaa", roles = "USER")
    void createContactInfo_UserRole_ReturnsCreated() throws Exception {
        ContactInfoRequest request = new ContactInfoRequest("user@example.com", "+9876543210");

        mockMvc.perform(post("/users/contact-info")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.email").value("user@example.com"))
                .andExpect(jsonPath("$.phoneNumber").value("+9876543210"));
    }

    @Test
    @WithMockUser(username = "d8e7f6a5-4321-41ff-8899-aaaaaaaaaaaa", roles = "USER")
    void createContactInfo_ValidRequestWithSpecialCharacters_ReturnsCreated() throws Exception {
        ContactInfoRequest request = new ContactInfoRequest("test+tag@example.com", "+1-234-567-890");

        mockMvc.perform(post("/users/contact-info")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.email").value("test+tag@example.com"))
                .andExpect(jsonPath("$.phoneNumber").value("+1-234-567-890"));
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = "ADMIN")
    void getAllContactInfoForUser_ValidRequest_ReturnsPagedContactInfo() throws Exception {
        String userId = "c9f8e7d6-5432-4d10-bbaa-999999999999";

        mockMvc.perform(get("/users/" + userId + "/contact-info")
                        .param("page", "0")
                        .param("size", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.page").value(1))
                .andExpect(jsonPath("$.size").value(10));
    }

    @Test
    @WithMockUser(roles = "USER")
    void getAllContactInfoForUser_UserRole_ReturnsForbidden() throws Exception {
        String userId = "c9f8e7d6-5432-4d10-bbaa-999999999999";

        mockMvc.perform(get("/users/" + userId + "/contact-info"))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = "ADMIN")
    void getAllContactInfoForUser_NonExistentUser_ReturnsOkWithEmptyContent() throws Exception {
        String userId = "00000000-0000-0000-0000-000000000000";

        mockMvc.perform(get("/users/" + userId + "/contact-info"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content").isEmpty());
    }

    @Test
    @WithMockUser(username = "c4c9a87b-3efb-41c8-bbb0-333333333333", roles = "USER")
    void getContactInfosForCurrentUser_ValidRequest_ReturnsPagedContactInfo() throws Exception {
        mockMvc.perform(get("/users/me/contact-info")
                        .param("page", "0")
                        .param("size", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content[0].email").value("ivan.contact@example.com"))
                .andExpect(jsonPath("$.page").value(1))
                .andExpect(jsonPath("$.size").value(10));
    }

    @Test
    @WithMockUser(username = "c4c9a87b-3efb-41c8-bbb0-888888888888", roles = "USER")
    void getContactInfosForCurrentUser_NoContactInfo_ReturnsOkWithEmptyContent() throws Exception {
        mockMvc.perform(get("/users/me/contact-info"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content").isEmpty());
    }

    @Test
    @WithAnonymousUser
    void getContactInfosForCurrentUser_AnonymousUser_ReturnsUnauthorized() throws Exception {
        mockMvc.perform(get("/users/me/contact-info"))
                .andExpect(status().isUnauthorized());
    }
}