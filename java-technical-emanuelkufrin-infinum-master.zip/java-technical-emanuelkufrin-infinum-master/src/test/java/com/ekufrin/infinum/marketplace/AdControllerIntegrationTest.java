package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.dto.AdCreateRequest;
import com.ekufrin.infinum.marketplace.enums.Condition;
import com.ekufrin.infinum.marketplace.model.Location;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.transaction.Transactional;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.UUID;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
class AdControllerIntegrationTest {
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private Flyway flyway;

    private UUID categoryId;
    private UUID contactInfoId;
    private Location location;

    @BeforeEach
    void setUp() {
        flyway.clean();
        flyway.migrate();

        categoryId = UUID.fromString("11111111-1111-1111-1111-111111111111");
        contactInfoId = UUID.fromString("ccccccc1-cccc-cccc-cccc-cccccccccccc");
        location = new Location(null, "Strojarska cesta 22, 10000 Zagreb", null, null);
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_ValidRequest_ShouldCreateAd() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Laptop for Sale",
                "Brand new laptop in excellent condition",
                categoryId,
                Condition.NEW,
                999.99,
                contactInfoId,
                List.of(UUID.fromString("eeeeeee3-eeee-eeee-eeee-eeeeeeeeeeee")),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.title").value("Laptop for Sale"))
                .andExpect(jsonPath("$.description").value("Brand new laptop in excellent condition"))
                .andExpect(jsonPath("$.price").value(999.99))
                .andExpect(jsonPath("$.condition").value("NEW"))
                .andExpect(jsonPath("$.status").value("ACTIVE"));
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_NullTitle_ShouldReturnBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                null,
                "Description",
                categoryId,
                Condition.NEW,
                100.00,
                contactInfoId,
                List.of(UUID.fromString("eeeeeee3-eeee-eeee-eeee-eeeeeeeeeeee")),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").exists());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_EmptyTitle_ShouldReturnBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "",
                "Description",
                categoryId,
                Condition.NEW,
                100.00,
                contactInfoId,
                List.of(),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_BlankTitle_ShouldReturnBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "   ",
                "Description",
                categoryId,
                Condition.NEW,
                100.00,
                contactInfoId,
                List.of(),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_TitleTooLong_ShouldReturnBadRequest() throws Exception {
        String longTitle = "A".repeat(256);
        AdCreateRequest request = new AdCreateRequest(
                longTitle,
                "Description",
                categoryId,
                Condition.NEW,
                100.00,
                contactInfoId,
                List.of(),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_NullDescription_ShouldReturnBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Title",
                null,
                categoryId,
                Condition.NEW,
                100.00,
                contactInfoId,
                List.of(),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_EmptyDescription_ShouldReturnBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Title",
                "",
                categoryId,
                Condition.NEW,
                100.00,
                contactInfoId,
                List.of(UUID.fromString("eeeeeee3-eeee-eeee-eeee-eeeeeeeeeeee")),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_NegativePrice_ShouldReturnBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Title",
                "Description",
                categoryId,
                Condition.NEW,
                -10.00,
                contactInfoId,
                List.of(),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").exists());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_ZeroPrice_ShouldReturnBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Title",
                "Description",
                categoryId,
                Condition.NEW,
                0.0,
                contactInfoId,
                List.of(),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_NullPrice_ShouldReturnBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Title",
                "Description",
                categoryId,
                Condition.NEW,
                null,
                contactInfoId,
                List.of(),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_VeryLargePrice_ShouldCreateAd() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Expensive Item",
                "Description",
                categoryId,
                Condition.NEW,
                999999999.99,
                contactInfoId,
                List.of(UUID.fromString("eeeeeee3-eeee-eeee-eeee-eeeeeeeeeeee")),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.price").value(999999999.99));
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_InvalidCategoryId_ShouldReturnNotFound() throws Exception {
        UUID invalidCategoryId = UUID.fromString("99999999-9999-9999-9999-999999999999");
        AdCreateRequest request = new AdCreateRequest(
                "Title",
                "Description",
                invalidCategoryId,
                Condition.NEW,
                100.00,
                contactInfoId,
                List.of(UUID.fromString("eeeeeee3-eeee-eeee-eeee-eeeeeeeeeeee")),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Category not found or is deactivated."));
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_NullCategoryId_ShouldReturnBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Title",
                "Description",
                null,
                Condition.NEW,
                100.00,
                contactInfoId,
                List.of(),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_InvalidContactInfoId_ShouldReturnNotFound() throws Exception {
        UUID invalidContactInfoId = UUID.fromString("99999999-9999-9999-9999-999999999999");
        AdCreateRequest request = new AdCreateRequest(
                "Title",
                "Description",
                categoryId,
                Condition.NEW,
                100.00,
                invalidContactInfoId,
                List.of(UUID.fromString("eeeeeee3-eeee-eeee-eeee-eeeeeeeeeeee")),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Contact info not found."));
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_NullContactInfoId_ShouldReturnBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Title",
                "Description",
                categoryId,
                Condition.NEW,
                100.00,
                null,
                List.of(),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_NullCondition_ShouldReturnBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Title",
                "Description",
                categoryId,
                null,
                100.00,
                contactInfoId,
                List.of(),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_WithMultipleImages_ShouldCreateAd() throws Exception {
        List<UUID> imageUrls = List.of(
                UUID.fromString("eeeeeee3-eeee-eeee-eeee-eeeeeeeeeeee"),
                UUID.fromString("eeeeeee4-eeee-eeee-eeee-eeeeeeeeeeee")
        );

        AdCreateRequest request = new AdCreateRequest(
                "Title",
                "Description",
                categoryId,
                Condition.NEW,
                100.00,
                contactInfoId,
                imageUrls,
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.images.length()").value(2));
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_EmptyImagesList_ShouldReturnBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Title",
                "Description",
                categoryId,
                Condition.NEW,
                100.00,
                contactInfoId,
                List.of(),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_NullLocation_ShouldReturnBadRequest() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Title",
                "Description",
                categoryId,
                Condition.NEW,
                100.00,
                contactInfoId,
                List.of(),
                null
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    void createAd_SpecialCharactersInTitle_ShouldCreateAd() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Laptop 💻 šđčćž 100€!",
                "Description",
                categoryId,
                Condition.NEW,
                100.00,
                contactInfoId,
                List.of(UUID.fromString("eeeeeee3-eeee-eeee-eeee-eeeeeeeeeeee")),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.title").value("Laptop 💻 šđčćž 100€!"));
    }

    @Test
    void createAd_WithoutAuthentication_ShouldReturnUnauthorized() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Title",
                "Description",
                categoryId,
                Condition.NEW,
                100.00,
                contactInfoId,
                List.of(),
                location
        );

        mockMvc.perform(post("/ads")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void getAllAds_ShouldReturnAllActiveAds_WhenNoFiltersProvided() throws Exception {
        mockMvc.perform(get("/ads")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(6))
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content[0].title").value("Mountain Bike"));
    }

    @Test
    void getAllAds_ShouldReturnMatchedAd_WhenTitlePartialMatchProvided() throws Exception {
        mockMvc.perform(get("/ads")
                        .param("title", "iphone")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(1))
                .andExpect(jsonPath("$.content[0].title").value("iPhone 13"));
    }

    @Test
    void getAllAds_ShouldReturnEmpty_WhenMinPriceGreaterThanMaxPrice() throws Exception {
        mockMvc.perform(get("/ads")
                        .param("minPrice", "1000")
                        .param("maxPrice", "100")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(0))
                .andExpect(jsonPath("$.content").isArray());
    }

    @Test
    void getAllAds_ShouldFilterByCategoryAndCondition_WhenCategoryAndConditionProvided() throws Exception {
        mockMvc.perform(get("/ads")
                        .param("category", "Electronics")
                        .param("condition", "USED")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(2))
                .andExpect(jsonPath("$.content[0].category").value("Electronics"))
                .andExpect(jsonPath("$.content[0].condition").value("USED"))
                .andExpect(jsonPath("$.content[1].category").value("Electronics"))
                .andExpect(jsonPath("$.content[1].condition").value("USED"));
    }

    @Test
    void getAllAds_ShouldSortByPriceAscendingWithPagination_WhenRequested() throws Exception {
        mockMvc.perform(get("/ads")
                        .param("page", "0")
                        .param("size", "5")
                        .param("sort", "price,asc")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(6))
                .andExpect(jsonPath("$.content[0].price").value(20.0))
                .andExpect(jsonPath("$.content[4].price").value(899.99));
    }

    @Test
    void getAdById_ReturnsAdResponse_WhenAdExists() throws Exception {
        UUID existingAdId = UUID.fromString("ddddddd1-dddd-dddd-dddd-dddddddddddd");

        mockMvc.perform(get("/ads/{id}", existingAdId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("iPhone 13"))
                .andExpect(jsonPath("$.price").value(500.0))
                .andExpect(jsonPath("$.category").value("Electronics"))
                .andExpect(jsonPath("$.condition").value("USED"))
                .andExpect(jsonPath("$.status").value("ACTIVE"))
                .andExpect(jsonPath("$.contactInfo.email").value("contact1@example.com"))
                .andExpect(jsonPath("$.images.length()").value(1))
                .andExpect(jsonPath("$.location.address").value("Ilica 42, 10000 Zagreb"));
    }

    @Test
    void getAdById_ReturnsNotFound_WhenAdMissing() throws Exception {
        UUID missingAdId = UUID.randomUUID();

        mockMvc.perform(get("/ads/{id}", missingAdId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Ad not found."));
    }

    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    @Test
    void editAd_ValidRequest_ShouldUpdateAd() throws Exception {
        AdCreateRequest updateRequest = new AdCreateRequest(
                "Updated Title",
                "Updated Description",
                categoryId,
                Condition.USED,
                249.99,
                contactInfoId,
                List.of(UUID.fromString("eeeeeee3-eeee-eeee-eeee-eeeeeeeeeeee")),
                new Location(null, "Strojarska ulica 22, 10000 Zagreb", null, null)
        );

        mockMvc.perform(put("/ads/{id}", "ddddddd5-dddd-dddd-dddd-dddddddddddd")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updateRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Updated Title"))
                .andExpect(jsonPath("$.description").value("Updated Description"))
                .andExpect(jsonPath("$.price").value(249.99))
                .andExpect(jsonPath("$.condition").value("USED"))
                .andExpect(jsonPath("$.status").value("ACTIVE"))
                .andExpect(jsonPath("$.location.address").value("Strojarska ulica 22, 10000 Zagreb"));
    }

    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    @Test
    void editAd_InvalidAddress_ShouldReturnException() throws Exception {
        AdCreateRequest updateRequest = new AdCreateRequest(
                "Updated Title",
                "Updated Description",
                categoryId,
                Condition.USED,
                249.99,
                contactInfoId,
                List.of(UUID.fromString("eeeeeee3-eeee-eeee-eeee-eeeeeeeeeeee")),
                new Location(null, "Updated Address 1", null, null)
        );

        mockMvc.perform(put("/ads/{id}", "ddddddd5-dddd-dddd-dddd-dddddddddddd")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updateRequest)))
                .andExpect(status().is4xxClientError())
                .andExpect(jsonPath("$.message").value("Could not determine geolocation for the provided address."));
    }

    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    @Test
    void editAd_AdDateExpired_ShouldReturnNotFound() throws Exception {
        AdCreateRequest updateRequest = new AdCreateRequest(
                "Updated Title",
                "Updated Description",
                categoryId,
                Condition.USED,
                249.99,
                contactInfoId,
                List.of(UUID.fromString("eeeeeee3-eeee-eeee-eeee-eeeeeeeeeeee")),
                new Location(null, "Updated Address 1", "45.8000,15.9700", null)
        );

        mockMvc.perform(put("/ads/{id}", "ddddddd4-dddd-dddd-dddd-dddddddddddd")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updateRequest)))
                .andExpect(status().is4xxClientError())
                .andExpect(jsonPath("$.message").value("Ad has expired"));
    }

    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    @Test
    void editAd_InvalidAdId_ShouldReturnNotFound() throws Exception {
        UUID missingAdId = UUID.randomUUID();

        AdCreateRequest request = new AdCreateRequest(
                "Updated Title",
                "Updated Description",
                categoryId,
                Condition.USED,
                200.00,
                contactInfoId,
                List.of(UUID.fromString("eeeeeee3-eeee-eeee-eeee-eeeeeeeeeeee")),
                location
        );

        mockMvc.perform(put("/ads/{id}", missingAdId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Ad not found."));
    }

    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    @Test
    void editAd_NullTitle_ShouldReturnBadRequest() throws Exception {
        AdCreateRequest invalidRequest = new AdCreateRequest(
                null,
                "Updated Description",
                categoryId,
                Condition.USED,
                200.00,
                contactInfoId,
                List.of(UUID.fromString("eeeeeee3-eeee-eeee-eeee-eeeeeeeeeeee")),
                location
        );

        mockMvc.perform(put("/ads/{id}", "ddddddd2-dddd-dddd-dddd-dddddddddddd")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalidRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").exists());
    }

    @Test
    void editAd_WithoutAuthentication_ShouldReturnUnauthorized() throws Exception {
        AdCreateRequest request = new AdCreateRequest(
                "Updated Title",
                "Updated Description",
                categoryId,
                Condition.USED,
                200.00,
                contactInfoId,
                List.of(UUID.fromString("eeeeeee3-eeee-eeee-eeee-eeeeeeeeeeee")),
                location
        );

        mockMvc.perform(put("/ads/{id}", UUID.randomUUID())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isUnauthorized());
    }

    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    @Test
    void renewAd_WithValidTokenAndExistingAd_RenewsAndReturnsSuccessMessage() throws Exception {

        String token = "fffffff1-ffff-ffff-ffff-ffffffffffff";

        mockMvc.perform(get("/ads/renew")
                        .param("token", token)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").value("Ad renewed sucessfully for next 30 days."));
    }

    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    @Test
    void renewAd_WithNonexistentToken_ReturnsBadRequestAndDoesNotChangeAd() throws Exception {

        String invalidToken = UUID.randomUUID().toString();

        mockMvc.perform(get("/ads/renew")
                        .param("token", invalidToken)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Invalid or expired OTT"));
    }

    @WithMockUser(username = "8d5cfe7c-1e1b-4a1e-b8f0-111111111111", roles = {"USER"})
    @Test
    void renewAd_MissingTokenParameter_ReturnsBadRequest() throws Exception {
        mockMvc.perform(get("/ads/renew")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }
}
