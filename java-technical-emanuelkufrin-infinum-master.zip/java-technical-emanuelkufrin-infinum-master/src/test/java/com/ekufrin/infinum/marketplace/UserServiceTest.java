package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.dto.ContactInfoRequest;
import com.ekufrin.infinum.marketplace.dto.ContactInfoResponse;
import com.ekufrin.infinum.marketplace.dto.UserDTO;
import com.ekufrin.infinum.marketplace.dto.UserPasswordChange;
import com.ekufrin.infinum.marketplace.dto.UserRegisterRequest;
import com.ekufrin.infinum.marketplace.enums.Role;
import com.ekufrin.infinum.marketplace.exception.AlreadyExistsInDB;
import com.ekufrin.infinum.marketplace.exception.DBException;
import com.ekufrin.infinum.marketplace.exception.PasswordMismatch;
import com.ekufrin.infinum.marketplace.model.ContactInfo;
import com.ekufrin.infinum.marketplace.model.User;
import com.ekufrin.infinum.marketplace.repository.ContactInfoRepository;
import com.ekufrin.infinum.marketplace.repository.UserRepository;
import com.ekufrin.infinum.marketplace.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    @Mock
    private UserRepository userRepository;
    @Mock
    private ContactInfoRepository contactInfoRepository;
    private UserService userService;


    @BeforeEach
    void setUp() {
        userService = new UserService(userRepository, contactInfoRepository, passwordEncoder);
    }

    @Test
    void addUser_ValidUserRequestGiven_ShouldReturnAddedUser() {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Ivano Balić",
                "ivano.balic@gmail.com",
                "SecureP@ssword1");

        UUID expectedId = UUID.randomUUID();
        User expectedUser = new User.Builder()
                .id(expectedId)
                .name(userRegisterRequest.name())
                .email(userRegisterRequest.email())
                .password(passwordEncoder.encode(userRegisterRequest.password()))
                .isActive(true)
                .role(Role.USER)
                .build();

        when(userRepository.existsByEmailIgnoreCase("ivano.balic@gmail.com")).thenReturn(Boolean.FALSE);
        when(userRepository.save(any(User.class))).thenReturn(expectedUser);

        var user = userService.addUser(userRegisterRequest);

        assertThat(user.getId()).isNotNull();
        assertThat(user.getName()).isEqualTo("Ivano Balić");
        assertThat(user.getEmail()).isEqualTo("ivano.balic@gmail.com");
        assertThat(passwordEncoder.matches(userRegisterRequest.password(), user.getPassword())).isTrue();
    }

    @Test
    void addUser_ValidUserRequestGiven_ShouldReturnEmailAlreadyExists() {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Ivano Balić",
                "ivano.balic@gmail.com",
                "SecureP@ssword1");

        when(userRepository.existsByEmailIgnoreCase("ivano.balic@gmail.com")).thenReturn(Boolean.TRUE);

        try {
            userService.addUser(userRegisterRequest);
        } catch (Exception e) {
            assertThat(e).isInstanceOf(AlreadyExistsInDB.class);
            assertThat(e.getMessage()).isEqualTo("ivano.balic@gmail.com already exists.");
        }
    }

    @Test
    void addUser_EmailWithDifferentCase_ShouldStillCheckForDuplicates() {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Marko Marić",
                "Ivano.Balic@Gmail.com",
                "SecureP@ssword1");

        when(userRepository.existsByEmailIgnoreCase("Ivano.Balic@Gmail.com")).thenReturn(Boolean.TRUE);

        try {
            userService.addUser(userRegisterRequest);
        } catch (Exception e) {
            assertThat(e).isInstanceOf(AlreadyExistsInDB.class);
            assertThat(e.getMessage()).contains("Ivano.Balic@Gmail.com");
        }
    }

    @Test
    void addUser_EmptyEmail_ShouldHandleValidation() {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Ivano Balić",
                "",
                "SecureP@ssword1");

        when(userRepository.existsByEmailIgnoreCase("")).thenReturn(Boolean.FALSE);
        assertThatThrownBy(() -> userService.addUser(userRegisterRequest))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Wrong email format");
    }

    @Test
    void addUser_VeryLongEmail_ShouldHandle() {
        String longEmail = "a".repeat(250) + "@gmail.com";
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Ivano Balić",
                longEmail,
                "SecureP@ssword1");

        when(userRepository.existsByEmailIgnoreCase(longEmail)).thenReturn(Boolean.FALSE);
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        var user = userService.addUser(userRegisterRequest);

        assertThat(user.getEmail()).isEqualTo(longEmail);
    }

    @Test
    void addUser_SpecialCharactersInName_ShouldHandle() {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Ivano-Balić@#$%",
                "ivano.balic@gmail.com",
                "SecureP@ssword1");

        when(userRepository.existsByEmailIgnoreCase("ivano.balic@gmail.com")).thenReturn(Boolean.FALSE);
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        var user = userService.addUser(userRegisterRequest);

        assertThat(user.getName()).isEqualTo("Ivano-Balić@#$%");
    }

    @Test
    void addUser_EmailWithWhitespace_ShouldThrowException() {
        UserRegisterRequest userRegisterRequest = new UserRegisterRequest(
                "Ivano Balić",
                " ivano.balic@gmail.com ",
                "SecureP@ssword1");

        when(userRepository.existsByEmailIgnoreCase(" ivano.balic@gmail.com ")).thenReturn(Boolean.FALSE);

        assertThatThrownBy(() -> userService.addUser(userRegisterRequest))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Wrong email format");
    }

    @Test
    void changeUserPassword_UserNotFound_ShouldThrowException() {
        UUID userId = UUID.randomUUID();
        UserPasswordChange change = new UserPasswordChange("old", "new");
        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        String userIdStr = userId.toString();

        assertThatThrownBy(() -> userService.changeUserPassword(userIdStr, change))
                .isInstanceOf(DBException.class);
    }

    @Test
    void changeUserPassword_OldPasswordIncorrect_ShouldThrowPasswordMismatch() {
        String email = "user@example.com";
        String oldPassword = "wrongOld";
        String currentPassword = passwordEncoder.encode("realOld");
        User user = new User.Builder().id(UUID.randomUUID()).email(email).password(currentPassword).build();
        when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));

        UserPasswordChange change = new UserPasswordChange(oldPassword, "newPassword");

        String userId = user.getId().toString();

        assertThatThrownBy(() -> userService.changeUserPassword(userId, change))
                .isInstanceOf(PasswordMismatch.class)
                .hasMessageContaining("Old password does not match");
    }

    @Test
    void changeUserPassword_NewPasswordSameAsOld_ShouldThrowPasswordMismatch() {
        String email = "user@example.com";
        String oldPassword = "samePassword";
        String currentPassword = passwordEncoder.encode(oldPassword);
        User user = new User.Builder().id(UUID.randomUUID()).email(email).password(currentPassword).build();
        when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));

        UserPasswordChange change = new UserPasswordChange(oldPassword, oldPassword);

        String userId = user.getId().toString();

        assertThatThrownBy(() -> userService.changeUserPassword(userId, change))
                .isInstanceOf(PasswordMismatch.class)
                .hasMessageContaining("New password must be different");
    }

    @Test
    void changeUserPassword_NewPasswordIsNull_ShouldThrowExceptionOrEncodeNull() {
        String email = "user@example.com";
        String oldPassword = "oldPassword";

        UserPasswordChange change = new UserPasswordChange(oldPassword, null);

        assertThatThrownBy(() -> userService.changeUserPassword(email, change))
                .isInstanceOf(Exception.class);
    }

    @Test
    void getAllUsers_PageZero_ShouldReturnEmptyPage() {
        Pageable pageable = PageRequest.of(0, 20);

        when(userRepository.findAllFiltered(isNull(), isNull(), any(Pageable.class)))
                .thenReturn(Page.empty());

        Page<UserDTO> result = userService.getAllUsersAsPageWithFilterAndSorting(null, null, pageable);

        assertThat(result).isEmpty();
        assertThat(result.getTotalElements()).isZero();
        assertThat(result.getContent()).isEmpty();
    }

    @Test
    void getAllUsers_SizeNegative_ShouldDefaultToTwenty_AndReturnEmptyPage() {
        Pageable pageable = PageRequest.of(1, 20);

        when(userRepository.findAllFiltered(isNull(), isNull(), any(Pageable.class)))
                .thenReturn(Page.empty());

        Page<UserDTO> result = userService.getAllUsersAsPageWithFilterAndSorting(null, null, pageable);

        assertThat(result).isEmpty();
    }

    @Test
    void getAllUsers_SizeTooLarge_ShouldCapToHundred_AndReturnEmptyPage() {
        Pageable pageable = PageRequest.of(1, 100);

        when(userRepository.findAllFiltered(isNull(), isNull(), any(Pageable.class)))
                .thenReturn(Page.empty());

        Page<UserDTO> result = userService.getAllUsersAsPageWithFilterAndSorting(null, null, pageable);

        assertThat(result).isEmpty();
    }

    @Test
    void getAllUsers_SortParamNull_ShouldSortByCreatedAtDesc_AndReturnEmptyPage() {
        Pageable pageable = PageRequest.of(1, 20);

        when(userRepository.findAllFiltered(isNull(), isNull(), any(Pageable.class)))
                .thenReturn(Page.empty());

        Page<UserDTO> result = userService.getAllUsersAsPageWithFilterAndSorting(null, null, pageable);

        assertThat(result).isEmpty();
        assertThat(result.getContent()).isEmpty();
    }

    @Test
    void getAllUsers_SortParamInvalidFormat_ShouldSortByPropertyAsc_AndReturnEmptyPage() {
        Pageable pageable = PageRequest.of(1, 20, Sort.by("invalid"));

        when(userRepository.findAllFiltered(isNull(), isNull(), any(Pageable.class)))
                .thenReturn(Page.empty());

        Page<UserDTO> result = userService.getAllUsersAsPageWithFilterAndSorting(null, null, pageable);

        assertThat(result).isEmpty();
        assertThat(result.getContent()).isEmpty();
    }

    @Test
    void getAllUsers_SearchIsBlank_ShouldPassNullToRepository_AndReturnEmptyPage() {
        Pageable pageable = PageRequest.of(1, 20);

        when(userRepository.findAllFiltered(eq("   "), isNull(), eq(pageable)))
                .thenReturn(Page.empty());

        Page<UserDTO> result = userService.getAllUsersAsPageWithFilterAndSorting("   ", null, pageable);

        assertThat(result).isEmpty();
    }

    @Test
    void getAllUsers_StatusTrue_ShouldPassTrueToRepository_AndReturnEmptyPage() {
        Pageable pageable = PageRequest.of(1, 20);

        when(userRepository.findAllFiltered(isNull(), eq(true), any(Pageable.class)))
                .thenReturn(Page.empty());

        Page<UserDTO> result = userService.getAllUsersAsPageWithFilterAndSorting(null, true, pageable);

        assertThat(result).isEmpty();
        assertThat(result.getContent()).isEmpty();
    }

    @Test
    void getAllUsers_StatusFalse_ShouldPassFalseToRepository_AndReturnEmptyPage() {
        Pageable pageable = PageRequest.of(1, 20);

        when(userRepository.findAllFiltered(isNull(), eq(false), any(Pageable.class)))
                .thenReturn(Page.empty());

        Page<UserDTO> result = userService.getAllUsersAsPageWithFilterAndSorting(null, false, pageable);

        assertThat(result).isEmpty();
        assertThat(result.getContent()).isEmpty();
    }

    @Test
    void getUserByEmail_UserExists_ShouldReturnUserDTO() {
        String email = "marija.kovac@example.com";
        User user = new User.Builder().name("Marija Kovač")
                .email(email)
                .role(Role.USER)
                .isActive(true).
                build();

        when(userRepository.findByEmail(email)).thenReturn(Optional.of(user));

        UserDTO userDTO = userService.getUserByEmail(email);
        assertThat(userDTO).isNotNull();
        assertThat(userDTO.name()).isEqualTo("Marija Kovač");
        assertThat(userDTO.email()).isEqualTo(email);
        assertThat(userDTO.role()).isEqualTo(Role.USER);
        assertThat(userDTO.isActive()).isTrue();
    }

    @Test
    void getUserByEmail_UserDoesNotExist_ShouldThrowDBException() {
        String email = "luka.lukic@yahoo.com";

        when(userRepository.findByEmail(email)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> userService.getUserByEmail(email))
                .isInstanceOf(DBException.class)
                .hasMessageContaining("User with email " + email + " not found.");
    }

    @Test
    void createContactInfo_validArgumentGiven_shouldReturnContactInfoResponse() {
        ContactInfoRequest request = new ContactInfoRequest(
                "test123@gmail.com",
                "+385912345678");
        UserDetails userDetails = org.springframework.security.core.userdetails.User.withUsername("8d5cfe7c-1e1b-4a1e-b8f0-111111111111")
                .password("password")
                .roles("USER")
                .build();
        when(userRepository.findById(UUID.fromString("8d5cfe7c-1e1b-4a1e-b8f0-111111111111")))
                .thenReturn(Optional.of(mock(com.ekufrin.infinum.marketplace.model.User.class)));
        when(contactInfoRepository.save(org.mockito.ArgumentMatchers.any()))
                .thenAnswer(i -> i.getArguments()[0]);
        ContactInfoResponse response = userService.createContactInfo(request, userDetails);

        assertThat(response.email()).isEqualTo(request.email());
        assertThat(response.phoneNumber()).isEqualTo(request.phoneNumber());
    }

    @Test
    void createContactInfo_UserNotFound_ThrowsDBException() {
        ContactInfoRequest request = new ContactInfoRequest("notfound@example.com", "+123456789");
        UserDetails userDetails = org.springframework.security.core.userdetails.User
                .withUsername("00000000-0000-0000-0000-000000000000")
                .password("password")
                .roles("USER")
                .build();

        when(userRepository.findById(UUID.fromString(userDetails.getUsername())))
                .thenReturn(Optional.empty());

        assertThatThrownBy(() -> userService.createContactInfo(request, userDetails))
                .isInstanceOf(DBException.class)
                .hasMessageContaining("User not found");
    }

    @Test
    void findAllContactInfoForUser_ValidUserId_ShouldReturnContactInfoPage() {
        UUID userId = UUID.randomUUID();
        Pageable pageable = PageRequest.of(0, 10);

        ContactInfo contactInfo1 = new ContactInfo();
        contactInfo1.setId(UUID.randomUUID());
        contactInfo1.setEmail("test.user@example.com");
        contactInfo1.setPhoneNumber("+123456789");

        ContactInfo contactInfo2 = new ContactInfo();
        contactInfo2.setId(UUID.randomUUID());
        contactInfo2.setEmail("test.user.new.email@example.com");
        contactInfo2.setPhoneNumber("+123456789");

        ContactInfoResponse contact1 = new ContactInfoResponse(
                contactInfo1.getId(),
                "test.user@example.com",
                "+123456789");

        ContactInfoResponse contact2 = new ContactInfoResponse(
                contactInfo2.getId(),
                "test.user.new.email@example.com",
                "+123456789");

        Page<ContactInfo> contactInfoPage = new PageImpl<>(List.of(contactInfo1, contactInfo2));
        when(contactInfoRepository.findAllByUser_Id(userId, pageable))
                .thenReturn(contactInfoPage);
        Page<ContactInfoResponse> result = userService.getAllContactInfoForUser(userId, pageable);
        assertThat(result).isNotNull();
        assertThat(result.getTotalElements()).isEqualTo(2);
        assertThat(result.getContent()).containsExactly(contact1, contact2);
    }

    @Test
    void findAllContactInfoForUser_NoContactInfo_ShouldReturnEmptyPage() {
        UUID userId = UUID.randomUUID();
        Pageable pageable = PageRequest.of(0, 10);

        when(contactInfoRepository.findAllByUser_Id(userId, pageable))
                .thenReturn(Page.empty());

        Page<ContactInfoResponse> result = userService.getAllContactInfoForUser(userId, pageable);

        assertThat(result).isEmpty();
        assertThat(result.getTotalElements()).isZero();
        assertThat(result.getContent()).isEmpty();
    }
}
