package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.model.Location;
import com.ekufrin.infinum.marketplace.repository.LocationRepository;
import com.ekufrin.infinum.marketplace.service.GeocodingService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.client.RestTemplate;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GeocodingServiceTest {
    @InjectMocks
    private GeocodingService geocodingService;
    @Mock
    private RestTemplate restTemplate;
    @Mock
    private LocationRepository locationRepository;

    @Test
    void getGeocoordinatesFromAddress_validAddress_returnsCoordinates() {
        Location location = new Location();
        location.setAddress("Strojarska cesta 22, 1000 Zagreb, Croatia");
        location.setGeoLocation("45.8031937,15.9667828");
        String address = "Strojarska cesta 22, 1000 Zagreb, Croatia";

        when(locationRepository.findByAddress(address)).thenReturn(Optional.of(location));
        String coordinates = geocodingService.getCoordinatesFromAddress(address);

        assertThat(coordinates).isEqualTo("45.8031937,15.9667828");
    }

    @Test
    void getGeocoordinatesFromAddress_invalidAddress_returnsNull() {
        String address = "Invalid Address 12345";

        when(locationRepository.findByAddress(address)).thenReturn(Optional.empty());
        String coordinates = geocodingService.getCoordinatesFromAddress(address);

        assertThat(coordinates).isNull();
    }

    @Test
    void getGeocoordinatesFromAddress_externalServiceFails_returnsNull() {
        String address = "Some Address 12345";

        when(restTemplate.getForObject(any(String.class), any(Class.class))).thenThrow(new RuntimeException("Service down"));
        when(locationRepository.findByAddress(address)).thenReturn(Optional.empty());
        String coordinates = geocodingService.getCoordinatesFromAddress(address);

        assertThat(coordinates).isNull();
    }

}
