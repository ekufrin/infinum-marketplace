package com.ekufrin.infinum.marketplace;

import com.ekufrin.infinum.marketplace.model.OTT;
import com.ekufrin.infinum.marketplace.repository.OTTRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OTTRepositoryTest {

    @Mock
    private OTTRepository ottRepository;


    @Test
    void findById_ShouldReturnOptionalWithOTT_WhenIdExists() {
        UUID id = UUID.randomUUID();
        OTT ott = new OTT();
        ott.setId(id);

        when(ottRepository.findById(id)).thenReturn(Optional.of(ott));

        Optional<OTT> result = ottRepository.findById(id);

        assertThat(result).isPresent();
        assertThat(result.get().getId()).isEqualTo(id);
    }

    @Test
    void findById_ShouldReturnEmptyOptional_WhenIdDoesNotExist() {
        UUID id = UUID.randomUUID();

        when(ottRepository.findById(id)).thenReturn(Optional.empty());
        Optional<OTT> result = ottRepository.findById(id);

        assertThat(result).isEmpty();
    }
}
