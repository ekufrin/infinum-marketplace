CREATE TABLE IF NOT EXISTS app_user
(
    id         UUID PRIMARY KEY,
    name       VARCHAR(100)             NOT NULL,
    email      VARCHAR(100) UNIQUE      NOT NULL,
    username   VARCHAR(100) UNIQUE      NOT NULL,
    password   VARCHAR(255)             NOT NULL,
    role       VARCHAR(50)              NOT NULL,
    is_active  BOOLEAN                           DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS category
(
    id         UUID PRIMARY KEY,
    name       VARCHAR(100) NOT NULL UNIQUE,
    active     BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE
);

CREATE TABLE IF NOT EXISTS contact_info
(
    id           UUID PRIMARY KEY,
    email        VARCHAR(255),
    phone_number VARCHAR(50),
    user_id      UUID NOT NULL,
    CONSTRAINT fk_contact_info_user FOREIGN KEY (user_id) REFERENCES "app_user" (id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS location
(
    id           UUID PRIMARY KEY,
    address      VARCHAR(500) NOT NULL,
    geo_location VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS ad
(
    id                     UUID PRIMARY KEY,
    title                  VARCHAR(120)             NOT NULL,
    description            VARCHAR(2000)            NOT NULL,
    category_id            UUID                     NOT NULL,
    condition              VARCHAR(50)              NOT NULL,
    price                  NUMERIC(15, 2)           NOT NULL,
    expires_at             TIMESTAMP WITH TIME ZONE NOT NULL,
    status                 VARCHAR(50)              NOT NULL,
    author_id              UUID                     NOT NULL,
    location_id            UUID                     NOT NULL,
    contact_info_id        UUID                     NOT NULL,
    expiration_notified_at TIMESTAMP WITH TIME ZONE,
    CONSTRAINT fk_ad_category FOREIGN KEY (category_id) REFERENCES category (id) ON DELETE CASCADE,
    CONSTRAINT fk_ad_location_id FOREIGN KEY (location_id) REFERENCES location (id),
    CONSTRAINT fk_ad_author FOREIGN KEY (author_id) REFERENCES "app_user" (id) ON DELETE CASCADE,
    CONSTRAINT fk_ad_contact_info FOREIGN KEY (contact_info_id) REFERENCES contact_info (id)
);

CREATE TABLE IF NOT EXISTS image
(
    id         UUID PRIMARY KEY,
    created_at TIMESTAMP WITH TIME ZONE,
    ad_id      UUID,
    CONSTRAINT fk_image_ad FOREIGN KEY (ad_id) REFERENCES ad (id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS one_time_token
(
    id         UUID PRIMARY KEY,
    value      VARCHAR(255)             NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL
);
