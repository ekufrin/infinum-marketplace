INSERT INTO app_user (id, name, email, username, password, role, is_active, created_at)
VALUES ('8d5cfe7c-1e1b-4a1e-b8f0-111111111111', 'Luka Papac', 'luka.papac@example.com', 'luka.papac',
        '$2a$12$WeEHkZ4sddLAt7I/LA62.uRphHc7iZ9F/bEo/IaeEvLPp.L4FzZtG', 'ADMIN', true, '2024-01-01 10:00:00'),
       ('7f8adf32-9c71-4d93-a0a1-222222222222', 'Ana Horvat', 'ana.horvat@example.com', 'ana.horvat',
        '$2a$12$WeEHkZ4sddLAt7I/LA62.uRphHc7iZ9F/bEo/IaeEvLPp.L4FzZtG', 'USER', true, '2024-01-02 11:00:00'),
       ('c4c9a87b-3efb-41c8-bbb0-333333333333', 'Ivan Ivić', 'ivan.ivic@example.com', 'ivan.ivic',
        '$2a$12$WeEHkZ4sddLAt7I/LA62.uRphHc7iZ9F/bEo/IaeEvLPp.L4FzZtG', 'USER', true, '2024-01-03 12:00:00'),
       ('d7fbd190-2e48-45f3-9fc1-444444444444', 'Marija Kovač', 'marija.kovac@example.com', 'marija.kovac',
        '$2a$12$WeEHkZ4sddLAt7I/LA62.uRphHc7iZ9F/bEo/IaeEvLPp.L4FzZtG', 'USER', true, '2024-01-04 13:00:00'),
       ('e3d48a9d-2f9d-4262-b7c5-555555555555', 'Petar Perić', 'petar.peric@example.com', 'petar.peric',
        '$2a$12$WeEHkZ4sddLAt7I/LA62.uRphHc7iZ9F/bEo/IaeEvLPp.L4FzZtG', 'USER', true, '2024-01-05 14:00:00'),
       ('f1a6b9e3-483b-41b7-81db-666666666666', 'Ivana Babić', 'ivana.babic@example.com', 'ivana.babic',
        '$2a$12$WeEHkZ4sddLAt7I/LA62.uRphHc7iZ9F/bEo/IaeEvLPp.L4FzZtG', 'USER', true, '2024-01-06 15:00:00'),
       ('a2c3d4e5-6789-4a0b-bcde-777777777777', 'Karlo Katić', 'karlo.katic@example.com', 'karlo.katic',
        '$2a$12$WeEHkZ4sddLAt7I/LA62.uRphHc7iZ9F/bEo/IaeEvLPp.L4FzZtG', 'USER', true, '2024-01-07 16:00:00'),
       ('b1c2d3e4-5678-41f9-abcd-888888888888', 'Maja Novak', 'maja.novak@example.com', 'maja.novak',
        '$2a$12$WeEHkZ4sddLAt7I/LA62.uRphHc7iZ9F/bEo/IaeEvLPp.L4FzZtG', 'USER', true, '2024-01-08 17:00:00'),
       ('c9f8e7d6-5432-4d10-bbaa-999999999999', 'Tomislav Radić', 'tomislav.radic@example.com', 'tomislav.radic',
        '$2a$12$WeEHkZ4sddLAt7I/LA62.uRphHc7iZ9F/bEo/IaeEvLPp.L4FzZtG', 'USER', true, '2024-01-09 18:00:00'),
       ('d8e7f6a5-4321-41ff-8899-aaaaaaaaaaaa', 'Sara Matić', 'sara.matic@example.com', 'sara.matic',
        '$2a$12$WeEHkZ4sddLAt7I/LA62.uRphHc7iZ9F/bEo/IaeEvLPp.L4FzZtG', 'USER', true, '2024-01-10 19:00:00');

INSERT INTO category (id, name, active, created_at)
VALUES ('11111111-1111-1111-1111-111111111111', 'Electronics', true, '2024-01-01 10:00:00'),
       ('22222222-2222-2222-2222-222222222222', 'Books', true, '2024-01-02 11:00:00'),
       ('33333333-3333-3333-3333-333333333333', 'Clothing', false, '2024-01-03 12:00:00'),
       ('44444444-4444-4444-4444-444444444444', 'Home & Kitchen', true, '2024-01-04 13:00:00'),
       ('55555555-5555-5555-5555-555555555555', 'Sports & Outdoors', false, '2024-01-05 14:00:00'),
       ('66666666-6666-6666-6666-666666666666', 'Toys & Games', true, '2024-01-06 15:00:00');

INSERT INTO location (id, address, geo_location)
VALUES ('1a1a1a1a-1a1a-1a1a-1a1a-1a1a1a1a1a1a', 'Ilica 42, 10000 Zagreb', '45.8150,15.9819'),
       ('2b2b2b2b-2b2b-2b2b-2b2b-2b2b2b2b2b2b', 'Marin Držić 15, 21000 Split', '43.5081,16.4402'),
       ('3c3c3c3c-3c3c-3c3c-3c3c-3c3c3c3c3c3c', 'Vukovarska 23, 51000 Rijeka', '45.3271,14.4422'),
       ('4d4d4d4d-4d4d-4d4d-4d4d-4d4d4d4d4d4d', 'Jurja Dobrile 8, 52100 Pula', '44.8666,13.8496'),
       ('5e5e5e5e-5e5e-5e5e-5e5e-5e5e5e5e5e5e', 'Ante Starčevića 12, 31000 Osijek', '45.5550,18.6955'),
       ('6f6f6f6f-6f6f-6f6f-6f6f-6f6f6f6f6f6f', 'Stjepana Radića 7, 23000 Zadar', '44.1194,15.2314'),
       ('7a7a7a7a-7a7a-7a7a-7a7a-7a7a7a7a7a7a', 'Trg bana Jelačića 1, 10000 Zagreb', '45.8131,15.9775'),
       ('8b8b8b8b-8b8b-8b8b-8b8b-8b8b8b8b8b8b', 'Riva 10, 21000 Split', '43.5082,16.4395'),
       ('9c9c9c9c-9c9c-9c9c-9c9c-9c9c9c9c9c9c', 'Korzo 25, 51000 Rijeka', '45.3266,14.4425'),
       ('0d0d0d0d-0d0d-0d0d-0d0d-0d0d0d0d0d0d', 'Forum 5, 52100 Pula', '44.8687,13.8481');

INSERT INTO contact_info (id, email, phone_number, user_id)
VALUES ('ccccccc1-cccc-cccc-cccc-cccccccccccc', 'contact1@example.com', '+385911234567',
        '8d5cfe7c-1e1b-4a1e-b8f0-111111111111'),
       ('ccccccc2-cccc-cccc-cccc-cccccccccccc', 'contact2@example.com', '+385921234567',
        'c9f8e7d6-5432-4d10-bbaa-999999999999'),
       ('ccccccc3-cccc-cccc-cccc-cccccccccccc', 'ana.contact@example.com', '+385931234567',
        '7f8adf32-9c71-4d93-a0a1-222222222222'),
       ('ccccccc4-cccc-cccc-cccc-cccccccccccc', 'ivan.contact@example.com', '+385941234567',
        'c4c9a87b-3efb-41c8-bbb0-333333333333'),
       ('ccccccc5-cccc-cccc-cccc-cccccccccccc', 'marija.contact@example.com', '+385951234567',
        'd7fbd190-2e48-45f3-9fc1-444444444444');

INSERT INTO ad (id, title, description, category_id, condition, price, expires_at, status, author_id, location_id,
                contact_info_id, expiration_notified_at)
VALUES ('ddddddd1-dddd-dddd-dddd-dddddddddddd', 'iPhone 13', 'Almost new, 128GB',
        '11111111-1111-1111-1111-111111111111', 'USED', 500.00, '2024-12-31 23:59:59', 'ACTIVE',
        '8d5cfe7c-1e1b-4a1e-b8f0-111111111111', '1a1a1a1a-1a1a-1a1a-1a1a-1a1a1a1a1a1a',
        'ccccccc1-cccc-cccc-cccc-cccccccccccc', null),
       ('ddddddd2-dddd-dddd-dddd-dddddddddddd', 'Book: Java Basics', 'Great for beginners',
        '22222222-2222-2222-2222-222222222222', 'NEW', 20.00, '2024-11-30 23:59:59', 'ACTIVE',
        'c9f8e7d6-5432-4d10-bbaa-999999999999', '2b2b2b2b-2b2b-2b2b-2b2b-2b2b2b2b2b2b',
        'ccccccc2-cccc-cccc-cccc-cccccccccccc', null),
       ('ddddddd3-dddd-dddd-dddd-dddddddddddd', 'Gaming Laptop', 'RTX 3060, 16GB RAM',
        '11111111-1111-1111-1111-111111111111', 'USED', 899.99, '2025-03-15 23:59:59', 'ACTIVE',
        '7f8adf32-9c71-4d93-a0a1-222222222222', '3c3c3c3c-3c3c-3c3c-3c3c-3c3c3c3c3c3c',
        'ccccccc3-cccc-cccc-cccc-cccccccccccc', null),
       ('ddddddd4-dddd-dddd-dddd-dddddddddddd', 'Kitchen Table', 'Wooden, seats 6',
        '44444444-4444-4444-4444-444444444444', 'USED', 150.00, '2025-02-28 23:59:59', 'ACTIVE',
        'c4c9a87b-3efb-41c8-bbb0-333333333333', '4d4d4d4d-4d4d-4d4d-4d4d-4d4d4d4d4d4d',
        'ccccccc4-cccc-cccc-cccc-cccccccccccc', null),
       ('ddddddd5-dddd-dddd-dddd-dddddddddddd', 'Mountain Bike', '21 speed, excellent condition',
        '55555555-5555-5555-5555-555555555555', 'USED', 250.00, '2027-04-20 23:59:59', 'ACTIVE',
        'd7fbd190-2e48-45f3-9fc1-444444444444', '5e5e5e5e-5e5e-5e5e-5e5e-5e5e5e5e5e5e',
        'ccccccc5-cccc-cccc-cccc-cccccccccccc', null),
       ('ddddddd6-dddd-dddd-dddd-dddddddddddd', 'Road bike', '5 speed, good condition',
        '55555555-5555-5555-5555-555555555555', 'USED', 100.00, CURRENT_TIMESTAMP, 'EXPIRED',
        'd7fbd190-2e48-45f3-9fc1-444444444444', '5e5e5e5e-5e5e-5e5e-5e5e-5e5e5e5e5e5e',
        'ccccccc5-cccc-cccc-cccc-cccccccccccc', null),
       ('ddddddd7-dddd-dddd-dddd-dddddddddddd', 'Microwave', 'Broken door, works fine',
        '55555555-5555-5555-5555-555555555555', 'USED', 100.00, CURRENT_TIMESTAMP, 'EXPIRED',
        'd7fbd190-2e48-45f3-9fc1-444444444444', '5e5e5e5e-5e5e-5e5e-5e5e-5e5e5e5e5e5e',
        'ccccccc5-cccc-cccc-cccc-cccccccccccc', null),
       ('ddddddd8-dddd-dddd-dddd-dddddddddddd', 'Quadcopter Drone', 'Mint condition, 4K camera',
        '55555555-5555-5555-5555-555555555555', 'NEW', 1200.00, CURRENT_TIMESTAMP, 'ACTIVE',
        'd7fbd190-2e48-45f3-9fc1-444444444444', '5e5e5e5e-5e5e-5e5e-5e5e-5e5e5e5e5e5e',
        'ccccccc5-cccc-cccc-cccc-cccccccccccc', CURRENT_TIMESTAMP)
;

INSERT INTO image (id, created_at, ad_id)
VALUES ('eeeeeee1-eeee-eeee-eeee-eeeeeeeeeeee', '2024-06-01 10:00:00',
        'ddddddd1-dddd-dddd-dddd-dddddddddddd'),
       ('eeeeeee2-eeee-eeee-eeee-eeeeeeeeeeee', '2024-06-02 11:00:00',
        'ddddddd2-dddd-dddd-dddd-dddddddddddd'),
       ('eeeeeee3-eeee-eeee-eeee-eeeeeeeeeeee', '2025-08-08 12:23:12', null),
       ('eeeeeee4-eeee-eeee-eeee-eeeeeeeeeeee', '2022-11-01 11:10:00', null);

INSERT INTO one_time_token(id, value, expires_at)
VALUES ('fffffff1-ffff-ffff-ffff-ffffffffffff', 'ddddddd7-dddd-dddd-dddd-dddddddddddd',
        CURRENT_TIMESTAMP + INTERVAL '3 days'),
       ('fffffff2-ffff-ffff-ffff-ffffffffffff', 'ddddddd8-dddd-dddd-dddd-dddddddddddd',
        CURRENT_TIMESTAMP + INTERVAL '3 days');